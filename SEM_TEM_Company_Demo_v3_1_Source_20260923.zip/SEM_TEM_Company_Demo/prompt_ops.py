import cv2
import numpy as np
class PostPrecess:
    @staticmethod
    def remove_small_objects(image,min_size=15):
        n,labels,stats,_=cv2.connectedComponentsWithStats((image>0).astype('uint8'),connectivity=8)
        keep=stats[:,cv2.CC_STAT_AREA]>=min_size;keep[0]=False
        return keep[labels]
    @staticmethod
    def dilation(image,square=5):
        return cv2.dilate(image,np.ones((square,square),np.uint8))
