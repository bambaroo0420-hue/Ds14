# v3.0 — Human-in-the-loop RF 학습
부분 브러시 주석 → Random Forest 학습 → 새 이미지 자동 분할을 추가했습니다. start_rf.bat 또는 메인 창의 RF 학습 / 자동 분할 버튼으로 실행하세요. 먼저 V3_RF_GUIDE.md를 읽으세요. 기존 v2.2 기능도 포함합니다.

# v2.2 업데이트
Canny/Otsu 처리 영상, Gaussian 적용 상태, Otsu 자동 임계값과 동일 조건 실행을 추가했습니다. 먼저 V2_2_UPDATE.md를 읽으세요. v2.1 클릭 보정도 포함합니다.

# v2.1 업데이트
이전 마스크를 입력하는 클릭 보정과 적용/취소가 추가되었습니다. V2_1_UPDATE.md를 먼저 읽으세요. v2 자동 프롬프트와 다층 표시는 유지됩니다.

# 빠른 시작 — 오프라인 묶음 사용 시
Windows 64bit와 Python 3.13 64bit(Tkinter 및 py launcher 포함)가 먼저 설치되어 있어야 합니다. Python 설치 파일은 별도 준비합니다.
1. Offline_Win_Py313 ZIP을 쓰기 가능한 폴더에 압축 해제합니다.
2. setup_offline.bat 실행 → 성공 확인 → start.bat 실행.
3. 체크포인트에서 checkpoints/sam_vit_b_01ec64.pth 선택, 모델 종류를 vit_b로 변경, cpu로 모델 로드.
4. 합성 예제에서 자동 후보 생성 또는 점·박스 수정 → 재분할 → 결과 저장.
ViT-H 파일을 준비했다면 vit_h를 선택할 수 있습니다. 회사 OS/Python이 다르면 wheelhouse를 해당 환경용으로 다시 준비하세요.

# 회사 로컬 SEM/TEM 데모

## 범위
이미지 열기 → 자동 후보 → 층별 점·박스 수정 → 재분할 → 브러시 수정 → 검수 → JPG/마스크/세션 저장. Canny는 독립 비교이며 물리 계면 정답이 아닙니다. 인터넷 서버를 열지 않는 Tkinter 데스크톱 앱입니다. 실행 중 외부 전송·자동 다운로드 없음. 코드·의존성 설치와 체크포인트 준비는 별도입니다.

기본 가정: Windows 10/11, Python 3.11 또는 3.12 64bit와 Tkinter. CPU 기본. GPU는 호환 PyTorch/CUDA 설치 후 cuda 선택. RAM/속도는 실제 회사 PC에서 확인해야 합니다. 아래 명령은 Windows PowerShell 기준입니다.

## 설치 및 실행
```powershell
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python app.py
```
이 기본 설치만으로 합성 영상, Canny, 브러시, 정답 평가, 저장을 시험할 수 있습니다. SAM처럼 보이는 가짜 분할은 하지 않습니다.
SAM 실행은 추가 설치가 필요합니다:
```powershell
.venv\Scripts\python -m pip install -r requirements-sam.txt
```
배포 환경에 따라 CPU용 torch/torchvision을 공식 PyTorch 설치 안내에 맞춰 설치하세요. 동작 확인 후 `pip freeze > environment-lock.txt`로 버전을 고정하세요. requirements는 범위 지정이며 모든 조합 검증을 의미하지 않습니다.

## 체크포인트
공식 출처: https://github.com/facebookresearch/segment-anything#model-checkpoints
ViT-H: sam_vit_h_4b8939.pth / ViT-B: sam_vit_b_01ec64.pth / ViT-L: sam_vit_l_0b3195.pth
공식 링크에서 미리 받아 checkpoints/에 넣고 화면에서 파일과 모델 종류를 일치시켜 선택하세요. 소스 ZIP에는 가중치가 없고, Offline_Win_Py313 ZIP에는 CPU 검증용 ViT-B 가중치를 포함합니다. ViT-H는 별도로 준비하세요. 신뢰할 수 있는 공식/사내 체크포인트만 사용하세요.

회사 서버에서 Decoder만 학습했다면 `torch.save(model.mask_decoder.state_dict(), path)`로 내보낸 파일을 Decoder 선택으로 지정한 뒤 모델을 로드합니다. 동일 기반 모델·구조를 사용해야 합니다. optimizer 포함 학습 체크포인트나 LoRA 파일을 이 입력에 넣지 마세요. LoRA 로딩과 서버 학습 파이프라인은 이번 최소 데모에 포함하지 않았습니다.

## 사용 순서
1. start.bat 또는 app.py 실행. 합성 이미지가 열립니다.
2. 회사 8bit PNG/JPG/TIFF를 열거나 합성 예제로 시작합니다. 16bit 영상은 명시적 대비 변환 후 별도 파일로 사용하세요. 다중 페이지 TIFF는 첫 페이지만 읽습니다.
3. SAM 모델 로드 후 MatSAM prompts 또는 SAM grid 자동 후보 생성. CPU ViT-H는 오래 걸릴 수 있으므로 처음에는 작은 ROI를 권합니다.
4. 후보 번호 선택 → 선택층에 적용. 후보는 서로 겹칠 수 있으며 재료명/층 순서를 자동 인식하지 않습니다.
5. 층별 양성·음성 점/박스를 원본 패널에 입력 → 선택층 재분할. 점 삭제는 클릭과 가장 가까운 점을 삭제합니다. 층 추가로 프롬프트 묶음을 분리합니다.
6. 브러시로 마스크를 수정할 수 있습니다. 재분할하면 브러시 결과를 덮어쓰므로 필요시 되돌리기 또는 먼저 저장하세요. 현재 재분할은 점/박스로 새 예측하며 수정 마스크를 mask_input으로 넘기지 않습니다.
7. Canny low/high 변경 후 에지 갱신. Canny와 mask boundary는 서로 다른 결과입니다.
8. 외부 정답 PNG(같은 크기, 0 배경/양수 전경)를 불러오면 현재 선택층 IoU/Dice 표시. 합성 예제의 synthetic_gt.png는 중간층 정답입니다. 다른 층에 적용하지 마세요.
9. 검수 완료는 사용자 선언이며 정확도를 보장하지 않습니다. 결과 저장은 모든 층과 프롬프트를 보존합니다. 세션 불러오기로 계속 수정할 수 있습니다.

## 출력·좌표
results/시간별 폴더: original.png, layer_N_mask.png, layer_N_comparison.jpg, canny.png, layer_overlap.png, session.json. 외부 GT가 있으면 reference PNG와 지표도 저장합니다. 모든 마스크는 입력 원본 크기. 화면 축소만 적용하고 점을 원본 좌표로 환산합니다. SAM 내부 리사이즈는 공식 predictor가 처리합니다. nm 보정/계측/불확실 구간/스케일바 자동 제외는 미구현. 원본 ROI를 준비해 사용하세요. 마스크 중첩은 overlap.png와 픽셀 수로 기록하며 자동 덮어쓰기 하지 않습니다.

## 캐시와 학습
동일 이미지에서 점 수정은 메모리의 embedding을 재사용합니다. 디스크 embedding 캐시·Decoder 학습·LoRA 학습·시편 단위 분리 평가는 후속 범위입니다. 새 모델 로드시 캐시는 초기화됩니다. 서버 가중치를 로컬로 가져오는 Decoder 로딩 인터페이스만 제공합니다.

## 오프라인 반입
인터넷 가능한 동일 OS/Python 환경에서:
```powershell
python -m pip download -r requirements-sam.txt -d wheelhouse
```
회사로 코드+wheelhouse+체크포인트를 옮긴 뒤:
```powershell
python -m venv .venv
.venv\Scripts\python -m pip install --no-index --find-links wheelhouse -r requirements-sam.txt
```
wheelhouse에는 torch/torchvision과 모든 종속 패키지가 있어야 합니다. OS/Python/CPU·CUDA 대상에 맞춰 준비하고 연결 없는 시험 PC에서 설치·실행을 확인하세요. 소스 ZIP에는 wheel·가중치가 없습니다. Offline_Win_Py313 ZIP에는 wheel과 ViT-B 가중치가 포함됩니다. 두 ZIP 모두 Python 설치 프로그램이나 무설치 EXE는 아닙니다.

## 라이선스·출처
SAM 코드·모델: Apache-2.0, 공식 저장소 LICENSE 동봉/고지 조건 확인. MatSAM 프롬프트 원본은 vendor_reference/에 보존하며 명시적 라이선스 확인 미완료. 사용자 요청에 따라 포함하되 회사 검토 완료라고 주장하지 않습니다. matsam_prompt.py는 최소 의존성 연결·비정사각형 좌표 수정·빈 프롬프트 처리 수정본입니다. 공식 SAM AMG에 연결하고 crop=0, grid8, batch8 사용하므로 원논문 전체 재현은 아닙니다. 결정립 후처리는 제외했습니다. MatSAM 출처: https://github.com/USTB-AI3DVIP/matsam

공개 논문/업체 이미지는 반입 ZIP에 포함하지 않습니다. 예제는 직접 생성한 합성 영상이며 성능 검증용 회사 영상이 아닙니다. 설치 패키지별 라이선스는 회사 배포 버전에 맞춰 별도 확인하세요.

## 이번 PC 실행 검증
Windows / Python 3.13 / CPU에서 ViT-B 실제 추론, MatSAM grid4+중심점 자동 후보 생성, 두 번째 프롬프트의 embedding 재사용, JPG 저장을 확인했습니다. 합성 예제 자동 후보는 5개였습니다. 측정 시간은 VALIDATION.json 참고. 회사 영상의 성능이나 회사 PC 속도를 의미하지 않습니다. ViT-H와 학습 Decoder 파일 로딩은 코드 경로를 제공하지만 이 로컬 검증에서는 실행하지 않았습니다.

정확한 설치 버전은 environment-lock-win-py313.txt에 있습니다. 다른 Python 버전은 설치 가능한 종속성 조합을 다시 검증하세요.
