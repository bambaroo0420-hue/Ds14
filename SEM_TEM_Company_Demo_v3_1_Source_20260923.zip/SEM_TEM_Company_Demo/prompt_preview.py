"""Shared prompt snapshot for preview and SAM execution. No downloads."""
from pathlib import Path
import hashlib,json
import numpy as np
from PIL import Image,ImageDraw
from auto_tools import prepare_prompts,filter_values
from refinement import image_key

def prepare_preview(rgb,config):
    cfg=dict(config);cfg.setdefault('otsu_fixed_blur',True)
    filter_values(cfg['filter_strength'])
    points,meta,proposal,stages=prepare_prompts(rgb,cfg['mode'],cfg['grid'],cfg['prompt_low'],cfg['prompt_high'],cfg['blur_sigma'],cfg['otsu_fixed_blur'],True)
    meta.update(points_sha256=hashlib.sha256(points.tobytes()).hexdigest(),proposal_sha256=hashlib.sha256(proposal.tobytes()).hexdigest(),preprocessing_version='2.2')
    return dict(config=cfg,image_sha256=image_key(rgb),points=points,meta=meta,proposal=proposal,stages=stages,rgb=rgb.copy())

def matches(preview,rgb,config):
    cfg=dict(config);cfg.setdefault('otsu_fixed_blur',True)
    return preview is not None and preview['config']==cfg and preview['image_sha256']==image_key(rgb)

def panels(preview):
    rgb=preview['rgb'];first=Image.fromarray(rgb.copy());draw=ImageDraw.Draw(first);h,w=rgb.shape[:2]
    for i,(x,y) in enumerate(preview['points']):
        x=float(x)*w;y=float(y)*h;color=(85,170,255) if i<preview['meta']['grid_points'] else (255,153,0)
        draw.ellipse((x-2,y-2,x+2,y+2),fill=color)
    stages=preview['stages'];raw=stages['detection'];mode=preview['config']['mode']
    if mode in ('MatSAM Canny','MatSAM prompts'):
        shown=rgb.copy();shown[raw>0]=[255,60,40]
    else:shown=raw
    return [np.array(first),stages['gaussian'],shown,preview['proposal']]

def summary(preview):
    c=preview['config'];m=preview['meta']
    if c['mode']=='SAM grid':return f"SAM grid / {len(preview['points'])} points / Canny, Otsu, Gaussian OFF"
    text=f"{c['mode']} / Gaussian sigma={c['blur_sigma']} (0=OFF)"
    if c['mode']=='MatSAM Otsu':text+=f" / extra 5x5={'ON' if c['otsu_fixed_blur'] else 'OFF'} / Otsu T={m['otsu_threshold']:.0f}"
    else:text+=f" / Canny={c['prompt_low']},{c['prompt_high']} / min area=15 / dilation=5"
    return text+f" / points={len(preview['points'])} / filter={c['filter_strength']}"

def save_preview(preview,folder):
    out=Path(folder);out.mkdir(parents=True,exist_ok=True)
    images=panels(preview);sheet=Image.new('RGB',(1280,900),'white');draw=ImageDraw.Draw(sheet)
    # ASCII labels keep export independent of installed fonts.
    c=preview['config'];head=f"{c['mode']} | sigma={c['blur_sigma']} | Otsu extra5x5={preview['meta']['otsu_fixed_blur']} | T={preview['meta']['otsu_threshold']} | Canny={preview['meta']['prompt_canny']}"
    if c['mode']=='MatSAM Otsu':head=head.rsplit(' | Canny=',1)[0]+' | Canny=OFF'
    if c['mode']=='SAM grid':head='SAM grid | Gaussian/Canny/Otsu OFF'
    draw.text((10,8),head,fill='black')
    titles=['Original + prompts (blue grid / orange centroids)','Actual grayscale input after Gaussian','Raw Canny overlay / Otsu binary / grid blank','Proposal AFTER processing (used for centroids)']
    for i,(a,title) in enumerate(zip(images,titles)):
        x=(i%2)*640;y=40+(i//2)*430;draw.text((x+8,y+5),title,fill='black')
        im=Image.fromarray(a);im.thumbnail((640,390));sheet.paste(im,(x,y+30))
    sheet.save(out/'prompt_preview.jpg',quality=94)
    for name,a in preview['stages'].items():Image.fromarray(a).save(out/(name+'.png'))
    Image.fromarray(preview['proposal']).save(out/'proposal.png')
    (out/'prompt_preview.json').write_text(json.dumps(dict(config=c,metadata=preview['meta'],image_sha256=preview['image_sha256'],points_normalized=preview['points'].tolist()),ensure_ascii=False,indent=2),encoding='utf-8')
    return out

class PreviewWindow:
    def __init__(self,app):
        import tkinter as tk
        from tkinter import ttk
        self.app=app;self.window=tk.Toplevel(app.root);self.window.title('자동 프롬프트 처리 미리보기 — SAM 실행 전');self.window.geometry('1160x820')
        self.label=ttk.Label(self.window,wraplength=1100);self.label.pack(fill='x')
        bar=ttk.Frame(self.window);bar.pack(fill='x')
        ttk.Button(bar,text='현재 설정으로 미리보기 갱신',command=app.preview_points).pack(side='left')
        ttk.Button(bar,text='이 미리보기 조건으로 SAM 실행',command=app.run_preview).pack(side='left')
        ttk.Button(bar,text='미리보기 JPG/조건 저장',command=app.save_prompt_preview).pack(side='left')
        ttk.Label(self.window,text='필터 설정은 메인 창에서 조절합니다. SAM에는 원본 RGB와 생성 점이 입력됩니다. 중심점은 재료층 중심을 보장하지 않습니다.',wraplength=1100).pack(fill='x')
        area=ttk.Frame(self.window);area.pack(fill='both',expand=True);self.canvases=[];self.frames=[];self.photos=[]
        for i in range(4):
            frame=ttk.LabelFrame(area);frame.grid(row=i//2,column=i%2,sticky='nsew');self.frames.append(frame)
            canvas=tk.Canvas(frame,bg='#202832',highlightthickness=0);canvas.pack(fill='both',expand=True);self.canvases.append(canvas)
        for i in range(2):area.rowconfigure(i,weight=1);area.columnconfigure(i,weight=1)
        self.window.bind('<Configure>',lambda e:self.render() if e.widget==self.window else None)
    def alive(self):return bool(self.window.winfo_exists())
    def render(self):
        from PIL import ImageTk
        p=self.app.prompt_snapshot
        if p is None:
            self.label.configure(text='새 영상입니다. 미리보기를 갱신하세요.')
            for c in self.canvases:c.delete('all')
            return
        try:stale=not matches(p,self.app.rgb,self.app.auto_config())
        except Exception:stale=True
        self.label.configure(text=('설정 변경됨 — 갱신 필요. 아래는 이전 조건입니다. ' if stale else '현재 설정과 일치. ')+summary(p))
        mode=p['config']['mode'];titles=['원본 + 생성 점 (파랑 격자 / 주황 중심점)','검출에 실제 사용하는 Gaussian 처리 영상','Canny 원시 에지 오버레이' if mode!='MatSAM Otsu' else 'Otsu 이진 영상 (자동 임계값)','중심점 생성용 후처리 영상']
        if mode=='SAM grid':titles[2]='격자 모드: 에지 검출 안 함';titles[3]='격자 모드: 중심점 생성 안 함'
        self.photos=[]
        for c,f,a,title in zip(self.canvases,self.frames,panels(p),titles):
            f.configure(text=title);im=Image.fromarray(a);im.thumbnail((max(1,c.winfo_width()),max(1,c.winfo_height())))
            photo=ImageTk.PhotoImage(im);self.photos.append(photo);c.delete('all');c.create_image(0,0,image=photo,anchor='nw')
