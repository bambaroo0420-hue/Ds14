import numpy as np
from matsam_prompt import PromptGenerator
PALETTE=[(40,220,130),(70,160,255),(255,175,60),(210,95,245),(255,100,135),(80,220,220)]
def filter_values(name):
    values={'엄격':(.95,.97),'기본':(.90,.92),'완화':(.75,.80)}
    if name not in values:raise ValueError('Unknown candidate filter')
    return values[name]
def prepare_prompts(rgb,mode='MatSAM Canny',grid=8,low=80,high=130,sigma=0.,otsu_fixed_blur=True,return_stages=False):
    if mode not in ('SAM grid','MatSAM prompts','MatSAM Canny','MatSAM Otsu'):raise ValueError('Unknown prompt method')
    if mode=='SAM grid':low,high,sigma=80,130,0.
    generator=PromptGenerator(rgb,n_per_side_base=grid,method_type=2 if mode=='MatSAM Otsu' else 1,canny_low=low,canny_high=high,blur_sigma=sigma,otsu_fixed_blur=otsu_fixed_blur)
    points=generator.generate_prompt_points()[0]
    if mode=='SAM grid':points=generator.grid;centroids=0;proposal=np.zeros(rgb.shape[:2],np.uint8)
    else:centroids=len(generator.centroids);proposal=generator.proposal_image
    meta=dict(mode=mode,grid=int(grid),grid_points=int(grid)**2,centroid_points=centroids,total_points=len(points),prompt_canny=[int(low),int(high)],prompt_blur_sigma=float(sigma),otsu_two_groups=True if mode=='MatSAM Otsu' else False,coordinates='normalized x/width,y/height',crop_layers=0)
    meta.update(otsu_threshold=generator.otsu_threshold if mode=='MatSAM Otsu' else None,otsu_fixed_blur=bool(otsu_fixed_blur) if mode=='MatSAM Otsu' else False,prompt_min_size=15 if mode not in ('SAM grid','MatSAM Otsu') else None,prompt_dilation=5 if mode not in ('SAM grid','MatSAM Otsu') else None)
    if return_stages:
        stages=dict(gaussian=generator.gray_input,detection=generator.detection_image)
        if mode=='SAM grid':
            import cv2
            stages=dict(gaussian=cv2.cvtColor(rgb,cv2.COLOR_RGB2GRAY),detection=np.zeros(rgb.shape[:2],np.uint8))
        return points,meta,proposal,stages
    return points,meta,proposal

def multi_overlay(rgb,masks,show_uncovered=False):
    a=rgb.copy();coverage=np.zeros(rgb.shape[:2],np.int32)
    for i,mask in enumerate(masks):
        mask=np.asarray(mask,dtype=bool);a[mask]=(.5*a[mask]+.5*np.array(PALETTE[i%len(PALETTE)])).astype('uint8');coverage+=mask
    if show_uncovered:a[coverage==0]=(.55*a[coverage==0]+.45*np.array([255,40,40])).astype('uint8')
    a[coverage>1]=[255,255,0]
    return a,coverage
