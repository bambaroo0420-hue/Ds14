import unittest,tempfile,json
from pathlib import Path
from unittest.mock import patch
import numpy as np
import cv2
from PIL import Image
from rf_core import Project,Forest,IGNORE,save_result
from verify_rf import synthetic,scribbles

class RFTests(unittest.TestCase):
    def project(self,folder):
        p=Project(folder);p.meta['classes']={'1':'background','2':'layer','3':'void'};p.save()
        for seed in [10,11]:
            rgb,gt=synthetic(seed);key,_=p.add_image(rgb,str(seed));p.save_labels(key,scribbles(gt,seed))
        return p
    def test_sparse_samples_cache_and_reload(self):
        with tempfile.TemporaryDirectory() as folder:
            p=self.project(folder);x,y,records=p.collect();self.assertEqual(set(y),{1,2,3});self.assertLess(len(y),240*360)
            p2=Project(folder);self.assertEqual(p.classes,p2.classes);self.assertEqual(len(p2.meta['images']),2)
            first=next(iter(p2.meta['images']));rgb=np.asarray(Image.open(p2.root/'data'/(first+'.png')))
            a=p2.cached_features(first,rgb);b=p2.cached_features(first,rgb);np.testing.assert_array_equal(a,b)
            # Release memory-mapped cache handles before Windows removes the folder.
            del a,b
    def test_no_unlabeled_or_excluded_training(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Project(folder);rgb=np.zeros((20,30,3),np.uint8);key,ann=p.add_image(rgb,'one')
            ann[2:5,2:5]=1;ann[10:13,15:18]=2;ann[:2]=IGNORE;p.save_labels(key,ann)
            x,y,_=p.collect();self.assertEqual(len(y),18);self.assertEqual(set(y),{1,2})
    def test_unseen_prediction_no_overlap_saved_model(self):
        with tempfile.TemporaryDirectory() as folder:
            p=self.project(folder);forest=Forest();forest.train(p);forest.save(p.root/'models/test');other=Forest();other.load(p.root/'models/test')
            rgb,gt=synthetic(15);key,ann=p.add_image(rgb,'unseen');ann[:2]=IGNORE
            a=forest.predict(p,key,rgb,ann);b=other.predict(p,key,rgb,ann)
            np.testing.assert_array_equal(a['labels'],b['labels']);self.assertFalse(a['labels'][:2].any());self.assertTrue(np.all(a['labels'][2:]>0))
            self.assertNotIn(key,[r['image_sha256'] for r in forest.meta['training_images']])
            out=save_result(p.root/'results/check',rgb,ann,a,forest)
            masks=[np.asarray(Image.open(out/f'class_{cid:03d}_mask.png'))>0 for cid in [1,2,3]]
            self.assertTrue(np.all(np.sum(masks,axis=0)<=1));self.assertTrue((out/'comparison.jpg').exists())
    def test_retrain_uses_new_annotations(self):
        with tempfile.TemporaryDirectory() as folder:
            p=self.project(folder);f=Forest();f.train(p);before=f.meta['training_samples'];rgb,gt=synthetic(16);key,_=p.add_image(rgb,'additional');p.save_labels(key,scribbles(gt,16));g=Forest();g.train(p)
            self.assertGreater(g.meta['training_samples'],before);self.assertEqual(len(g.meta['training_images']),3)
    def test_empty_classes_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Project(folder)
            with self.assertRaises(ValueError):Forest().train(p)
    def test_ui_draw_undo_and_model_prediction(self):
        import tkinter as tk
        from rf_app import RFApp
        from types import SimpleNamespace
        root=tk.Tk();root.withdraw()
        with tempfile.TemporaryDirectory() as folder:
            try:
                with patch('rf_app.Project',side_effect=lambda path:Project(folder)):
                    app=RFApp(root)
                app.scale=(1,1);app.classbox.current(0);before=app.labels.copy();app.press(SimpleNamespace(x=10,y=10));app.drag(SimpleNamespace(x=25,y=10));app.release(None)
                self.assertTrue((app.labels==1).any());app.undo();np.testing.assert_array_equal(app.labels,before)
                app.project=self.project(Path(folder)/'second');app.update_classes();app.forest=Forest();app.forest.train(app.project)
                rgb,_=synthetic(15);app.rgb=rgb;app.key,app.labels=app.project.add_image(rgb,'unseen');app.task=lambda work,done:done(work());app.predict()
                self.assertIsNotNone(app.result);self.assertFalse(app.labels.any())
                app.mode.set('분석 제외');app.paint((10,10),(20,10));app.predict();self.assertTrue((app.result['labels'][app.labels==IGNORE]==0).all())
            finally:root.destroy()

if __name__=='__main__':unittest.main()
