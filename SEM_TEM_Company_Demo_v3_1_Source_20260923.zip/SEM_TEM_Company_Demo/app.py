from pathlib import Path
import tkinter as tk
from tkinter import ttk,filedialog,messagebox,simpledialog
import threading,queue,json,time,hashlib
import numpy as np
from PIL import Image,ImageTk
from core import Engine,read_image,canny,views,export,metrics
from prompt_preview import prepare_preview,matches,PreviewWindow,save_preview
from refinement import remember, undo, snapshot, valid_logits
from auto_tools import prepare_prompts,multi_overlay,PALETTE
ROOT=Path(__file__).resolve().parent
class App:
    def __init__(self,root):
        self.root=root;root.title('SEM/TEM 회사 로컬 데모 v3.1');root.geometry('1360x900')
        self.engine=Engine();self.rgb=None;self.layers={};self.candidates=[];self.queue=queue.Queue();self.busy=False;self.pending=None;self.prompt_snapshot=None;self.preview_window=None
        bar=ttk.Frame(root);bar.pack(fill='x')
        for title,fn in [('RF 학습 / 자동 분할',self.open_rf),('합성 예제',lambda:self.open(ROOT/'data/demo/synthetic.png')),('이미지 열기',self.open),('세션 불러오기',self.restore),('결과 저장',self.save)]:ttk.Button(bar,text=title,command=fn).pack(side='left')
        self.status=tk.StringVar(value='CPU 기본 / 외부 전송 없음 / 원본 좌표 / 정밀 계측 아님');ttk.Label(root,textvariable=self.status).pack(fill='x')
        model=ttk.LabelFrame(root,text='로컬 SAM 가중치 (필요 파일은 README 참고)');model.pack(fill='x')
        self.ckpt=tk.StringVar();ttk.Entry(model,textvariable=self.ckpt,width=65).pack(side='left');ttk.Button(model,text='체크포인트',command=self.checkpoint).pack(side='left')
        self.variant=tk.StringVar(value='vit_h');ttk.Combobox(model,textvariable=self.variant,values=['vit_b','vit_l','vit_h'],width=7,state='readonly').pack(side='left')
        self.device=tk.StringVar(value='cpu');ttk.Combobox(model,textvariable=self.device,values=['cpu','cuda'],width=6,state='readonly').pack(side='left')
        self.decoder='';ttk.Button(model,text='Decoder 선택(선택사항)',command=self.pick_decoder).pack(side='left');ttk.Button(model,text='모델 로드',command=self.load_model).pack(side='left')
        controls=ttk.Frame(root);controls.pack(fill='x')
        self.layer=tk.StringVar();self.layerbox=ttk.Combobox(controls,textvariable=self.layer,state='readonly',width=14);self.layerbox.pack(side='left');self.layerbox.bind('<<ComboboxSelected>>',lambda e:self.refresh())
        ttk.Button(controls,text='층 추가',command=self.add_layer).pack(side='left')
        self.mode=tk.StringVar(value='양성 점');ttk.Combobox(controls,textvariable=self.mode,values=['양성 점','음성 점','점 삭제','박스','마스크 칠하기','마스크 지우기'],state='readonly',width=15).pack(side='left')
        ttk.Label(controls,text='브러시 반경(px)').pack(side='left');self.brush=tk.IntVar(value=6);ttk.Spinbox(controls,from_=1,to=100,textvariable=self.brush,width=4).pack(side='left')
        ttk.Button(controls,text='선택 마스크 클릭 보정',command=self.predict).pack(side='left');ttk.Button(controls,text='점/박스 초기화',command=self.clear).pack(side='left');ttk.Button(controls,text='편집 되돌리기',command=self.undo).pack(side='left')
        ttk.Button(controls,text='정답 PNG 불러오기',command=self.gt).pack(side='left');ttk.Button(controls,text='현재 마스크 검수 확정',command=self.review).pack(side='left')
        correction=ttk.Frame(root);correction.pack(fill='x')
        ttk.Button(correction,text='보정 적용',command=self.apply_correction).pack(side='left')
        ttk.Button(correction,text='보정 취소',command=self.cancel_correction).pack(side='left')
        ttk.Label(correction,text='보정 미리보기: 이전 / 제안 / 변화(초록=추가, 자홍=제거). 적용 전에는 마스크가 바뀌지 않습니다.').pack(side='left')
        auto=ttk.Frame(root);auto.pack(fill='x');self.automode=tk.StringVar(value='MatSAM Canny');ttk.Combobox(auto,textvariable=self.automode,values=['MatSAM Canny','MatSAM Otsu','SAM grid'],state='readonly',width=18).pack(side='left')
        ttk.Button(auto,text='자동 후보 생성 (CPU 느림)',command=self.automatic).pack(side='left');self.candidate=tk.StringVar();self.cbox=ttk.Combobox(auto,textvariable=self.candidate,state='readonly',width=24);self.cbox.pack(side='left');ttk.Button(auto,text='후보를 선택층에 적용',command=self.use_candidate).pack(side='left')
        tuning=ttk.LabelFrame(root,text='자동 프롬프트 설정 — 아래 비교용 Canny와 독립');tuning.pack(fill='x')
        self.grid=tk.IntVar(value=8);ttk.Label(tuning,text='격자 한 변').pack(side='left');ttk.Combobox(tuning,textvariable=self.grid,values=[8,16,32],state='readonly',width=4).pack(side='left')
        self.promptlow=tk.IntVar(value=80);self.prompthigh=tk.IntVar(value=130);self.sigma=tk.DoubleVar(value=0.)
        self.prompt_widgets=[]
        for name,var,maximum in [('프롬프트 Canny low',self.promptlow,255),('high',self.prompthigh,255),('평활화 sigma',self.sigma,10)]:
            ttk.Label(tuning,text=name).pack(side='left');widget=ttk.Spinbox(tuning,from_=0,to=maximum,increment=.5 if maximum==10 else 1,textvariable=var,width=5);widget.pack(side='left');self.prompt_widgets.append(widget)
        self.strength=tk.StringVar(value='기본');ttk.Label(tuning,text='후보 필터').pack(side='left');ttk.Combobox(tuning,textvariable=self.strength,values=['엄격','기본','완화'],state='readonly',width=6).pack(side='left')
        ttk.Button(tuning,text='처리 영상 / 자동 점 미리보기',command=self.preview_points).pack(side='left')
        extra=ttk.Frame(root);extra.pack(fill='x');self.otsu_fixed=tk.BooleanVar(value=True)
        self.otsu_toggle=ttk.Checkbutton(extra,text='Otsu 추가 5×5 Gaussian (기존 동작)',variable=self.otsu_fixed);self.otsu_toggle.pack(side='left')
        self.filter_note=tk.StringVar();ttk.Label(extra,textvariable=self.filter_note).pack(side='left')
        for var in [self.automode,self.grid,self.promptlow,self.prompthigh,self.sigma,self.strength,self.otsu_fixed]:var.trace_add('write',self.prompt_settings_changed)
        self.prompt_settings_changed()
        viewing=ttk.Frame(root);viewing.pack(fill='x');self.viewmode=tk.StringVar(value='선택층');viewbox=ttk.Combobox(viewing,textvariable=self.viewmode,values=['선택층','모든 층','모든 자동 후보'],state='readonly',width=16);viewbox.pack(side='left');viewbox.bind('<<ComboboxSelected>>',lambda e:self.refresh())
        self.showpoints=tk.BooleanVar(value=True);ttk.Checkbutton(viewing,text='자동 점 표시 (파랑=격자, 주황=중심점)',variable=self.showpoints,command=self.refresh).pack(side='left')
        self.uncovered=tk.BooleanVar(value=True);ttk.Checkbutton(viewing,text='미포함 영역 빨강 / 겹침 노랑',variable=self.uncovered,command=self.refresh).pack(side='left')
        self.autoinfo=tk.StringVar(value='Otsu는 밝기 두 그룹을 나누는 방법이며 재료층별 분류가 아닙니다.');ttk.Label(root,textvariable=self.autoinfo,wraplength=1250).pack(fill='x')
        self.auto_points=None;self.auto_metadata={}
        comparison=ttk.Frame(root);comparison.pack(fill='x')
        ttk.Label(comparison,text='비교 전용 Canny: Gaussian 5×5, sigma=1 고정 / 자동 프롬프트와 별도').pack(side='left')
        self.low=tk.IntVar(value=40);self.high=tk.IntVar(value=100)
        for name,var in [('비교 Canny low',self.low),('high',self.high)]:ttk.Label(comparison,text=name).pack(side='left');ttk.Spinbox(comparison,from_=0,to=255,textvariable=var,width=5).pack(side='left')
        ttk.Button(comparison,text='비교 에지 갱신 (SAM과 별도)',command=self.edge).pack(side='left')
        ttk.Label(root,text='원본 패널 클릭: 점 입력/삭제 · 박스는 드래그 · 브러시 단위: 원본 px · 우클릭: 음성 점 · 후보 적용 → 포함/제외 점 → 클릭 보정 → 보정 적용 · 박스는 대상 프롬프트(이미지 크롭 아님)').pack(fill='x')
        area=ttk.Frame(root);area.pack(fill='both',expand=True);self.canvases=[];self.photos=[];self.panel_frames=[]
        for i,title in enumerate(['원본 / 프롬프트 (편집)','Segmentation 마스크','마스크 경계 ≠ 물리 계면','Canny 명암 에지 ≠ 정답']):
            frame=ttk.LabelFrame(area,text=title);self.panel_frames.append(frame);frame.grid(row=i//2,column=i%2,sticky='nsew');c=tk.Canvas(frame,bg='#202832',highlightthickness=0);c.pack(fill='both',expand=True);self.canvases.append(c)
        for i in range(2):area.columnconfigure(i,weight=1);area.rowconfigure(i,weight=1)
        self.canvases[0].bind('<Button-1>',self.click);self.canvases[0].bind('<B1-Motion>',self.drag);self.canvases[0].bind('<ButtonRelease-1>',self.release);self.canvases[0].bind('<Button-3>',lambda e:self.click(e,negative=True))
        root.bind('<Configure>',self.resize);root.after(150,self.poll);root.after(300,self.open_initial_example)
    def open_initial_example(self):
        if self.rgb is None:
            self.open(ROOT/'data/demo/synthetic.png')
    def open_rf(self):
        if self.blocked():return
        from rf_app import RFApp
        if getattr(self,'rf_window',None) is not None and self.rf_window.winfo_exists():self.rf_window.lift();return
        self.rf_window=tk.Toplevel(self.root);self.rf_application=RFApp(self.rf_window)
    def resize(self,e):
        if e.widget==self.root:self.root.after_idle(self.refresh)
    def blocked(self):
        if self.pending is not None:self.status.set('먼저 보정 적용 또는 보정 취소를 선택하세요.');return True
        return self.busy
    def current(self):return self.layers[self.layer.get()]
    def open(self,path=None):
        if self.blocked():return
        if path is None:path=filedialog.askopenfilename(filetypes=[('8-bit images','*.png *.jpg *.jpeg *.tif *.tiff *.bmp')])
        if not path:return
        try:
            self.rgb=read_image(path);self.source=dict(filename=Path(path).name,sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest());self.layers={};self.candidates=[];self.prompt_snapshot=None;self.auto_points=None;self.auto_metadata={};self.auto_result_metadata={};self.cbox['values']=[];self.candidate.set('');self.new_layer('Layer 1');self.edge();self.status.set('이미지 로드 완료. 층 내부에 양성 점을 찍거나 마스크를 직접 편집하세요.')
            if self.preview_window is not None and self.preview_window.alive():self.preview_window.render()
        except Exception as e:messagebox.showerror('이미지 오류',str(e))
    def new_layer(self,name):
        self.layers[name]=dict(points=[],labels=[],box=[],mask=np.zeros(self.rgb.shape[:2],bool),reviewed=False,history=[],gt=None,logits=None,logits_context=None,initialized=False);self.layerbox['values']=list(self.layers);self.layer.set(name)
    def add_layer(self):
        if self.blocked() or self.rgb is None:return
        name=simpledialog.askstring('층 이름','목표 층 이름:')
        if name and name not in self.layers:self.new_layer(name);self.refresh()
    def checkpoint(self):
        if self.blocked():return
        f=filedialog.askopenfilename(filetypes=[('SAM checkpoint','*.pth *.pt')]);self.ckpt.set(f or self.ckpt.get())
    def pick_decoder(self):
        if not self.blocked():self.decoder=filedialog.askopenfilename(filetypes=[('Decoder state_dict','*.pth *.pt')])
    def task(self,work,done):
        if self.blocked():return
        self.busy=True;self.layerbox.configure(state='disabled');self.status.set('처리 중… CPU ViT-H는 오래 걸릴 수 있습니다. 입력 변경은 잠시 잠깁니다.')
        def run():
            try:self.queue.put((done,work(),None))
            except Exception as e:self.queue.put((done,None,str(e)))
        threading.Thread(target=run,daemon=True).start()
    def poll(self):
        try:
            done,result,error=self.queue.get_nowait();self.busy=False;self.layerbox.configure(state='readonly')
            if error:self.status.set('실패: '+error);messagebox.showerror('실행 실패',error)
            else:done(result)
        except queue.Empty:pass
        self.root.after(150,self.poll)
    def load_model(self):
        checkpoint,variant,device,decoder=self.ckpt.get(),self.variant.get(),self.device.get(),self.decoder
        self.task(lambda:self.engine.load(checkpoint,variant,device,decoder),lambda r:self.status.set('모델 로드 완료: '+r['model']+' / '+r['device']))
    def remember(self):remember(self.current())
    def predict(self):
        if self.rgb is None or self.blocked():return
        l=self.current();previous=snapshot(l)
        def done(r):
            self.pending=dict(layer=self.layer.get(),result=r)
            self.layerbox.configure(state='disabled');self.refresh()
            changed=int(np.count_nonzero(l['mask']!=r['mask']))
            self.status.set(f"보정 미리보기: {changed} px 변경 / 이전 입력: {r['inference']['prior_source']}. 적용 또는 취소하세요.")
        self.task(lambda:self.engine.refine(self.rgb,previous['points'],previous['labels'],previous['box'],previous),done)
    def apply_correction(self):
        if self.busy or self.pending is None:return
        l=self.layers[self.pending['layer']];remember(l);l.update(self.pending['result'])
        self.pending=None;self.layerbox.configure(state='readonly');self.refresh();self.status.set('보정 적용 완료. 이전 SAM logits를 다음 보정에 재사용합니다.')
    def cancel_correction(self):
        if self.busy or self.pending is None:return
        self.pending=None;self.layerbox.configure(state='readonly');self.refresh();self.status.set('보정 취소. 이전 마스크를 유지합니다. 입력한 점은 남아 있으므로 수정 후 다시 보정할 수 있습니다.')
    def auto_config(self):
        return dict(mode=self.automode.get(),grid=self.grid.get(),prompt_low=self.promptlow.get(),prompt_high=self.prompthigh.get(),blur_sigma=self.sigma.get(),filter_strength=self.strength.get(),otsu_fixed_blur=self.otsu_fixed.get())
    def prompt_settings_changed(self,*args):
        mode=self.automode.get()
        for widget in self.prompt_widgets[:2]:widget.configure(state='normal' if mode=='MatSAM Canny' else 'disabled')
        self.prompt_widgets[2].configure(state='disabled' if mode=='SAM grid' else 'normal')
        self.otsu_toggle.configure(state='normal' if mode=='MatSAM Otsu' else 'disabled')
        note='sigma=0: 추가 Gaussian 끔. Canny 작은 에지 제거 15px / 팽창 5×5.'
        if mode=='MatSAM Otsu':note='Otsu 임계값 자동 계산. sigma=0이어도 추가 5×5가 켜져 있으면 평활화 적용.'
        if mode=='SAM grid':note='격자만 사용. Gaussian / Canny / Otsu 설정은 적용하지 않음.'
        self.filter_note.set(note)
        if self.preview_window is not None and self.preview_window.alive():self.preview_window.render()
    def set_prompt_preview(self,prepared):
        self.prompt_snapshot=prepared;self.auto_points=prepared['points'].copy();self.auto_metadata=dict(prepared['meta'])
        if self.preview_window is None or not self.preview_window.alive():self.preview_window=PreviewWindow(self)
        self.preview_window.render();self.preview_window.window.lift()
    def preview_points(self):
        if self.blocked() or self.rgb is None:return
        try:
            self.set_prompt_preview(prepare_preview(self.rgb,self.auto_config()));self.refresh()
            self.status.set('처리 영상 미리보기 완료. 조건을 확인한 뒤 미리보기 창의 SAM 실행을 누르세요.')
        except Exception as e:messagebox.showerror('프롬프트 설정 오류',str(e))
    def run_preview(self):
        if self.blocked() or self.rgb is None:return
        try:
            if not matches(self.prompt_snapshot,self.rgb,self.auto_config()):
                self.status.set('설정이 바뀌었습니다. 먼저 현재 설정으로 미리보기를 갱신하세요.');return
            self.automatic(require_preview=True)
        except Exception as e:messagebox.showerror('미리보기 오류',str(e))
    def save_prompt_preview(self):
        if self.blocked() or self.prompt_snapshot is None:return
        try:
            if not matches(self.prompt_snapshot,self.rgb,self.auto_config()):
                self.status.set('설정 변경됨: 미리보기 갱신 후 저장하세요.');return
            out=filedialog.askdirectory(initialdir=ROOT/'results')
            if out:
                dest=Path(out)/('prompt_'+time.strftime('%Y%m%d_%H%M%S')+'_'+str(time.time_ns())[-6:])
                save_preview(self.prompt_snapshot,dest);self.status.set('미리보기 저장: '+str(dest))
        except Exception as e:messagebox.showerror('저장 오류',str(e))
    def automatic(self,require_preview=False):
        if self.rgb is None or self.blocked():return
        try:
            cfg=self.auto_config()
            if not matches(self.prompt_snapshot,self.rgb,cfg):
                if require_preview:self.status.set('미리보기 갱신 필요');return
                self.set_prompt_preview(prepare_preview(self.rgb,cfg))
            prepared=self.prompt_snapshot
        except Exception as e:messagebox.showerror('설정 오류',str(e));return
        def done(r):
            self.candidates=r;self.cbox['values']=[f'{i}: {m["area"]} px' for i,m in enumerate(r)]
            self.auto_points=self.engine.last_auto_points.copy();self.auto_metadata=dict(self.engine.last_auto);self.auto_result_metadata=dict(self.engine.last_auto)
            if r:self.cbox.current(0)
            else:self.candidate.set('')
            self.viewmode.set('모든 자동 후보');self.refresh();self.status.set(f'자동 후보 {len(r)}개. 미리보기와 같은 점 사용. 미리보기 창에서 실제 실행 조건을 확인하세요.')
            if self.preview_window is not None and self.preview_window.alive():self.preview_window.render()
        self.task(lambda:self.engine.automatic(self.rgb,**cfg,prepared=prepared),done)
    def use_candidate(self):
        if self.blocked() or not self.candidates or self.cbox.current()<0:return
        l=self.current();candidate=self.candidates[self.cbox.current()];source=dict(getattr(self,'auto_result_metadata',{}))
        def done(result):
            self.remember();l.update(result);self.viewmode.set('선택층');self.refresh()
            self.status.set('후보 마스크와 생성 점 적용 / 보정 시작 입력: '+result['candidate_seed'])
        self.task(lambda:self.engine.candidate_state(self.rgb,candidate,source),done)
    def edge(self):
        if self.rgb is None or self.blocked():return
        try:self.edges=canny(self.rgb,self.low.get(),self.high.get());self.refresh()
        except Exception as e:messagebox.showerror('Canny 오류',str(e))
    def coords(self,e):
        w,h=self.display_size;x=e.x/self.sx;y=e.y/self.sy
        if not (0<=e.x<w and 0<=e.y<h):return None
        return [min(self.rgb.shape[1]-1,int(x)),min(self.rgb.shape[0]-1,int(y))]
    def click(self,e,negative=False):
        if self.blocked() or self.rgb is None:return
        pt=self.coords(e)
        if pt is None:return
        l=self.current();mode='음성 점' if negative else self.mode.get();self.start=pt
        if mode!='박스':self.remember()
        if mode in ('양성 점','음성 점'):l['points'].append(pt);l['labels'].append(int(mode=='양성 점'))
        elif mode=='점 삭제' and l['points']:
            i=int(np.argmin(np.sum((np.array(l['points'])-pt)**2,axis=1)));l['points'].pop(i);l['labels'].pop(i)
        elif mode.startswith('마스크'):self.paint(pt)
        self.refresh()
    def paint(self,pt):
        l=self.current();y,x=np.ogrid[:self.rgb.shape[0],:self.rgb.shape[1]];region=(x-pt[0])**2+(y-pt[1])**2<=max(1,self.brush.get())**2;l['mask'][region]=self.mode.get()=='마스크 칠하기';l['reviewed']=False;l['logits']=None;l['logits_context']=None;l['initialized']=True
    def drag(self,e):
        if self.blocked() or self.rgb is None:return
        pt=self.coords(e)
        if pt and self.mode.get().startswith('마스크'):self.paint(pt);self.refresh()
    def release(self,e):
        if self.blocked() or self.rgb is None or not hasattr(self,'start'):return
        pt=self.coords(e)
        if pt and self.mode.get()=='박스':
            x0,y0=self.start;x1,y1=pt
            if x0!=x1 and y0!=y1:self.remember();self.current()['box']=[min(x0,x1),min(y0,y1),max(x0,x1),max(y0,y1)];self.current()['reviewed']=False;self.refresh()
    def clear(self):
        if self.blocked() or self.rgb is None:return
        self.remember();l=self.current();l['points']=[];l['labels']=[];l['box']=[];self.refresh()
    def undo(self):
        if self.blocked() or self.rgb is None:return
        l=self.current()
        if l['history']:undo(l);self.refresh()
    def gt(self):
        if self.blocked() or self.rgb is None:return
        f=filedialog.askopenfilename(filetypes=[('Binary mask','*.png')])
        if not f:return
        try:
            gt=np.array(Image.open(f).convert('L'))>0;l=self.current();score=metrics(l['mask'],gt);l['gt']=gt;self.status.set('외부 정답 대비: '+json.dumps(score))
        except Exception as e:messagebox.showerror('정답 오류',str(e))
    def review(self):
        if self.blocked() or self.rgb is None:return
        if messagebox.askyesno('검수','선택층 마스크를 검수 완료로 기록할까요? 자동 예측을 정답으로 간주하지 마세요.'):
            self.current()['reviewed']=True;self.status.set('선택층 검수 완료. 정답 평가는 독립적인 외부 정답으로 수행합니다.')
    def refresh(self):
        if self.rgb is None or not hasattr(self,'edges'):return
        self.photos=[];l=self.current()
        panels=views(self.rgb,l['mask'],self.edges)
        names=[];masks=[]
        if self.viewmode.get()=='모든 층':names=list(self.layers);masks=[x['mask'] for x in self.layers.values()]
        elif self.viewmode.get()=='모든 자동 후보':names=[f'candidate {j}' for j in range(len(self.candidates))];masks=[x['segmentation'] for x in self.candidates]
        if self.viewmode.get()!='선택층':
            panels[1],coverage=multi_overlay(self.rgb,masks,self.uncovered.get())
            self.autoinfo.set(f'{self.viewmode.get()} {len(masks)}개 / 미포함 {int((coverage==0).sum())}px / 겹침 {int((coverage>1).sum())}px. 배경도 미포함에 속함. 자동 생성 조건: '+json.dumps(getattr(self,'auto_result_metadata',{}),ensure_ascii=False))
        titles=['원본 / 프롬프트 (편집)','Segmentation 마스크','마스크 경계 ≠ 물리 계면','Canny 명암 에지 ≠ 정답']
        if self.pending is not None:
            before=l['mask'];after=self.pending['result']['mask'];diff=self.rgb.copy()
            diff[after & ~before]=[0,255,120];diff[before & ~after]=[255,0,180]
            panels=[self.rgb,views(self.rgb,before,self.edges)[1],views(self.rgb,after,self.edges)[1],diff]
            titles=['입력 프롬프트 (미리보기 중 잠금)','보정 전','보정 제안 (아직 미적용)','변화: 초록 추가 / 자홍 제거'];names=[]
        for frame,title in zip(self.panel_frames,titles):frame.configure(text=title)
        for i,(c,a) in enumerate(zip(self.canvases,panels)):

            pic=Image.fromarray(a);pic.thumbnail((max(1,c.winfo_width()),max(1,c.winfo_height())));photo=ImageTk.PhotoImage(pic);self.photos.append(photo);c.delete('all');c.create_image(0,0,image=photo,anchor='nw')
            if i==1 and names:
                for j,name in enumerate(names[:12]):c.create_text(8,10+15*j,text=name,fill='#%02x%02x%02x'%PALETTE[j%len(PALETTE)],anchor='nw')
            if i==0:
                self.sx=pic.width/self.rgb.shape[1];self.sy=pic.height/self.rgb.shape[0];self.display_size=(pic.width,pic.height)
                if self.showpoints.get() and self.auto_points is not None:
                    ngrid=self.auto_metadata.get('grid_points',0)
                    for j,(nx,ny) in enumerate(self.auto_points):
                        px=nx*pic.width;py=ny*pic.height;color='#55aaff' if j<ngrid else '#ff9900';c.create_oval(px-2,py-2,px+2,py+2,fill=color,outline='')
                for (x,y),label in zip(l['points'],l['labels']):c.create_oval(x*self.sx-4,y*self.sy-4,x*self.sx+4,y*self.sy+4,fill='lime' if label else 'red',outline='black')
                if l['box']:
                    x0,y0,x1,y1=l['box'];c.create_rectangle(x0*self.sx,y0*self.sy,x1*self.sx,y1*self.sy,outline='yellow',width=2)
    def save(self):
        if self.blocked() or self.rgb is None:return
        out=filedialog.askdirectory(initialdir=ROOT/'results')
        if not out:return
        try:
            layers={n:{k:v for k,v in l.items() if k!='history'} for n,l in self.layers.items()};dest=export(out,self.rgb,layers,self.edges,self.source,getattr(self.engine,'info',{}),dict(canny=[self.low.get(),self.high.get()],prompt_controls=self.auto_config(),nm_per_pixel=None,automatic=getattr(self,'auto_result_metadata',{}),prompt_preview=self.auto_metadata,automatic_points_normalized=self.auto_points.tolist() if self.auto_points is not None else []));self.status.set('저장: '+str(dest))
        except Exception as e:messagebox.showerror('저장 오류',str(e))
    def restore(self):
        if self.blocked():return
        f=filedialog.askopenfilename(filetypes=[('Session','session.json')])
        if not f:return
        try:
            d=Path(f).parent;r=json.loads(Path(f).read_text(encoding='utf-8'));self.open(d/'original.png');self.source=r['source'];self.layers={}
            for rec in r['layers']:
                self.new_layer(rec['name']);l=self.current();l.update({k:v for k,v in rec.items() if k not in ('name','mask','reference','metrics','logits_file')});l['mask']=np.array(Image.open(d/rec['mask']).convert('L'))>0
                l['initialized']=rec.get('initialized',True)
                if 'logits_file' in rec:
                    value=np.load(d/rec['logits_file'],allow_pickle=False)
                    if not valid_logits(value):raise ValueError('Invalid saved logits')
                    l['logits']=value
                if 'reference' in rec:l['gt']=np.array(Image.open(d/rec['reference']).convert('L'))>0
            cfg=r['settings'].get('prompt_controls')
            if cfg:
                for key,var in [('mode',self.automode),('grid',self.grid),('prompt_low',self.promptlow),('prompt_high',self.prompthigh),('blur_sigma',self.sigma),('filter_strength',self.strength),('otsu_fixed_blur',self.otsu_fixed)]:
                    if key in cfg:var.set(cfg[key])
            self.low.set(r['settings']['canny'][0]);self.high.set(r['settings']['canny'][1]);self.auto_result_metadata=r['settings'].get('automatic',{});self.auto_metadata=r['settings'].get('prompt_preview',{});pts=r['settings'].get('automatic_points_normalized',[]);self.auto_points=np.array(pts) if pts else None;self.edge();self.status.set('세션 복원 완료. 모델은 별도로 로드하세요.')
        except Exception as e:messagebox.showerror('복원 오류',str(e))
if __name__=='__main__':
    root=tk.Tk();App(root);root.mainloop()
