from pathlib import Path
import json,time
import numpy as np
from PIL import Image,ImageDraw
import torch
from core import Engine,read_image,metrics,views
ROOT=Path(__file__).resolve().parent
if __name__=='__main__':
    torch.set_num_threads(4)
    e=Engine();e.load(ROOT/'checkpoints/sam_vit_b_01ec64.pth','vit_b','cpu')
    rgb=read_image(ROOT/'data/demo/synthetic.png');gt=np.array(Image.open(ROOT/'data/demo/synthetic_gt.png').convert('L'))>0
    points=[[200,170]];labels=[1];box=[20,100,620,250]
    initial=e.refine(rgb,points,labels,box)
    corrected_points=points+[[350,172]];corrected_labels=[1,0]
    fresh=e.refine(rgb,corrected_points,corrected_labels,box)
    refined=e.refine(rgb,corrected_points,corrected_labels,box,initial)
    binary=e.refine(rgb,corrected_points,corrected_labels,box,dict(mask=initial['mask'],initialized=True))
    assert refined['inference']['prior_source']=='sam_logits'
    assert binary['inference']['prior_source']=='binary_mask_seed'
    with torch.inference_mode():
        masks,scores,logits=e.predictor.predict(point_coords=np.array(points),point_labels=np.array(labels),multimask_output=True)
    candidate=dict(segmentation=masks[0],point_coords=points,bbox=[0,0,640,360])
    recovered=e.candidate_state(rgb,candidate,dict(model=e.info))
    assert recovered['candidate_seed']=='sam_logits'
    np.testing.assert_array_equal(recovered['logits'],logits[0:1])
    yy,xx=np.ogrid[:rgb.shape[0],:rgb.shape[1]];far=(xx-350)**2+(yy-172)**2>40**2
    out=ROOT/'results/refinement_v2_1';out.mkdir(parents=True,exist_ok=True)
    report=dict(dataset='synthetic only; no company TEM accuracy validation',model=e.info,candidate_logits_recovered=True,conditions=dict(initial_points=points,initial_labels=labels,box=box,correction_points=corrected_points,correction_labels=corrected_labels,far_radius_px=40),results={})
    for name,r in [('initial',initial),('fresh',fresh),('refined',refined),('binary_seed',binary)]:
        report['results'][name]=dict(**metrics(r['mask'],gt),**r['inference'],changed_pixels=int((r['mask']!=initial['mask']).sum()),changed_far_pixels=int(((r['mask']!=initial['mask'])&far).sum()))
    sheet=Image.new('RGB',(1280,1200),'white');draw=ImageDraw.Draw(sheet)
    items=[('Original',rgb),('Synthetic GT',views(rgb,gt,gt)[1]),('Initial mask',views(rgb,initial['mask'],gt)[1]),('Fresh prediction (old)',views(rgb,fresh['mask'],gt)[1]),('Previous SAM logits (new)',views(rgb,refined['mask'],gt)[1]),('Binary seed fallback',views(rgb,binary['mask'],gt)[1])]
    for i,(title,img) in enumerate(items):
        x=(i%2)*640;y=(i//2)*400;draw.text((x+8,y+8),title,fill='black');sheet.paste(Image.fromarray(img),(x,y+35))
    sheet.save(out/'comparison.jpg',quality=94)
    (out/'comparison.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
