"""MatSAM centroid + grid prompts, adapted for RGB, repeatability and settings.
Original source: vendor_reference/prompt_generator_original.py.
Canny/Otsu are proposal heuristics, not semantic layer labels.
"""
import cv2
import numpy as np
from prompt_ops import PostPrecess

class PromptGenerator:
    def __init__(self,image,layers=0,scales=3,n_per_side_base=32,method_type=1,canny_low=80,canny_high=130,blur_sigma=0.,min_size=15,dilation=5,otsu_fixed_blur=True):
        self.otsu_fixed_blur=bool(otsu_fixed_blur);self.otsu_threshold=None;self.image=image;self.layers=layers;self.scales=scales;self.n_per_side_base=int(n_per_side_base);self.method_type=method_type
        self.low=int(canny_low);self.high=int(canny_high);self.sigma=float(blur_sigma);self.min_size=int(min_size);self.dilation=int(dilation)
        if layers!=0:raise ValueError('This demo supports crop_n_layers=0 only')
        if not 1<=self.n_per_side_base<=64:raise ValueError('Grid must be 1..64')
        if self.method_type==1 and not 0<=self.low<self.high<=255:raise ValueError('Prompt Canny requires 0 <= low < high <= 255')
        if not 0<=self.sigma<=10:raise ValueError('Sigma must be 0..10')
        if self.min_size<1 or not 1<=self.dilation<=31:raise ValueError('Invalid prompt preprocessing')
    def generate_prompt_points(self):
        gray=cv2.cvtColor(self.image,cv2.COLOR_RGB2GRAY)
        if self.sigma:gray=cv2.GaussianBlur(gray,(0,0),self.sigma)
        self.gray_input=gray.copy()
        if self.method_type==1:
            edges=cv2.Canny(gray,self.low,self.high)
            self.detection_image=edges.copy()
            filtered=PostPrecess.remove_small_objects(edges,min_size=self.min_size)
            self.proposal_image=PostPrecess.dilation(filtered.astype('uint8')*255,square=self.dilation)
        elif self.method_type==2:
            blurred=cv2.GaussianBlur(gray,(5,5),0) if self.otsu_fixed_blur else gray
            self.gray_input=blurred.copy()
            self.otsu_threshold,self.proposal_image=cv2.threshold(blurred,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
            self.detection_image=self.proposal_image.copy()
        else:raise ValueError('method_type must be 1 Canny or 2 Otsu')
        contours,_=cv2.findContours(self.proposal_image,cv2.RETR_TREE,cv2.CHAIN_APPROX_TC89_KCOS)
        centers=[];h,w=gray.shape
        for contour in contours:
            m=cv2.moments(contour)
            if m['m00']:centers.append([m['m10']/m['m00']/w,m['m01']/m['m00']/h])
        self.centroids=np.asarray(centers,dtype=np.float32).reshape(-1,2)
        n=self.n_per_side_base;side=(np.arange(n,dtype=np.float32)+.5)/n
        gx,gy=np.meshgrid(side,side);self.grid=np.column_stack([gx.ravel(),gy.ravel()])
        self.points_layers=[np.concatenate([self.grid,self.centroids],axis=0)]
        return self.points_layers
