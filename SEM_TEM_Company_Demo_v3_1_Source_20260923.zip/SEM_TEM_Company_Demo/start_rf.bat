@echo off
cd /d "%~dp0"
if exist .venv\Scripts\python.exe (.venv\Scripts\python.exe rf_app.py) else (python rf_app.py)
pause
