import tkinter as tk,json,tempfile
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
import numpy as np
from app import App,ROOT
root=tk.Tk();root.withdraw();app=App(root);app.open(ROOT/'data/demo/synthetic.png');root.update();app.refresh()
app.refresh=lambda:None
app.sx=app.sy=1.;app.display_size=(640,360)
app.click(SimpleNamespace(x=100,y=170));assert app.current()['points']==[[100,170]]
app.mode.set('박스');app.click(SimpleNamespace(x=10,y=110));app.release(SimpleNamespace(x=620,y=240));assert app.current()['box']==[10,110,620,240]
app.mode.set('마스크 칠하기');app.click(SimpleNamespace(x=100,y=175));assert app.current()['mask'][175,100];app.undo();assert not app.current()['mask'][175,100]
app.new_layer('층 2');assert not app.current()['points'];app.layer.set('Layer 1');assert len(app.current()['points'])==1
with tempfile.TemporaryDirectory() as d:
    with patch('app.filedialog.askdirectory',return_value=d):app.save()
    f=next(Path(d).glob('*/session.json'))
    with patch('app.filedialog.askopenfilename',return_value=str(f)):app.restore()
    assert len(app.layers)==2;assert app.layers['Layer 1']['points']==[[100,170]];assert app.layers['Layer 1']['box']==[10,110,620,240]
root.destroy();print('UI handler smoke PASS: init, point/box mapping, brush/undo, layer isolation, export/restore. Hidden-window test; no screenshot QA.')
