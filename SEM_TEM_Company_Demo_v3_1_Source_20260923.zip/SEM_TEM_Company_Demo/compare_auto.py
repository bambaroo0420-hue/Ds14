from pathlib import Path
import json
import numpy as np
import torch
from PIL import Image,ImageDraw
from core import Engine,read_image
from auto_tools import multi_overlay
p=Path(__file__).resolve().parent;out=p/'results/auto_v2';out.mkdir(parents=True,exist_ok=True)
torch.set_num_threads(4);engine=Engine();engine.load(p/'checkpoints/sam_vit_b_01ec64.pth','vit_b','cpu');rgb=read_image(p/'data/demo/synthetic.png');report=[]
for mode in ['SAM grid','MatSAM Canny','MatSAM Otsu']:
    masks=engine.automatic(rgb,mode,grid=8);overlay,coverage=multi_overlay(rgb,[m['segmentation'] for m in masks],True)
    meta=dict(engine.last_auto,uncovered_pixels=int((coverage==0).sum()),overlap_pixels=int((coverage>1).sum()),gt_accuracy_evaluated=False)
    canvas=Image.new('RGB',(rgb.shape[1]*2,rgb.shape[0]+40),'white');canvas.paste(Image.fromarray(rgb),(0,40));canvas.paste(Image.fromarray(overlay),(rgb.shape[1],40));draw=ImageDraw.Draw(canvas)
    for j,(x,y) in enumerate(engine.last_auto_points):
        x*=rgb.shape[1];y=y*rgb.shape[0]+40;draw.ellipse((x-2,y-2,x+2,y+2),fill='blue' if j<64 else 'orange')
    draw.text((5,10),mode+' | prompts / candidates | red=uncovered, yellow=overlap | SYNTHETIC ONLY',fill='black')
    canvas.save(out/(mode.replace(' ','_')+'.jpg'),quality=94)
    report.append(meta);print(mode,len(masks),meta['total_points'],flush=True)
(out/'comparison.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print('COMPARISON_COMPLETE',flush=True)
