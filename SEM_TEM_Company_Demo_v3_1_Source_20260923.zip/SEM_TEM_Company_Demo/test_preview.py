import unittest,json
from pathlib import Path
from unittest.mock import patch
import numpy as np
import cv2
from prompt_preview import prepare_preview,matches,save_preview
from core import Engine

class PreviewTests(unittest.TestCase):
    def rgb(self):
        a=np.random.default_rng(2).integers(0,60,(80,140,3),dtype=np.uint8);a[25:55]+=90;return a
    def cfg(self,mode='MatSAM Canny'):
        return dict(mode=mode,grid=8,prompt_low=40,prompt_high=100,blur_sigma=1.5,filter_strength='기본',otsu_fixed_blur=True)
    def test_actual_gaussian_canny_and_postprocess(self):
        rgb=self.rgb();cfg=self.cfg();p=prepare_preview(rgb,cfg)
        gray=cv2.GaussianBlur(cv2.cvtColor(rgb,cv2.COLOR_RGB2GRAY),(0,0),1.5)
        np.testing.assert_array_equal(p['stages']['gaussian'],gray)
        np.testing.assert_array_equal(p['stages']['detection'],cv2.Canny(gray,40,100))
        self.assertFalse(np.array_equal(p['stages']['detection'],p['proposal']))
    def test_otsu_extra_blur_and_threshold(self):
        rgb=self.rgb();cfg=self.cfg('MatSAM Otsu');cfg.update(blur_sigma=0,otsu_fixed_blur=False)
        p=prepare_preview(rgb,cfg);gray=cv2.cvtColor(rgb,cv2.COLOR_RGB2GRAY)
        t,b=cv2.threshold(gray,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
        np.testing.assert_array_equal(p['stages']['gaussian'],gray);np.testing.assert_array_equal(p['proposal'],b);self.assertEqual(t,p['meta']['otsu_threshold'])
        cfg['otsu_fixed_blur']=True;q=prepare_preview(rgb,cfg)
        np.testing.assert_array_equal(q['stages']['gaussian'],cv2.GaussianBlur(gray,(5,5),0))
    def test_snapshot_used_by_engine_and_mismatch_rejected(self):
        rgb=self.rgb();cfg=self.cfg();p=prepare_preview(rgb,cfg);e=Engine();e.predictor=object();e.model=object();e.info={'device':'cpu'}
        with patch('segment_anything.SamAutomaticMaskGenerator') as generator:
            generator.return_value.generate.return_value=[]
            e.automatic(rgb,**cfg,prepared=p)
            np.testing.assert_array_equal(generator.call_args.kwargs['point_grids'][0],p['points'])
            np.testing.assert_array_equal(generator.return_value.generate.call_args.args[0],rgb)
            self.assertEqual(e.last_auto['points_sha256'],p['meta']['points_sha256'])
            with self.assertRaises(ValueError):e.automatic(rgb,**dict(cfg,blur_sigma=2),prepared=p)
            changed=rgb.copy();changed[0,0]=255
            with self.assertRaises(ValueError):e.automatic(changed,**cfg,prepared=p)
    def test_grid_no_processing(self):
        p=prepare_preview(self.rgb(),self.cfg('SAM grid'));self.assertEqual(len(p['points']),64);self.assertFalse(p['proposal'].any());self.assertFalse(p['stages']['detection'].any())
    def test_ui_stale_and_modes(self):
        import tkinter as tk
        from app import App
        root=tk.Tk();root.withdraw()
        try:
            app=App(root);app.open(Path(__file__).parent/'data/demo/synthetic.png');app.preview_points();app.preview_window.window.withdraw()
            self.assertTrue(matches(app.prompt_snapshot,app.rgb,app.auto_config()))
            app.sigma.set(2);app.run_preview();self.assertIn('바뀌었습니다',app.status.get())
            app.automode.set('MatSAM Otsu');self.assertEqual(str(app.prompt_widgets[0]['state']),'disabled')
            app.preview_points();app.preview_window.window.withdraw();self.assertIsNotNone(app.prompt_snapshot['meta']['otsu_threshold'])
            app.otsu_fixed.set(False);self.assertFalse(matches(app.prompt_snapshot,app.rgb,app.auto_config()))
            app.open(Path(__file__).parent/'data/demo/synthetic.png');self.assertIsNone(app.prompt_snapshot)
        finally:root.destroy()

if __name__=='__main__':unittest.main()
