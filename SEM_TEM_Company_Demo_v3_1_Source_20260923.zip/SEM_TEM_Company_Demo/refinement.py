"""Per-layer refinement state; no network access."""
from copy import deepcopy
import hashlib
import numpy as np

def snapshot(layer):
    return deepcopy({k:v for k,v in layer.items() if k not in ('history','gt')})

def remember(layer):
    layer['history'].append(snapshot(layer))
    layer['history']=layer['history'][-8:]
    layer['reviewed']=False

def undo(layer):
    if not layer['history']:return
    previous=layer['history'].pop();history=layer['history'];gt=layer.get('gt')
    layer.clear();layer.update(previous,history=history,gt=gt)

def image_key(rgb):
    return hashlib.sha256(str(rgb.shape).encode()+rgb.tobytes()).hexdigest()

def context(rgb,info):
    return dict(image_sha256=image_key(rgb),shape=list(rgb.shape),
        checkpoint_sha256=info.get('checkpoint_sha256'),decoder_sha256=info.get('decoder_sha256'),
        model=info.get('model'),preprocessing='SAM RGB ResizeLongestSide bottom-right-pad v1')

def valid_logits(value):
    return isinstance(value,np.ndarray) and value.shape==(1,256,256) and np.isfinite(value).all()

def mask_seed(mask,input_size,encoder_size=1024):
    # Approximate binary seed, NOT recovered SAM confidence logits.
    import torch
    import torch.nn.functional as F
    x=torch.as_tensor(np.asarray(mask,dtype=np.float32))[None,None]*8-4
    x=F.interpolate(x,size=input_size,mode='bilinear',align_corners=False)
    x=F.pad(x,(0,encoder_size-input_size[1],0,encoder_size-input_size[0]),value=-4)
    return F.interpolate(x,size=(256,256),mode='bilinear',align_corners=False)[0].numpy()
