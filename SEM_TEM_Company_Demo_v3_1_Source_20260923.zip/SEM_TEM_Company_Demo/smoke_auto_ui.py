import tkinter as tk,tempfile,json
from pathlib import Path
from unittest.mock import patch
from app import App,ROOT
root=tk.Tk();root.withdraw();a=App(root);a.open(ROOT/'data/demo/synthetic.png');root.update()
a.automode.set('MatSAM Otsu');a.grid.set(16);a.preview_points();assert a.auto_metadata['grid_points']==256
a.new_layer('oxide');a.current()['mask'][130:220,:]=True;a.viewmode.set('모든 층');a.refresh();assert '2개' in a.autoinfo.get()
a.candidates=[{'segmentation':a.current()['mask'].copy(),'area':57600}];a.viewmode.set('모든 자동 후보');a.refresh();assert '1개' in a.autoinfo.get()
with tempfile.TemporaryDirectory() as d:
 with patch('app.filedialog.askdirectory',return_value=d):a.save()
 f=next(Path(d).glob('*/session.json'));r=json.loads(f.read_text(encoding='utf-8'));assert r['settings']['prompt_preview']['grid']==16
 with patch('app.filedialog.askopenfilename',return_value=str(f)):a.restore()
 assert a.auto_metadata['grid']==16;assert len(a.layers)==2
root.destroy();print('AUTO_UI_HANDLERS_PASS')
