import unittest,tempfile,json
from pathlib import Path
import numpy as np
from PIL import Image
from core import *
from matsam_prompt import PromptGenerator
class Tests(unittest.TestCase):
    def test_void_boundary(self):
        m=np.ones((9,12),bool);m[3:6,4:7]=False
        b=boundary(m);self.assertFalse(b[4,5]);self.assertTrue(b[2,5]);self.assertTrue(b[0,0])
    def test_metrics(self):
        a=np.array([[1,0],[1,0]],bool);b=np.array([[1,1],[0,0]],bool)
        self.assertAlmostEqual(metrics(a,b)['iou'],1/3);self.assertEqual(metrics(a,b)['dice'],.5)
        with self.assertRaises(ValueError):metrics(a,b[:1])
    def test_rectangular_prompts(self):
        rgb=np.zeros((100,320,3),np.uint8);rgb[20:80,190:280]=180
        pts=PromptGenerator(rgb,n_per_side_base=8).generate_prompt_points()[0]
        self.assertGreater(len(pts),64);self.assertTrue(((pts>=0)&(pts<=1)).all())
        self.assertTrue(np.any(np.abs(pts[64:,0]-.735)<.05))
    def test_export(self):
        rgb=np.zeros((20,40,3),np.uint8);m=np.zeros((20,40),bool);m[3:12,4:20]=True
        layers={'layer':dict(mask=m,gt=m,points=[[8,8]],labels=[1],box=[],reviewed=False)}
        with tempfile.TemporaryDirectory() as d:
            out=export(d,rgb,layers,canny(rgb),{}, {},{'canny':[40,100]})
            r=json.loads((out/'session.json').read_text());self.assertEqual(r['layers'][0]['metrics']['iou'],1);self.assertFalse(r['layers'][0]['reviewed'])
            with Image.open(out/'layer_000_mask.png') as image:self.assertEqual(image.size,(40,20))
if __name__=='__main__':unittest.main()
