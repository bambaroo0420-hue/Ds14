from pathlib import Path
import tkinter as tk
from tkinter import ttk,filedialog,messagebox,simpledialog
import queue,threading,time,json
import numpy as np
import cv2
from PIL import Image,ImageTk
from core import read_image
from rf_core import Project,Forest,IGNORE,COLORS,overlay,save_result
ROOT=Path(__file__).resolve().parent

class RFApp:
    def __init__(self,root):
        self.root=root;root.title('SEM/TEM v3 — 부분 주석으로 RF 학습 / 새 이미지 자동 분할');root.geometry('1280x850')
        self.project=Project(ROOT/'rf_projects/default');self.forest=Forest();self.rgb=None;self.labels=None;self.result=None;self.busy=False;self.queue=queue.Queue();self.history=[];self.dirty=False
        bar=ttk.Frame(root);bar.pack(fill='x')
        for name,fn in [('프로젝트 열기/새로 만들기',self.open_project),('이미지 열기',self.open_image),('학습 예제 이미지 목록',self.image_list),('주석 저장',self.save_annotations),('합성 사용 예제',self.example)]:ttk.Button(bar,text=name,command=fn).pack(side='left')
        self.status=tk.StringVar(value='각 클래스 내부에 선을 그리세요. 주석 없는 픽셀은 학습에 쓰지 않습니다.');ttk.Label(root,textvariable=self.status,wraplength=1200).pack(fill='x')
        controls=ttk.Frame(root);controls.pack(fill='x');self.classvar=tk.StringVar();self.classbox=ttk.Combobox(controls,textvariable=self.classvar,state='readonly',width=24);self.classbox.pack(side='left')
        ttk.Button(controls,text='클래스 추가',command=self.add_class).pack(side='left');ttk.Button(controls,text='이름 변경',command=self.rename_class).pack(side='left')
        self.mode=tk.StringVar(value='주석');ttk.Combobox(controls,textvariable=self.mode,values=['주석','주석 지우기','분석 제외'],state='readonly',width=12).pack(side='left')
        ttk.Label(controls,text='브러시 반경(px)').pack(side='left');self.radius=tk.IntVar(value=3);ttk.Spinbox(controls,from_=1,to=60,textvariable=self.radius,width=4).pack(side='left')
        ttk.Button(controls,text='주석 되돌리기',command=self.undo).pack(side='left')
        train=ttk.Frame(root);train.pack(fill='x')
        for name,fn in [('누적 주석으로 RF 학습',self.train),('현재 이미지 자동 분할',self.predict),('모델 저장',self.save_model),('모델 불러오기',self.load_model),('결과 JPG/라벨맵 저장',self.export),('독립 GT 평가',self.evaluate)]:ttk.Button(train,text=name,command=fn).pack(side='left')
        row=ttk.Frame(root);row.pack(fill='x');self.autorun=tk.BooleanVar(value=True);ttk.Checkbutton(row,text='모델이 있으면 새 이미지 자동 예측',variable=self.autorun).pack(side='left')
        self.review=tk.BooleanVar(value=True);ttk.Checkbutton(row,text='검토 필요 영역 노랑 빗금',variable=self.review,command=self.refresh).pack(side='left')
        self.threshold=tk.DoubleVar(value=.55);self.margin=tk.DoubleVar(value=.15)
        for name,var in [('검토 투표비 기준',self.threshold),('1·2위 차이 기준',self.margin)]:ttk.Label(row,text=name).pack(side='left');ttk.Spinbox(row,from_=0,to=1,increment=.05,textvariable=var,width=5).pack(side='left')
        ttk.Label(root,text='왼쪽: 클래스별 짧은 선으로 학습 예시 입력 / 오른쪽: 예측. 틀린 곳을 왼쪽에 주석 후 재학습. 모델 예측을 자동으로 GT에 넣지 않습니다.',wraplength=1200).pack(fill='x')
        self.info=tk.StringVar();ttk.Label(root,textvariable=self.info,wraplength=1200).pack(fill='x')
        area=ttk.Frame(root);area.pack(fill='both',expand=True);self.canvases=[];self.photos=[]
        for i,title in enumerate(['원본 + 학습 브러시 (자홍=분석 제외)','겹침 없는 RF 예측 / 노랑=검토 필요']):
            frame=ttk.LabelFrame(area,text=title);frame.grid(row=0,column=i,sticky='nsew');c=tk.Canvas(frame,bg='#202832');c.pack(fill='both',expand=True);self.canvases.append(c);area.columnconfigure(i,weight=1)
        area.rowconfigure(0,weight=1);self.canvases[0].bind('<Button-1>',self.press);self.canvases[0].bind('<B1-Motion>',self.drag);self.canvases[0].bind('<ButtonRelease-1>',self.release)
        root.bind('<Configure>',lambda e:root.after_idle(self.refresh) if e.widget==root else None);root.protocol('WM_DELETE_WINDOW',self.close)
        self.update_classes();root.after(150,self.poll)
        self.open_image(ROOT/'data/demo/synthetic.png')
    def update_classes(self):
        values=[f'{cid}: {name}' for cid,name in self.project.classes.items()];self.classbox['values']=values
        if self.classvar.get() not in values:self.classbox.current(0)
    def save_annotations(self):
        if self.busy:return
        if self.rgb is not None:self.project.save_labels(self.key,self.labels);self.dirty=False
    def open_project(self):
        if self.busy:return
        folder=filedialog.askdirectory(title='프로젝트 폴더 선택 (빈 폴더면 새 프로젝트)')
        if folder:
            self.save_annotations();self.project=Project(folder);self.forest=Forest();self.rgb=None;self.labels=None;self.result=None;self.history=[];self.dirty=False
            if hasattr(self,'previous'):del self.previous
            self.update_classes();self.refresh();self.status.set('프로젝트 전환. 이미지 또는 모델을 불러오세요.')
    def open_image(self,path=None):
        if self.busy:return
        if path is None:path=filedialog.askopenfilename(filetypes=[('8-bit image','*.png *.jpg *.jpeg *.tif *.tiff *.bmp')])
        if not path:return
        try:
            rgb=read_image(path);self.save_annotations();self.rgb=rgb;self.key,self.labels=self.project.add_image(rgb,Path(path).name);self.history=[];self.result=None;self.dirty=False;self.refresh()
            if self.autorun.get() and hasattr(self.forest,'model'):self.predict()
            else:self.status.set('이미지 로드. 배경과 각 목표 영역에 주석을 넣고 누적 학습하세요.')
        except Exception as e:messagebox.showerror('이미지 오류',str(e))
    def image_list(self):
        if self.busy:return
        win=tk.Toplevel(self.root);win.title('프로젝트 이미지 — 더블클릭으로 열기');box=tk.Listbox(win,width=85,height=16);box.pack(fill='both',expand=True)
        keys=list(self.project.meta['images'])
        for k in keys:box.insert('end',self.project.meta['images'][k]['name']+' / '+k[:12])
        def choose(e):
            if box.curselection():self.open_image(self.project.root/'data'/(keys[box.curselection()[0]]+'.png'));win.destroy()
        box.bind('<Double-Button-1>',choose)
    def add_class(self):
        if self.busy:return
        name=simpledialog.askstring('클래스 추가','분리할 영역 이름 (새 클래스는 주석 후 재학습 필요):',parent=self.root)
        if name:
            cid=max(self.project.classes)+1
            if cid>254:messagebox.showerror('클래스','최대 254개');return
            self.project.meta['classes'][str(cid)]=name;self.project.save();self.update_classes();self.classbox.current(len(self.project.classes)-1);self.result=None;self.refresh()
    def rename_class(self):
        if self.busy:return
        cid=int(self.classvar.get().split(':')[0]);name=simpledialog.askstring('이름 변경','같은 클래스의 표시 이름만 변경하세요. 의미 변경은 새 프로젝트에서 진행하세요.',parent=self.root)
        if name:
            self.project.meta['classes'][str(cid)]=name;self.project.save()
            if hasattr(self.forest,'meta'):self.forest.meta['classes'][str(cid)]=name
            self.update_classes();self.refresh()
    def pos(self,e):
        if not hasattr(self,'scale'):return None
        x=int(e.x/self.scale[0]);y=int(e.y/self.scale[1]);h,w=self.labels.shape
        return (x,y) if 0<=x<w and 0<=y<h else None
    def press(self,e):
        if self.busy or self.rgb is None:return
        pt=self.pos(e)
        if pt is None:return
        self.history.append(self.labels.copy());self.history=self.history[-12:];self.previous=pt;self.paint(pt,pt)
    def paint(self,a,b):
        cid=0 if self.mode.get()=='주석 지우기' else IGNORE if self.mode.get()=='분석 제외' else int(self.classvar.get().split(':')[0])
        radius=max(1,min(60,self.radius.get()));cv2.line(self.labels,a,b,int(cid),2*radius+1);cv2.circle(self.labels,b,radius,int(cid),-1)
        self.dirty=True;self.refresh();self.status.set('주석 변경됨. RF 학습 버튼을 누르면 이 주석이 학습에 반영됩니다. 오른쪽은 이전 예측일 수 있습니다.')
    def drag(self,e):
        if self.busy or self.rgb is None or not hasattr(self,'previous'):return
        pt=self.pos(e)
        if pt is not None:self.paint(self.previous,pt);self.previous=pt
    def release(self,e):
        if hasattr(self,'previous'):del self.previous
        self.save_annotations()
    def undo(self):
        if self.busy or self.rgb is None:return
        if self.history:self.labels=self.history.pop();self.save_annotations();self.refresh();self.status.set('주석 복원. 예측 갱신은 재학습/재예측 후 반영됩니다.')
    def task(self,work,done):
        if self.busy:return
        self.busy=True;self.status.set('CPU 처리 중… 이미지/주석 변경은 잠깁니다.')
        def worker():
            try:self.queue.put((done,work(),None))
            except Exception as e:self.queue.put((done,None,str(e)))
        threading.Thread(target=worker,daemon=True).start()
    def poll(self):
        try:
            done,value,error=self.queue.get_nowait();self.busy=False
            if error:self.status.set('실패: '+error);messagebox.showerror('RF 오류',error)
            else:done(value)
        except queue.Empty:pass
        self.root.after(150,self.poll)
    def compatible(self):return hasattr(self.forest,'meta') and self.forest.meta['classes']==self.project.meta['classes']
    def train(self):
        if self.busy:return
        self.save_annotations()
        def work():
            forest=Forest();forest.train(self.project);folder=self.project.root/'models'/('rf_'+str(time.time_ns()));forest.save(folder);return forest,folder
        def done(value):
            self.forest,folder=value;self.status.set('학습·모델 자동 저장 완료: '+str(folder));self.predict()
        self.task(work,done)
    def predict(self):
        if self.busy or self.rgb is None:return
        if not self.compatible():messagebox.showerror('모델','현재 클래스 목록과 일치하는 모델을 학습하거나 불러오세요.');return
        try:
            threshold=self.threshold.get();margin=self.margin.get()
            if not 0<=threshold<=1 or not 0<=margin<=1:raise ValueError('검토 기준은 0~1')
        except Exception as e:messagebox.showerror('설정',str(e));return
        self.save_annotations()
        def done(result):
            self.result=result;self.prediction_annotations=self.labels.copy();self.refresh();self.status.set(f"자동 분할 완료: {result['info']['seconds']:.2f}초 / 검토 필요 {result['info']['review_pixels']}px. 이는 GT 정확도가 아닙니다.")
        self.task(lambda:self.forest.predict(self.project,self.key,self.rgb,self.labels,threshold,margin),done)
    def save_model(self):
        if self.busy:return
        if not hasattr(self.forest,'model'):messagebox.showerror('모델','학습 또는 불러오기 먼저');return
        folder=filedialog.askdirectory(title='모델 저장 상위 폴더')
        if folder:
            dest=Path(folder)/('rf_'+str(time.time_ns()));self.forest.save(dest);self.status.set('모델 저장: '+str(dest))
    def load_model(self):
        if self.busy:return
        folder=filedialog.askdirectory(title='forest.xml과 model.json이 있는 폴더')
        if not folder:return
        try:
            forest=Forest();forest.load(folder)
            if forest.meta['classes']!=self.project.meta['classes']:
                self.save_annotations()
                has_labels=any(np.any((np.asarray(Image.open(f))>0)&(np.asarray(Image.open(f))!=IGNORE)) for f in (self.project.root/'annotations').glob('*.png'))
                if has_labels:raise ValueError('현재 주석의 클래스와 다릅니다. 빈 새 프로젝트에서 모델을 불러오세요.')
                self.project.meta['classes']=forest.meta['classes'].copy();self.project.save();self.update_classes()
            self.forest=forest;self.result=None
            if self.rgb is not None:self.predict()
        except Exception as e:messagebox.showerror('모델 오류',str(e))
    def export(self):
        if self.busy or self.result is None:return
        self.save_annotations()
        if not np.array_equal(self.labels,self.prediction_annotations):
            self.status.set('주석/제외 영역이 예측 후 변경되었습니다. 학습 또는 현재 이미지 자동 분할 후 저장하세요.');return
        folder=self.project.root/'results'/('prediction_'+str(time.time_ns()));save_result(folder,self.rgb,self.labels,self.result,self.forest);self.status.set('저장: '+str(folder))
    def evaluate(self):
        if self.busy or self.result is None:return
        path=filedialog.askopenfilename(title='같은 클래스 ID의 독립 GT PNG (0/65535 제외)',filetypes=[('GT labelmap','*.png')])
        if not path:return
        try:
            gt=np.asarray(Image.open(path))
            if gt.shape!=self.labels.shape:raise ValueError('GT dimensions mismatch')
            valid=(gt!=0)&(gt!=IGNORE);pred=self.result['labels'];rows={}
            if not valid.any():raise ValueError('평가할 GT 픽셀이 없습니다.')
            if not set(np.unique(gt[valid])).issubset(self.project.classes):raise ValueError('GT 클래스 ID가 프로젝트와 다릅니다.')
            for cid,name in self.project.classes.items():
                a=(pred==cid)&valid;b=(gt==cid)&valid;inter=int((a&b).sum());union=int((a|b).sum());den=int(a.sum()+b.sum());rows[name]=dict(iou=inter/union if union else None,dice=2*inter/den if den else None)
            from rf_core import write_json
            dest=self.project.root/'results'/('evaluation_'+str(time.time_ns())+'.json');write_json(dest,dict(metrics=rows,valid_pixels=int(valid.sum()),training_image=self.key in [r['image_sha256'] for r in self.forest.meta['training_images']],note='GT is evaluation only; not added to training'))
            messagebox.showinfo('독립 GT 평가',json.dumps(rows,ensure_ascii=False,indent=2)+'\n저장: '+str(dest))
        except Exception as e:messagebox.showerror('평가 오류',str(e))
    def example(self):
        if self.busy:return
        self.save_annotations();folder=ROOT/'rf_example_project'
        if not (folder/'project.json').exists():messagebox.showerror('예제','rf_example_project 폴더를 업데이트 ZIP에서 복사하세요.');return
        self.project=Project(folder);self.forest=Forest();self.forest.load(folder/'models/example');self.rgb=None;self.result=None;self.update_classes();self.open_image(ROOT/'data/rf_demo/test.png')
    def refresh(self):
        if self.rgb is None:
            for c in self.canvases:c.delete('all')
            return
        arrays=[overlay(self.rgb,self.labels),overlay(self.rgb,self.result['labels'],self.result['review'] if self.review.get() else None) if self.result is not None else self.rgb]
        self.photos=[]
        for i,(c,a) in enumerate(zip(self.canvases,arrays)):
            im=Image.fromarray(a);im.thumbnail((max(1,c.winfo_width()),max(1,c.winfo_height())));photo=ImageTk.PhotoImage(im);self.photos.append(photo);c.delete('all');c.create_image(0,0,image=photo,anchor='nw')
            if i==0:self.scale=(im.width/self.rgb.shape[1],im.height/self.rgb.shape[0])
        counts=' / '.join(f'{cid}:{name} {int((self.labels==cid).sum())}px' for cid,name in self.project.classes.items())
        self.info.set('프로젝트: '+str(self.project.root)+' | 현재 이미지 주석: '+counts+' | 0=미주석, 배경도 별도 클래스. RF 투표비는 정확도 확률이 아닙니다.')
    def close(self):
        if self.busy:self.status.set('처리가 끝난 뒤 닫아주세요.');return
        self.save_annotations();self.root.destroy()

if __name__=='__main__':
    root=tk.Tk();RFApp(root);root.mainloop()
