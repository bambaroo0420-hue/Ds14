"""Reproducible CPU inference checks; pass a local SAM checkpoint explicitly."""
import argparse
import json
import platform
import tempfile
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

from core import Engine, read_image, metrics
from prompt_preview import prepare_preview
from rf_core import Project, Forest, save_result
from verify_rf import synthetic, scribbles


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path)
    parser.add_argument('--output', type=Path, default=Path('results/release_validation'))
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    cv2.setNumThreads(4)
    report = {'version': '3.1', 'python': platform.python_version(),
              'opencv': cv2.__version__, 'dataset': 'Synthetic only; not company TEM validation'}
    # Keep generated projects in the requested output folder for inspection.
    project = Project(args.output / 'rf_project')
    project.meta['classes'] = {'1': 'background', '2': 'layer', '3': 'void'}
    project.save()
    for seed in (10, 11):
        rgb, gt = synthetic(seed)
        key, _ = project.add_image(rgb, f'train_{seed}')
        project.save_labels(key, scribbles(gt, seed))
    forest = Forest()
    forest.train(project)
    forest.save(args.output / 'rf_model')
    restored = Forest()
    restored.load(args.output / 'rf_model')
    rgb, gt = synthetic(15)
    key, ann = project.add_image(rgb, 'unseen_test')
    assert key not in [r['image_sha256'] for r in forest.meta['training_images']]
    result = forest.predict(project, key, rgb, ann)
    np.testing.assert_array_equal(result['labels'], restored.predict(project, key, rgb, ann)['labels'])
    masks = np.stack([result['labels'] == cid for cid in (1, 2, 3)])
    assert np.all(masks.sum(axis=0) == 1)
    save_result(args.output / 'rf_result', rgb, ann, result, forest)
    report['rf'] = {'reload_identical': True, 'overlap_pixels': 0,
                    'training_samples': forest.meta['training_samples'],
                    'metrics': {str(cid): metrics(result['labels'] == cid, gt == cid) for cid in (1, 2, 3)},
                    'inference': result['info']}
    if args.checkpoint:
        import torch
        torch.set_num_threads(4)
        engine = Engine()
        engine.load(args.checkpoint, 'vit_b', 'cpu')
        root = Path(__file__).resolve().parent
        rgb = read_image(root / 'data/demo/synthetic.png')
        gt = np.asarray(Image.open(root / 'data/demo/synthetic_gt.png')) > 0
        initial = engine.refine(rgb, [[200, 170]], [1], [20, 100, 620, 250])
        refined = engine.refine(rgb, [[200, 170], [350, 172]], [1, 0], [20, 100, 620, 250], initial)
        assert refined['inference']['embedding_reused']
        assert refined['inference']['prior_source'] == 'sam_logits'
        binary = engine.refine(rgb, [[200, 170]], [1], [], {'mask': refined['mask'], 'initialized': True})
        assert binary['inference']['prior_source'] == 'binary_mask_seed'
        modes = []
        for mode in ('SAM grid', 'MatSAM Canny', 'MatSAM Otsu'):
            cfg = dict(mode=mode, grid=8, prompt_low=80, prompt_high=130,
                       blur_sigma=1., filter_strength='기본', otsu_fixed_blur=True)
            preview = prepare_preview(rgb, cfg)
            candidates = engine.automatic(rgb, **cfg, prepared=preview)
            assert candidates, f'No candidates in synthetic fixture: {mode}'
            np.testing.assert_array_equal(engine.last_auto_points, preview['points'])
            assert all(m['segmentation'].shape == rgb.shape[:2] for m in candidates)
            modes.append(dict(mode=mode, candidates=len(candidates), preview_points_equal=True))
        report['sam'] = dict(model=engine.info, initial=initial['inference'], refined=refined['inference'],
                             binary_seed=binary['inference'], metrics=metrics(refined['mask'], gt), modes=modes)
    else:
        report['sam'] = {'status': 'not run; supply --checkpoint'}
    (args.output / 'validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
