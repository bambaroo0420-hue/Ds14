from pathlib import Path
import hashlib,json,time
import numpy as np
from PIL import Image,ImageDraw
from refinement import context, image_key, valid_logits, mask_seed

def read_image(path):
    im=Image.open(path)
    if im.mode not in ('RGB','RGBA','L','P'):
        raise ValueError('8-bit PNG/JPG/TIFF only. Convert high-bit-depth images with a documented contrast window first.')
    return np.array(im.convert('RGB'))

def canny(rgb,low=40,high=100):
    import cv2
    if not 0 <= low < high <= 255: raise ValueError('0 <= low < high <= 255 required')
    return cv2.Canny(cv2.GaussianBlur(cv2.cvtColor(rgb,cv2.COLOR_RGB2GRAY),(5,5),1),low,high)>0

def boundary(mask):
    a=np.pad(mask,1,constant_values=False)
    inner=a[1:-1,1:-1]&a[:-2,1:-1]&a[2:,1:-1]&a[1:-1,:-2]&a[1:-1,2:]
    return mask & ~inner

def views(rgb,mask,edge):
    overlay=rgb.copy();overlay[mask]=(.55*rgb[mask]+.45*np.array([40,220,130])).astype('uint8')
    b=rgb.copy();b[boundary(mask)]=[0,255,120]
    e=rgb.copy();e[edge]=[255,65,40]
    return [rgb,overlay,b,e]

def metrics(pred,gt):
    pred=pred.astype(bool);gt=gt.astype(bool)
    if pred.shape!=gt.shape:raise ValueError('GT dimensions mismatch')
    inter=int((pred & gt).sum());union=int((pred|gt).sum());den=int(pred.sum()+gt.sum())
    return dict(iou=inter/union if union else 1.,dice=2*inter/den if den else 1.,both_empty=union==0)

class Engine:
    def __init__(self):self.predictor=None;self.loaded=None
    def load(self,checkpoint,variant='vit_h',device='cpu',decoder=''):
        import torch
        from segment_anything import sam_model_registry,SamPredictor
        path=Path(checkpoint)
        if not path.is_file():raise ValueError('Select a local SAM checkpoint')
        model=sam_model_registry[variant](checkpoint=str(path))
        if decoder:
            state=torch.load(decoder,map_location='cpu',weights_only=True)
            model.mask_decoder.load_state_dict(state,strict=True)
        self.model=model.to(device).eval();self.predictor=SamPredictor(self.model);self.loaded=None
        h=hashlib.sha256()
        with path.open('rb') as f:
            for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
        self.info=dict(model=variant,device=device,checkpoint_sha256=h.hexdigest(),decoder_sha256=hashlib.sha256(Path(decoder).read_bytes()).hexdigest() if decoder else None)
        return self.info
    def predict(self,rgb,points,labels,box):
        r=self.refine(rgb,points,labels,box)
        return r['mask'],r['inference']
    def refine(self,rgb,points,labels,box,previous=None):
        import torch
        if self.predictor is None:raise ValueError('Load SAM first')
        previous=previous or {};ctx=context(rgb,self.info)
        key=image_key(rgb);t=time.perf_counter();cached=self.loaded==key
        with torch.inference_mode():
            if not cached:self.predictor.set_image(rgb);self.loaded=key
            seed=None;origin='none'
            if previous.get('logits_context')==ctx and valid_logits(previous.get('logits')):
                seed=previous['logits'];origin='sam_logits'
            elif previous.get('initialized',False):
                mask=np.asarray(previous['mask'])
                if mask.shape!=rgb.shape[:2]:raise ValueError('Previous mask dimensions mismatch')
                seed=mask_seed(mask,self.predictor.input_size,self.model.image_encoder.img_size);origin='binary_mask_seed'
            if not points and not box and seed is None:raise ValueError('Add points or a target box first')
            m,s,logits=self.predictor.predict(point_coords=np.array(points) if points else None,
                point_labels=np.array(labels) if points else None,box=np.array(box) if box else None,
                mask_input=seed,multimask_output=False)
        if self.info['device']=='cuda':torch.cuda.synchronize()
        return dict(mask=m[0],logits=logits.copy(),logits_context=ctx,initialized=True,
            model=dict(self.info),reviewed=False,inference=dict(seconds=time.perf_counter()-t,
            embedding_reused=cached,predicted_iou=float(s[0]),measured_accuracy=False,prior_source=origin))
    def candidate_state(self,rgb,candidate,source):
        import torch
        result=dict(mask=candidate['segmentation'].copy(),points=[list(pt) for pt in candidate.get('point_coords',[])],
            labels=[1]*len(candidate.get('point_coords',[])),box=[],logits=None,logits_context=None,initialized=True,
            automatic_source=source,candidate_bbox=candidate.get('bbox'),model=source.get('model',{}))
        result['candidate_seed']='binary_mask_seed'
        if self.predictor is not None and source.get('model')==self.info and result['points']:
            with torch.inference_mode():
                key=image_key(rgb)
                if self.loaded!=key:self.predictor.set_image(rgb);self.loaded=key
                masks,scores,logits=self.predictor.predict(point_coords=np.array(result['points']),
                    point_labels=np.array(result['labels']),multimask_output=True)
            for index,mask in enumerate(masks):
                if np.array_equal(mask,result['mask']):
                    result.update(logits=logits[index:index+1].copy(),logits_context=context(rgb,self.info),candidate_seed='sam_logits')
                    break
        return result
    def automatic(self,rgb,mode='SAM grid',grid=8,prompt_low=80,prompt_high=130,blur_sigma=0.,filter_strength='기본',otsu_fixed_blur=True,prepared=None):
        import torch
        from segment_anything import SamAutomaticMaskGenerator
        from auto_tools import prepare_prompts,filter_values
        if self.predictor is None:raise ValueError('Load SAM first')
        from prompt_preview import prepare_preview,matches
        cfg=dict(mode=mode,grid=grid,prompt_low=prompt_low,prompt_high=prompt_high,blur_sigma=blur_sigma,filter_strength=filter_strength,otsu_fixed_blur=otsu_fixed_blur)
        if prepared is not None and not matches(prepared,rgb,cfg):raise ValueError('Preview settings/image mismatch; refresh preview')
        prepared=prepared if prepared is not None else prepare_preview(rgb,cfg)
        points,meta,proposal=prepared['points'],prepared['meta'],prepared['proposal']
        iou,stability=filter_values(filter_strength)
        kw=dict(points_per_side=None,point_grids=[points],points_per_batch=8,crop_n_layers=0,min_mask_region_area=0,pred_iou_thresh=iou,stability_score_thresh=stability,box_nms_thresh=.8)
        start=time.perf_counter()
        with torch.inference_mode():masks=SamAutomaticMaskGenerator(self.model,**kw).generate(rgb)
        if self.info['device']=='cuda':torch.cuda.synchronize()
        self.last_auto=dict(meta,filter_strength=filter_strength,pred_iou_thresh=iou,stability_score_thresh=stability,seconds=time.perf_counter()-start,candidate_count=len(masks),model=dict(self.info))
        self.last_auto_points=points;self.last_auto_proposal=proposal
        return sorted(masks,key=lambda m:m['area'],reverse=True)

def export(root,rgb,layers,edge,source,engine_info,settings):
    dest=Path(root)/time.strftime('%Y%m%d_%H%M%S');dest=dest.with_name(dest.name+'_'+str(time.time_ns())[-6:]);dest.mkdir(parents=True)
    Image.fromarray(rgb).save(dest/'original.png');Image.fromarray(edge.astype('uint8')*255).save(dest/'canny.png')
    records=[]
    for i,(name,l) in enumerate(layers.items()):
        stem=f'layer_{i:03d}';mask=l['mask'];Image.fromarray(mask.astype('uint8')*255).save(dest/(stem+'_mask.png'))
        panels=views(rgb,mask,edge);w=480;h=400;sheet=Image.new('RGB',(4*w,h+35),'white');draw=ImageDraw.Draw(sheet)
        for j,(a,title) in enumerate(zip(panels,['Original','Segmentation','Mask boundary (not interface)','Canny (not ground truth)'])):
            pic=Image.fromarray(a);pic.thumbnail((w,h));sheet.paste(pic,(j*w,35));draw.text((j*w+5,8),title,fill='black')
        sheet.save(dest/(stem+'_comparison.jpg'),quality=94)
        rec={k:v for k,v in l.items() if k not in ('mask','gt','history','logits')};rec.update(name=name,mask=stem+'_mask.png')
        if valid_logits(l.get('logits')):
            rec['logits_file']=stem+'_logits.npy';np.save(dest/rec['logits_file'],l['logits'],allow_pickle=False)
        if l.get('gt') is not None:
            Image.fromarray(l['gt'].astype('uint8')*255).save(dest/(stem+'_reference.png'));rec['reference']=stem+'_reference.png';rec['metrics']=metrics(mask,l['gt'])
        records.append(rec)
    overlap=np.sum([l['mask'] for l in layers.values()],axis=0)>1
    Image.fromarray(overlap.astype('uint8')*255).save(dest/'layer_overlap.png')
    record=dict(schema_version=2,source=source,shape_hw=list(rgb.shape[:2]),coordinate_system='original image pixels; x,y; no analysis resize',model=engine_info,settings=settings,layers=records,overlap_pixels=int(overlap.sum()),physical_interface_selected=False)
    (dest/'session.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    return dest
