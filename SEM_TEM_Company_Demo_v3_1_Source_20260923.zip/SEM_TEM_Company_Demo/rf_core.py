"""Offline scribble-trained multiclass random forest using OpenCV RTrees."""
from pathlib import Path
import hashlib,json,time
import cv2
import numpy as np
from PIL import Image,ImageDraw
from refinement import image_key
IGNORE=65535
FEATURE_CONFIG={'version':1,'sigmas':[1.,2.,4.,8.],'input':'RGB8 to gray /255','features':['mean','std','gx','gy','laplacian']}
COLORS=np.array([[50,180,255],[255,155,40],[70,220,120],[210,90,250],[255,90,135],[100,230,225],[220,215,60],[170,130,95]],np.uint8)

def write_json(path,value):
    path=Path(path);tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(path)

def features(rgb):
    gray=cv2.cvtColor(rgb,cv2.COLOR_RGB2GRAY).astype(np.float32)/255.;out=[gray]
    for sigma in FEATURE_CONFIG['sigmas']:
        mean=cv2.GaussianBlur(gray,(0,0),sigma)
        variance=np.maximum(cv2.GaussianBlur(gray*gray,(0,0),sigma)-mean*mean,0)
        out.extend([mean,np.sqrt(variance),cv2.Sobel(mean,cv2.CV_32F,1,0,ksize=3),cv2.Sobel(mean,cv2.CV_32F,0,1,ksize=3),cv2.Laplacian(mean,cv2.CV_32F,ksize=3)])
    return np.stack(out,axis=-1).astype(np.float32)

class Project:
    def __init__(self,folder):
        self.root=Path(folder);self.root.mkdir(parents=True,exist_ok=True)
        for name in ['data','annotations','cache','models','results']:(self.root/name).mkdir(exist_ok=True)
        path=self.root/'project.json'
        self.meta=json.loads(path.read_text(encoding='utf-8')) if path.exists() else dict(schema=1,classes={'1':'배경','2':'영역 A'},images={})
        self.save()
    @property
    def classes(self):return {int(k):v for k,v in self.meta['classes'].items()}
    def save(self):write_json(self.root/'project.json',self.meta)
    def log(self,record):
        with (self.root/'events.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(dict(time=time.strftime('%Y-%m-%dT%H:%M:%S'),**record),ensure_ascii=False)+'\n')
    def add_image(self,rgb,name):
        key=image_key(rgb);path=self.root/'data'/(key+'.png')
        if not path.exists():Image.fromarray(rgb).save(path)
        self.meta['images'].setdefault(key,{'name':name,'shape':list(rgb.shape)});self.save()
        a=self.root/'annotations'/(key+'.png')
        labels=np.asarray(Image.open(a),np.uint16).copy() if a.exists() else np.zeros(rgb.shape[:2],np.uint16)
        if labels.shape!=rgb.shape[:2]:raise ValueError('Annotation dimensions mismatch')
        return key,labels
    def save_labels(self,key,labels):
        dest=self.root/'annotations'/(key+'.png');tmp=dest.with_suffix('.tmp.png')
        Image.fromarray(labels.astype(np.uint16)).save(tmp);tmp.replace(dest)
    def cached_features(self,key,rgb):
        fingerprint=hashlib.sha256(json.dumps(FEATURE_CONFIG,sort_keys=True).encode()).hexdigest()[:12]
        path=self.root/'cache'/(key+'_'+fingerprint+'.npy')
        if path.exists():
            f=np.load(path,mmap_mode='r',allow_pickle=False)
            if f.shape==(*rgb.shape[:2],21) and f.dtype==np.float32:return f
        f=features(rgb);np.save(path,f,allow_pickle=False);return f
    def collect(self,cap=3000):
        rng=np.random.default_rng(42);xs=[];ys=[];records=[]
        for key,item in self.meta['images'].items():
            ap=self.root/'annotations'/(key+'.png')
            if not ap.exists():continue
            labels=np.asarray(Image.open(ap),np.uint16);positions=[]
            for cid in self.classes:
                idx=np.flatnonzero(labels.ravel()==cid)
                if len(idx):positions.extend(rng.choice(idx,min(cap,len(idx)),replace=False).tolist())
            if not positions:continue
            rgb=np.asarray(Image.open(self.root/'data'/(key+'.png')).convert('RGB'));f=self.cached_features(key,rgb)
            xs.append(np.asarray(f).reshape(-1,f.shape[-1])[positions]);ys.append(labels.ravel()[positions])
            records.append(dict(image_sha256=key,name=item['name'],annotation_sha256=hashlib.sha256(ap.read_bytes()).hexdigest(),sample_count=len(positions)))
        if not xs:raise ValueError('각 클래스에 브러시 주석을 먼저 그려주세요.')
        x=np.concatenate(xs);y=np.concatenate(ys);keep=[]
        for cid in self.classes:
            idx=np.flatnonzero(y==cid)
            if len(idx)<5:raise ValueError(f"클래스 {cid} ({self.classes[cid]})에 최소 5개 주석 픽셀이 필요합니다. 미사용 클래스도 주석하거나 새 프로젝트를 만드세요.")
            keep.extend(rng.choice(idx,min(15000,len(idx)),replace=False).tolist())
        if len(self.classes)<2:raise ValueError('두 클래스 이상 필요')
        return x[keep].astype(np.float32),y[keep].astype(np.int32),records

class Forest:
    def train(self,project):
        start=time.perf_counter();x,y,records=project.collect();cv2.setRNGSeed(42)
        model=cv2.ml.RTrees_create();model.setMaxDepth(18);model.setMinSampleCount(3);model.setMaxCategories(256)
        model.setCalculateVarImportance(True);model.setTermCriteria((cv2.TERM_CRITERIA_MAX_ITER,80,0))
        if not model.train(x,cv2.ml.ROW_SAMPLE,y):raise ValueError('RF training failed')
        self.model=model;self.meta=dict(schema=1,algorithm='OpenCV RTrees',opencv=cv2.__version__,feature_config=FEATURE_CONFIG,classes=project.meta['classes'].copy(),training_images=records,training_samples=len(y),sample_counts={str(c):int((y==c).sum()) for c in np.unique(y)},trees=80,max_depth=18,seed=42,seconds=time.perf_counter()-start)
        project.log(dict(event='train',details=self.meta));return self.meta
    def predict(self,project,key,rgb,annotations,threshold=.55,margin=.15):
        if not hasattr(self,'model'):raise ValueError('모델을 먼저 학습하거나 불러오세요.')
        start=time.perf_counter();f=project.cached_features(key,rgb);flat=np.asarray(f).reshape(-1,f.shape[-1])
        pred=np.zeros(len(flat),np.uint16);confidence=np.zeros(len(flat),np.float32);gap=confidence.copy()
        for begin in range(0,len(flat),32768):
            votes=self.model.getVotes(np.ascontiguousarray(flat[begin:begin+32768]),0)
            ids=votes[0].astype(np.uint16);counts=votes[1:].astype(np.float32);prob=counts/np.maximum(counts.sum(axis=1,keepdims=True),1)
            order=np.sort(prob,axis=1);pred[begin:begin+len(prob)]=ids[np.argmax(prob,axis=1)];confidence[begin:begin+len(prob)]=order[:,-1];gap[begin:begin+len(prob)]=order[:,-1]-order[:,-2]
        shape=rgb.shape[:2];labels=pred.reshape(shape);confidence=confidence.reshape(shape);gap=gap.reshape(shape);excluded=annotations==IGNORE
        labels[excluded]=0;review=((confidence<threshold)|(gap<margin))&~excluded
        return dict(labels=labels,confidence=confidence,review=review,info=dict(seconds=time.perf_counter()-start,threshold=threshold,margin=margin,review_pixels=int(review.sum()),excluded_pixels=int(excluded.sum()),overlap_pixels=0,note='Vote fractions are not calibrated accuracy; predictions are not GT'))
    def save(self,folder):
        folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);self.model.save(str(folder/'forest.xml'))
        meta=dict(self.meta,model_sha256=hashlib.sha256((folder/'forest.xml').read_bytes()).hexdigest());write_json(folder/'model.json',meta)
    def load(self,folder):
        folder=Path(folder);meta=json.loads((folder/'model.json').read_text(encoding='utf-8'))
        if meta['feature_config']!=FEATURE_CONFIG:raise ValueError('Feature version mismatch')
        if hashlib.sha256((folder/'forest.xml').read_bytes()).hexdigest()!=meta['model_sha256']:raise ValueError('Model file checksum mismatch')
        model=cv2.ml.RTrees_load(str(folder/'forest.xml'))
        if model.empty() or model.getVarCount()!=21:raise ValueError('Invalid forest')
        self.model=model;self.meta=meta;return meta

def overlay(rgb,labels,review=None):
    a=rgb.copy()
    for cid in np.unique(labels):
        if cid in (0,IGNORE):continue
        mask=labels==cid;a[mask]=(.45*a[mask]+.55*COLORS[(int(cid)-1)%len(COLORS)]).astype(np.uint8)
    a[labels==IGNORE]=[255,0,255]
    if review is not None:
        yy,xx=np.indices(labels.shape);a[review&((xx+yy)%6<2)]=[255,255,0]
    return a

def save_result(folder,rgb,annotations,result,forest):
    out=Path(folder);out.mkdir(parents=True,exist_ok=True)
    Image.fromarray(rgb).save(out/'original.png');Image.fromarray(annotations).save(out/'scribbles.png');Image.fromarray(result['labels']).save(out/'labelmap.png')
    Image.fromarray(result['review'].astype(np.uint8)*255).save(out/'review_required.png');np.save(out/'vote_fraction.npy',result['confidence'],allow_pickle=False)
    classes={int(k):v for k,v in forest.meta['classes'].items()}
    for cid in classes:Image.fromarray((result['labels']==cid).astype(np.uint8)*255).save(out/f'class_{cid:03d}_mask.png')
    h,w=rgb.shape[:2];sheet=Image.new('RGB',(3*w,h+40),'white');draw=ImageDraw.Draw(sheet)
    for i,(title,img) in enumerate([('Original + training scribbles',overlay(rgb,annotations)),('RF prediction (NOT ground truth)',overlay(rgb,result['labels'])),('Yellow hatch: review required',overlay(rgb,result['labels'],result['review']))]):
        sheet.paste(Image.fromarray(img),(i*w,40));draw.text((i*w+5,10),title,fill='black')
    sheet.save(out/'comparison.jpg',quality=94)
    write_json(out/'result.json',dict(classes=classes,info=result['info'],model=forest.meta,label_zero='excluded/unassigned, NOT background',scribble_zero='unlabeled, NOT background',scribble_65535='excluded',image_sha256=image_key(rgb)))
    return out
