@echo off
cd /d "%~dp0"
py -3.13 -m venv .venv
if errorlevel 1 goto fail
.venv\Scripts\python -m pip install --no-index --find-links wheelhouse -r environment-lock-win-py313.txt
if errorlevel 1 goto fail
echo Installation complete. Run start.bat
pause
exit /b 0
:fail
echo Installation failed. Check Python 3.13 x64 and wheelhouse.
pause
exit /b 1
