from pathlib import Path
import json,time
import numpy as np
import torch
from core import *
ROOT=Path(__file__).resolve().parent
torch.set_num_threads(min(4,torch.get_num_threads()))
rgb=read_image(ROOT/'data/demo/synthetic.png');engine=Engine();engine.load(ROOT/'checkpoints/sam_vit_b_01ec64.pth','vit_b','cpu')
mask,first=engine.predict(rgb,[[100,175],[100,75],[100,290]],[1,0,0],[0,110,639,235]);mask2,second=engine.predict(rgb,[[200,175],[200,75],[200,290]],[1,0,0],[0,110,639,235]);assert second['embedding_reused']
start=time.perf_counter();candidates=engine.automatic(rgb,'MatSAM prompts',grid=4);auto_seconds=time.perf_counter()-start
assert mask.shape==rgb.shape[:2];gt=np.array(Image.open(ROOT/'data/demo/synthetic_gt.png'))>0
out=export(ROOT/'results',rgb,{'middle':dict(mask=mask2,gt=gt,points=[[200,175],[200,75],[200,290]],labels=[1,0,0],box=[0,110,639,235],reviewed=False)},canny(rgb),{'filename':'synthetic.png'},engine.info,{'canny':[40,100]})
report=dict(model=engine.info,first=first,second=second,automatic_candidates=len(candidates),automatic_seconds=auto_seconds,output=str(out.relative_to(ROOT)),note='Synthetic only; not company accuracy. CPU ViT-B actual smoke test; ViT-H not tested locally.')
(ROOT/'VALIDATION.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
