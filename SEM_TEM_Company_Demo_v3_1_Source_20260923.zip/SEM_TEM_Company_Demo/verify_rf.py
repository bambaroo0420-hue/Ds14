from pathlib import Path
import json,time
import numpy as np
import cv2
from PIL import Image
from rf_core import Project,Forest,save_result,write_json
ROOT=Path(__file__).resolve().parent

def synthetic(seed):
    rng=np.random.default_rng(seed);h,w=240,360;y,x=np.indices((h,w));shift=(seed%3-1)*8
    top=65+shift+7*np.sin(x/45);bottom=165+shift+8*np.sin(x/55)
    gt=np.ones((h,w),np.uint16);gt[(y>top)&(y<bottom)]=2
    cx=160+(seed%4)*15;cy=112+shift;gt[((x-cx)/17)**2+((y-cy)/12)**2<1]=3
    mean=np.choose(gt-1,[55.,145.,15.]);gray=np.clip(mean+rng.normal(0,9,(h,w)),0,255).astype(np.uint8)
    return np.repeat(gray[:,:,None],3,axis=2),gt

def scribbles(gt,seed):
    rng=np.random.default_rng(seed);ann=np.zeros_like(gt)
    for cid in [1,2,3]:
        safe=cv2.erode((gt==cid).astype(np.uint8),np.ones((7,7),np.uint8));coords=np.argwhere(safe)
        for idx in rng.choice(len(coords),min(12,len(coords)),replace=False):
            y,x=coords[idx];cv2.circle(ann,(int(x),int(y)),2,int(cid),-1)
    return ann

if __name__=='__main__':
    cv2.setNumThreads(4);project=Project(ROOT/'rf_example_project');project.meta['classes']={'1':'배경','2':'밝은 층','3':'어두운 void 후보'};project.save()
    for seed in [10,11]:
        rgb,gt=synthetic(seed);key,_=project.add_image(rgb,f'synthetic_train_{seed}.png');project.save_labels(key,scribbles(gt,seed))
    forest=Forest();forest.train(project);forest.save(project.root/'models/example')
    rgb,gt=synthetic(15);data=ROOT/'data/rf_demo';data.mkdir(parents=True,exist_ok=True);Image.fromarray(rgb).save(data/'test.png');Image.fromarray(gt).save(data/'test_gt.png')
    key,ann=project.add_image(rgb,'synthetic_unseen_test.png');assert not ann.any()
    result=forest.predict(project,key,rgb,ann);restored=Forest();restored.load(project.root/'models/example');again=restored.predict(project,key,rgb,ann)
    np.testing.assert_array_equal(result['labels'],again['labels']);assert key not in [r['image_sha256'] for r in forest.meta['training_images']]
    scores={}
    for cid in [1,2,3]:
        a=result['labels']==cid;b=gt==cid;scores[str(cid)]=dict(iou=float((a&b).sum()/(a|b).sum()),dice=float(2*(a&b).sum()/(a.sum()+b.sum())))
    masks=np.stack([result['labels']==cid for cid in [1,2,3]]);assert np.all(masks.sum(axis=0)==1)
    out=ROOT/'results/rf_v3';save_result(out,rgb,ann,result,forest);Image.fromarray(gt).save(out/'synthetic_gt.png')
    write_json(out/'validation.json',dict(dataset='Synthetic ONLY; not semiconductor TEM accuracy',training_images=len(forest.meta['training_images']),test_image_in_training=False,model_reload_identical=True,overlap_pixels=0,metrics=scores,inference=result['info'],training=forest.meta))
    print(json.dumps(dict(metrics=scores,training_seconds=forest.meta['seconds'],inference=result['info']),indent=2))
