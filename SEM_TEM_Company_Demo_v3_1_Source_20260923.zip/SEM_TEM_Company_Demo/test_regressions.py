"""Regression coverage for the v3.1 release."""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import tkinter as tk
import numpy as np

from app import App
from rf_app import RFApp
from rf_core import Project


class ReleaseRegressionTests(unittest.TestCase):
    def test_startup_example_does_not_replace_loaded_image(self):
        root = tk.Tk()
        root.withdraw()
        try:
            app = App(root)
            app.rgb = np.full((10, 20, 3), 123, np.uint8)
            with patch.object(app, 'open') as opened:
                app.open_initial_example()
                opened.assert_not_called()
                app.rgb = None
                app.open_initial_example()
                opened.assert_called_once()
        finally:
            root.destroy()

    def test_project_switch_clears_undo_and_pending_stroke(self):
        root = tk.Tk()
        root.withdraw()
        try:
            with tempfile.TemporaryDirectory() as folder:
                old = Path(folder) / 'old'
                new = Path(folder) / 'new'
                with patch('rf_app.Project', side_effect=lambda path: Project(old)):
                    app = RFApp(root)
                app.history.append(app.labels.copy())
                app.previous = (1, 1)
                with patch('rf_app.filedialog.askdirectory', return_value=str(new)):
                    app.open_project()
                self.assertEqual(app.history, [])
                self.assertIsNone(app.labels)
                self.assertFalse(hasattr(app, 'previous'))
                app.undo()
                self.assertEqual(list((new / 'annotations').iterdir()), [])
        finally:
            root.destroy()


if __name__ == '__main__':
    unittest.main()
