import unittest
import numpy as np
from auto_tools import prepare_prompts,multi_overlay,filter_values
from matsam_prompt import PromptGenerator
class AutoTests(unittest.TestCase):
    def image(self):
        a=np.zeros((120,360,3),np.uint8);a[30:90,180:300]=70;return a
    def test_repeat_and_rectangular(self):
        g=PromptGenerator(self.image(),n_per_side_base=8);a=g.generate_prompt_points()[0];b=g.generate_prompt_points()[0];np.testing.assert_array_equal(a,b);self.assertTrue(((a>=0)&(a<=1)).all())
    def test_grid_modes(self):
        for n in [8,16,32]:
            pts,meta,_=prepare_prompts(self.image(),'SAM grid',n);self.assertEqual(len(pts),n*n);self.assertEqual(meta['centroid_points'],0)
    def test_canny_control_and_otsu(self):
        a=self.image();a[30:90,180:300]=30
        _,lo,_=prepare_prompts(a,'MatSAM Canny',8,5,10);_,hi,_=prepare_prompts(a,'MatSAM Canny',8,240,255);self.assertGreater(lo['centroid_points'],hi['centroid_points'])
        pts,meta,image=prepare_prompts(a,'MatSAM Otsu');self.assertTrue(meta['otsu_two_groups']);self.assertGreater(meta['centroid_points'],0);self.assertTrue(set(np.unique(image))<=set([0,255]))
    def test_overlap_and_empty(self):
        a=self.image();m=np.zeros(a.shape[:2],bool);m[10:20]=True
        out,c=multi_overlay(a,[m,m]);self.assertTrue((out[m]==[255,255,0]).all());self.assertTrue((c[m]==2).all())
        _,c=multi_overlay(a,[]);self.assertEqual(c.sum(),0)
    def test_bad_settings(self):
        with self.assertRaises(ValueError):prepare_prompts(self.image(),'MatSAM Canny',8,130,80)
        with self.assertRaises(ValueError):filter_values('invalid')
if __name__=='__main__':unittest.main()
