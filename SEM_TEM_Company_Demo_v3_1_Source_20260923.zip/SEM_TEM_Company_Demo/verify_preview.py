from pathlib import Path
import json
import torch
import numpy as np
from core import Engine,read_image
from prompt_preview import prepare_preview,save_preview
ROOT=Path(__file__).resolve().parent
if __name__=='__main__':
    torch.set_num_threads(4);rgb=read_image(ROOT/'data/demo/synthetic.png')
    engine=Engine();engine.load(ROOT/'checkpoints/sam_vit_b_01ec64.pth','vit_b','cpu')
    results=[]
    for mode in ['MatSAM Canny','MatSAM Otsu']:
        cfg=dict(mode=mode,grid=8,prompt_low=80,prompt_high=130,blur_sigma=1.0,filter_strength='기본',otsu_fixed_blur=True)
        preview=prepare_preview(rgb,cfg);dest=ROOT/'results/preview_v2_2'/mode.replace(' ','_');save_preview(preview,dest)
        masks=engine.automatic(rgb,**cfg,prepared=preview)
        np.testing.assert_array_equal(engine.last_auto_points,preview['points'])
        assert engine.last_auto['points_sha256']==preview['meta']['points_sha256']
        results.append(dict(mode=mode,candidates=len(masks),preview_execution_equal=True,metadata=engine.last_auto))
    out=ROOT/'results/preview_v2_2/validation.json';out.write_text(json.dumps(dict(dataset='synthetic only',results=results),ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(results,ensure_ascii=False))
