import unittest,tempfile,json
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from core import Engine,export
from refinement import *

class RefinementTests(unittest.TestCase):
    def test_undo_complete_and_independent(self):
        l=dict(mask=np.zeros((8,12),bool),points=[[1,2]],labels=[1],box=[0,0,9,7],logits=np.ones((1,256,256)),history=[],gt=None,reviewed=True)
        remember(l);l['mask'][1,1]=True;l['points'][0][0]=9;l['logits'][:]=0;l['box']=[]
        undo(l);self.assertFalse(l['mask'].any());self.assertEqual(l['points'],[[1,2]]);self.assertTrue(l['logits'].all());self.assertEqual(l['box'],[0,0,9,7]);self.assertTrue(l['reviewed'])
    def test_seed_padding_and_void(self):
        for shape,size in [((80,160),(512,1024)),((160,80),(1024,512))]:
            m=np.ones(shape,bool);m[shape[0]//4:shape[0]*3//4,shape[1]//4:shape[1]*3//4]=False
            seed=mask_seed(m,size);self.assertTrue(valid_logits(seed));self.assertGreater(seed[0,8,8],0)
            self.assertLess(seed[0,size[0]//8,size[1]//8],0)
            if size[0]<1024:self.assertTrue((seed[0,140:,:]<0).all())
            else:self.assertTrue((seed[0,:,140:]<0).all())
        self.assertTrue((mask_seed(np.zeros((10,20)),(512,1024))<0).all())
    def engine(self):
        e=Engine();e.info=dict(model='fake',device='cpu',checkpoint_sha256='a',decoder_sha256=None)
        e.model=SimpleNamespace(image_encoder=SimpleNamespace(img_size=1024));self.inputs=[]
        def predict(**kwargs):
            self.inputs.append(kwargs.get('mask_input'))
            return np.ones((1,10,20),bool),np.array([.8]),np.ones((1,256,256),np.float32)
        e.predictor=SimpleNamespace(input_size=(512,1024),set_image=lambda rgb:None,predict=predict)
        return e
    def test_reuse_and_invalidation(self):
        e=self.engine();rgb=np.zeros((10,20,3),np.uint8)
        a=e.refine(rgb,[[2,2]],[1],[]);self.assertIsNone(self.inputs[-1])
        b=e.refine(rgb,[[2,2],[4,4]],[1,0],[],a);self.assertEqual(b['inference']['prior_source'],'sam_logits');self.assertTrue(b['inference']['embedding_reused'])
        e.info['decoder_sha256']='changed';c=e.refine(rgb,[],[],[],b);self.assertEqual(c['inference']['prior_source'],'binary_mask_seed')
        rgb[0,0]=1;d=e.refine(rgb,[],[],[],b);self.assertFalse(d['inference']['embedding_reused']);self.assertEqual(d['inference']['prior_source'],'binary_mask_seed')
    def test_export_reload_logits(self):
        e=self.engine();rgb=np.zeros((10,20,3),np.uint8);r=e.refine(rgb,[[1,1]],[1],[]);r.update(points=[[1,1]],labels=[1],box=[],history=[],gt=None)
        with tempfile.TemporaryDirectory() as tmp:
            dest=export(tmp,rgb,{'one':r},np.zeros((10,20),bool),{},e.info,{})
            doc=json.loads((dest/'session.json').read_text(encoding='utf-8'));self.assertEqual(doc['schema_version'],2)
            value=np.load(dest/doc['layers'][0]['logits_file'],allow_pickle=False);np.testing.assert_array_equal(value,r['logits'])
    def test_ui_restore_v2_and_v21(self):
        import tkinter as tk
        from unittest.mock import patch
        from app import App
        root=tk.Tk();root.withdraw()
        try:
            app=App(root);rgb=np.zeros((10,20,3),np.uint8);e=self.engine()
            layer=e.refine(rgb,[[1,1]],[1],[]);layer.update(points=[[1,1]],labels=[1],box=[],gt=None)
            with tempfile.TemporaryDirectory() as tmp:
                dest=export(tmp,rgb,{'test':layer},np.zeros((10,20),bool),{},e.info,{'canny':[40,100]})
                with patch('app.filedialog.askopenfilename',return_value=str(dest/'session.json')),patch('app.messagebox.showerror') as err:
                    app.restore();err.assert_not_called();np.testing.assert_array_equal(app.current()['logits'],layer['logits'])
                    doc=json.loads((dest/'session.json').read_text(encoding='utf-8'));doc['schema_version']=1
                    for k in ['logits_file','logits_context','initialized']:doc['layers'][0].pop(k,None)
                    (dest/'session.json').write_text(json.dumps(doc),encoding='utf-8')
                    app.restore();err.assert_not_called();self.assertIsNone(app.current()['logits']);self.assertTrue(app.current()['initialized'])
                    result=e.refine(app.rgb,[[1,1]],[1],[],app.current());self.assertEqual(result['inference']['prior_source'],'binary_mask_seed')
        finally:root.destroy()

    def test_ui_preview_apply_cancel_undo(self):
        import tkinter as tk
        from app import App
        root=tk.Tk();root.withdraw()
        try:
            app=App(root);app.open(Path(__file__).parent/'data/demo/synthetic.png');app.engine=self.engine()
            # Use dimensions expected by mock.
            app.rgb=np.zeros((10,20,3),np.uint8);app.new_layer('test');app.edges=np.zeros((10,20),bool)
            app.current()['points']=[[2,2]];app.current()['labels']=[1]
            app.task=lambda work,done:done(work())
            app.predict();self.assertFalse(app.current()['mask'].any());self.assertIsNotNone(app.pending)
            app.clear();self.assertEqual(app.current()['points'],[[2,2]])
            app.cancel_correction();self.assertFalse(app.current()['mask'].any())
            app.predict();app.apply_correction();self.assertTrue(app.current()['mask'].all());self.assertTrue(valid_logits(app.current()['logits']))
            app.undo();self.assertFalse(app.current()['mask'].any());self.assertIsNone(app.current()['logits'])
            app.predict();app.apply_correction();app.mode.set('마스크 지우기');app.paint([3,3]);self.assertIsNone(app.current()['logits'])
        finally:root.destroy()

if __name__=='__main__':unittest.main()
