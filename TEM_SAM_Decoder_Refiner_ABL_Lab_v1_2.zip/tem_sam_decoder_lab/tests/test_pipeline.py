"""CPU integration tests with official SAM modules at a tiny random size.
These validate dataflow/gradients/artifacts, NOT pretrained ViT-H or TEM accuracy.
Run: python -m unittest discover -s tests -v
"""
import csv,json,tempfile,unittest
from pathlib import Path
import numpy as np
from PIL import Image
import torch
from torch import nn
from temlab.models import Engine,ResidualRefiner,Predictor,sam_model_registry
from temlab.losses import ABL,segmentation_loss
from temlab.data import read_manifest,targets,grid_prompts
from temlab.metrics import overlap,boundary_metrics,candidate_metrics
from temlab.train import train_all
from temlab.evaluate import compare_all
from temlab.export import export_bundle
from segment_anything.modeling import Sam,ImageEncoderViT,PromptEncoder,MaskDecoder,TwoWayTransformer

torch.set_num_threads(1)


def tiny_sam(checkpoint=None):
    m=Sam(image_encoder=ImageEncoderViT(img_size=64,patch_size=8,in_chans=3,embed_dim=32,depth=2,
             num_heads=4,mlp_ratio=2,out_chans=32,window_size=4,global_attn_indexes=(1,)),
          prompt_encoder=PromptEncoder(embed_dim=32,image_embedding_size=(8,8),input_image_size=(64,64),mask_in_chans=8),
          mask_decoder=MaskDecoder(transformer_dim=32,transformer=TwoWayTransformer(depth=2,embedding_dim=32,mlp_dim=64,num_heads=4),
                                  iou_head_depth=2,iou_head_hidden_dim=32),
          pixel_mean=[123.675,116.28,103.53],pixel_std=[58.395,57.12,57.375])
    if checkpoint:m.load_state_dict(torch.load(checkpoint,weights_only=True))
    return m.eval()


class TestPipeline(unittest.TestCase):
    def test_abl_grad_and_ignored(self):
        torch.manual_seed(4)
        gt=torch.zeros(1,24,24);gt[:,7:18,8:17]=1
        valid=torch.ones_like(gt,dtype=torch.bool);valid[:,:,:3]=False
        z=torch.randn(1,1,24,24,requires_grad=True)
        edge=ABL(label_smoothing=.2)(torch.cat([torch.zeros_like(z),z],1),gt.long(),valid)
        self.assertTrue(torch.isfinite(edge));edge.backward()
        self.assertGreater(float(z.grad.abs().sum()),0)
        z2=torch.zeros(1,1,24,24,requires_grad=True)
        loss,_=segmentation_loss(z2,torch.zeros_like(gt),valid,ABL(),.1)
        loss.backward();self.assertTrue(torch.isfinite(loss))
        self.assertEqual(float(z2.grad[:,:,:,:3].abs().sum()),0.)

    def test_refiner_initial_identity(self):
        m=ResidualRefiner(8);im=torch.rand(1,3,31,37);z=torch.randn(1,1,31,37)
        self.assertTrue(torch.equal(m(im,z),z))

    def test_metrics_missing_and_perfect(self):
        gt=np.zeros((32,32),bool);gt[8:24,8:24]=True;valid=np.ones_like(gt)
        self.assertEqual(overlap(gt,gt,valid)['dice'],1.)
        self.assertEqual(boundary_metrics(gt,gt,valid)['boundary_f1'],1.)
        cfg={'match_iou':.5,'boundary_tolerance_px':2,'small_region_area_px':1024}
        s,_=candidate_metrics([],[(1,gt)],valid,cfg)
        self.assertEqual(s['region_recall'],0);self.assertEqual(s['mean_best_iou'],0)

    def test_all_four_train_eval_export(self):
        sam_model_registry['vit_test']=tiny_sam
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);base=p/'tiny_sam.pt';torch.save(tiny_sam().state_dict(),base)
            cfg=json.loads((Path(__file__).parents[1]/'config.example.json').read_text())
            cfg.update(sam_checkpoint=str(base),model_type='vit_test',device='cpu',encoder_amp=False,
                       manifest=str(p/'manifest.csv'),cache_dir=str(p/'cache'),output_dir=str(p/'runs'),
                       epochs=2,patience=3,abl_warmup_epochs=0,refine_side=64,loss_side=64,refiner_width=8,
                       prompts_per_region=1,background_samples_per_image=1,grid_points_per_side=2)
            rows=[]
            for i,split in enumerate(['train','train','val','test']):
                a=np.random.default_rng(i).integers(0,255,(48,64,3),dtype=np.uint8)
                gt=np.zeros((48,64),np.uint8);gt[8:24,10:30]=1;gt[28:42,36:56]=2;gt[-2:]=255
                Image.fromarray(a).save(p/f'i{i}.png');Image.fromarray(gt).save(p/f'g{i}.png')
                rows.append(dict(image_id=f'i{i}',image=str(p/f'i{i}.png'),mask=str(p/f'g{i}.png'),group=f's{i}',split=split))
            with open(cfg['manifest'],'w',newline='') as f:
                w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
            paths=train_all(cfg)
            self.assertEqual(len(paths),4)
            results=compare_all(cfg,paths)
            self.assertEqual(len(results),5)
            for path in paths.values():
                locked=dict(cfg,mask_threshold=.55)
                bundle=export_bundle(path,p/('export_'+Path(path).parent.name),inference_cfg=locked)
                predictor=Predictor(base,Path(bundle)/'adaptation.pt',device='cpu',cache_dir=p/'ui_cache')
                self.assertEqual(predictor.engine.cfg['mask_threshold'],.55)
                image=np.asarray(Image.open(p/'i3.png'));predictor.set_image(image)
                out=predictor.predict(points=[[15,15]],labels=[1])
                self.assertEqual(out['mask'].shape,(48,64))
                self.assertTrue(np.isfinite(out['probability']).all())
            # Group leakage must be rejected.
            rows[-1]['group']=rows[0]['group']
            with open(cfg['manifest'],'w',newline='') as f:
                w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
            with self.assertRaises(ValueError):read_manifest(cfg['manifest'])


if __name__=='__main__':unittest.main()
