# TEM SAM Decoder Lab v0.1

회사 GPU 서버에서 원본 TEM + semantic GT로 학습하고, 별도 이미지에서 시험하는 Python / Jupyter 패키지입니다.
한 GPU에서 순차 실행합니다. 현재 GUI나 웹 서버를 만드는 패키지는 아니며, 추론 연결용 Python API를 제공합니다.

## 무엇을 비교하나

| 이름 | 고정되는 부분 | 학습되는 부분 | 손실 |
|---|---|---|---|
| baseline | SAM 전체 | 없음 | 없음 |
| decoder_noabl | image/prompt encoder, IoU head | 기존 mask decoder | BCE + Dice |
| decoder_abl | 동일 | 기존 mask decoder | BCE + Dice + adapted ABL |
| refiner_noabl | SAM 전체 | 별도 ResidualRefiner | BCE + Dice |
| refiner_abl | SAM 전체 | 별도 ResidualRefiner | BCE + Dice + adapted ABL |

ABL warmup 이후부터 가중치를 적용하고, ABL 실험의 best.pt는 ABL이 켜진 epoch 중에서만 선택합니다.
ABL 유무 두 조건은 같은 seed/초기 가중치/데이터 순서/prompt 샘플링을 사용합니다.
decoder와 refiner 사이의 학습률은 구조가 달라 기본값이 다릅니다. 검증 데이터에서만 조정하세요.

별도 refiner: RGB 3채널 + SAM foreground 확률 1채널 → 2단계 down/up CNN → logit 잔차.
기본 width=16, 약 119k 파라미터입니다. 최종 head를 0으로 초기화하여 처음에는 입력 SAM logit을 유지합니다.
refine_side에서 축소/확대하므로 원해상도 SAM 출력과 완전히 동일한 픽셀 결과라는 뜻은 아닙니다.

## 실행 순서

1. 압축을 풀고 `weights/`에 보유한 `sam_vit_h_4b8939.pth`를 넣습니다.
2. 서버 CUDA/드라이버에 맞는 **torch + torchvision 쌍**이 설치된 Python 환경을 사용합니다.
3. 같은 환경에서 `python -m pip install -r requirements.txt`를 실행합니다. 사내 패키지 미러 또는 wheelhouse를 사용할 수 있습니다.
4. Jupyter에서 그 Python 환경을 커널로 선택합니다.
5. `notebooks/00_data_setup.ipynb` → `01_train.ipynb` → `02_evaluate_export.ipynb` 순서로 실행합니다.

SAM Python 소스를 포함했으므로 git clone, pip git+URL, micro-SAM/elf/xxhash는 필요하지 않습니다.
모델 가중치 및 PyTorch/wheel 파일은 포함하지 않았습니다. 기본 코드는 실행 중 인터넷에 접속하지 않습니다.
기존 CUDA 환경을 무작정 CPU PyTorch로 덮어쓰지 마세요.

## 원본과 GT

`data/images/sample01.png`와 `data/masks/sample01.png`처럼 파일 stem을 맞춥니다.
이미지: PNG/JPG/TIF 등, 기본 RGB/그레이스케일 uint8. 16-bit는 config의 preprocessing을
`percentile_1_99`로 명시해야 합니다. 이때 이미지별 percentile 변환은 추론에도 동일하게 적용됩니다.
GT: 같은 픽셀 크기의 클래스 ID 이미지. 기본 배경=0, 층=1/2/…, 미표기=255.
**표기하지 않은 영역을 배경=0으로 두지 마세요.** 모르는 영역은 ignore=255로 처리합니다.

- 팔레트 PNG는 색이 아니라 저장된 index를 읽습니다.
- RGB GT는 `rgb_label_map`에 모든 색과 클래스 ID를 지정합니다.
- 0/255 이진 GT라면 기본값에서 255가 무시됩니다. `label_map={"0":0,"255":1}`을 명시하세요.
- `class_names`의 ID를 실제 GT와 일치시키세요. 모델이 클래스 이름을 예측한다는 뜻은 아닙니다.
- 스케일바/글자/분석 제외 부분은 GT의 ignore label로 두거나, 모든 방법에 동일한 고정 ROI를 사용합니다.
- 넓은 ROI를 자르는 경우 이미지와 GT를 함께 자르고 같은 원본/시료의 group ID를 공유합니다.

Semantic GT에서 클래스별 연결 영역을 자동 추출하여 이진 학습 대상을 만듭니다.
동일 클래스의 서로 닿은 셀은 하나의 영역이 됩니다. 진짜 instance GT로 간주하지 않습니다.
`min_gt_area` 미만 영역은 학습/평가에서 제외되므로 얇은 관심층이 빠지지 않도록 먼저 확인하세요.
수백만 픽셀이 있다고 독립 이미지가 수백만 개 있는 것은 아닙니다.

## 데이터 분할

00 노트북에서 manifest를 생성한 뒤 CSV의 group과 split을 직접 지정합니다.
`image_id,image,mask,group,split`이 필요하며, split은 train/val/test입니다.
절대 경로와 manifest 상대 경로 모두 지원합니다. 모델 학습은 train만, best 선택은 val만 사용합니다.
30장 예: 20/5/5, 50장 예: 35/7/8. **장수보다 시료 단위 분리가 우선**입니다.
같은 wafer/시료/연속 촬영/동일 원본 crop은 평가하려는 일반화 수준에 맞게 같은 group으로 묶으세요.
코드는 그룹 중복과 동일 픽셀 이미지 중복을 확인하지만 시료 관계를 스스로 알아낼 수는 없습니다.

## 학습 방식과 속도

encoder 고정, 이미지별 encoder 특징을 디스크에 캐시합니다. 키는 원본 픽셀과 base checkpoint hash에 의존합니다.
첫 인코딩은 오래 걸리고 이후 재사용됩니다. checkpoint는 최초 로딩 때 SHA256을 계산하므로 수 초가 더 걸릴 수 있습니다.
SAM decoder로 역전파할 때 `SamPredictor.predict()`의 no_grad 경로를 쓰지 않고 직접 decoder를 호출합니다.
encoder에만 선택적 fp16 autocast를 적용하고 decoder/refiner/loss는 fp32로 학습합니다.
GPU에서 동시 4개 모델을 올리지 않고 한 조건씩 실행합니다.

기본은 이미지 증강 없이 prompt 위치/종류만 바뀝니다. 캐시 특징과 영상이 어긋나지 않게 하기 위한 선택입니다.
이미지 증강을 추가할 때는 해당 증강 영상의 embedding도 다시 계산해야 합니다.
학습 prompt는 70% 양성점 1개, 20% 양성+음성점, 10% jitter 박스입니다. GT에서 자동 생성됩니다.
배경 query 샘플은 `background_samples_per_image`로 조절합니다. 관심층 이외를 거부하는 task-specific 학습입니다.
작은 ROI의 prompt는 원본 좌표를 사용합니다. UI의 화면 확대 좌표를 그대로 넘기면 안 됩니다.

`loss_side`/`refine_side` 기본 1024는 긴 변의 상한입니다. 매우 얇은 층은 축소 시 사라질 수 있습니다.
SAM 자체도 긴 변 1024 입력을 사용합니다. 더 큰 원본이 자동으로 모두 보존되는 것은 아닙니다.
처음부터 모든 실험에 동일한 crop/해상도 조건을 적용하세요. 타일 자동 병합은 v0.1 범위에 없습니다.
GPU 메모리 수치는 실제 ViT-H 서버에서 측정해야 합니다. OOM이면 프로세스/커널의 잔여 모델을 확인하고
refiner 폭·해상도 또는 입력 ROI를 검토하세요. encoder 고정이어도 encoder 추론 메모리는 필요합니다.

## 테스트: 두 프로토콜을 분리

### A. 고정 grid — 실사용 평가

GT를 읽기 전에 일정한 grid 좌표를 생성하고 각 점에서 단일 마스크를 예측합니다.
추론/후보 필터링에는 GT를 사용하지 않습니다. 같은 grid와 동일 threshold/NMS를 5조건에 적용합니다.
기본 16×16=256 query이며 보정 모델은 query마다 추가 실행되어 느려질 수 있습니다.
처음 동작 확인은 val에서 4×4 또는 8×8로 해도 되지만 최종 조건은 val에서 정하고 test 전에 고정하세요.
이 실험은 공식 AMG의 crop hierarchy/3개 multimask를 재현하지 않는 **단일 마스크 고정-grid harness**입니다.
현재 웹 UI가 공식 AMG를 사용한다면 이 harness 또는 같은 추론 프로토콜을 연결하고 다시 검증해야 합니다.

원 SAM IoU score는 decoder 변경 후 재보정되지 않았으므로 본 패키지는 필터/순위에 사용하지 않습니다.
foreground 확률의 stability로 정렬하고 mask IoU NMS를 사용합니다. 기본 min_stability=0은 이 점수로 제거하지 않는다는 뜻입니다.
NMS는 합쳐진 층을 올바르게 분리해주는 알고리즘이 아닙니다.

평가 시에만 GT 연결영역과 후보를 1:1 최대 매칭합니다. IoU≥0.5 통과 개수를 우선 최대화합니다.
클래스는 매칭한 GT로 분석표에 표시하며 **모델이 재료 이름을 예측한 것이 아닙니다.**
자동화 점수와 GT에서 가장 잘 맞는 후보를 고른 뒤의 성능을 혼동하지 마세요.

- region recall/precision/F1: 클래스 무관 관심영역 검출, 설정된 연결영역 정의에 의존.
- mean best IoU: GT별 최고 후보 IoU, 후보가 없으면 0. 진단용이며 자동 선택 성능이 아님.
- Boundary F1: 기본 허용거리 2px, 못 찾은 GT는 0 처리.
- mean boundary distance: 매칭된 영역만 계산; 누락률과 함께 보고. 작은 값만으로 모델 순위를 정하지 마세요.
- small-region recall: 기본 면적≤1024px를 임시 정의로 사용. 실제 작은 관심층 기준으로 val 이전에 정하세요.
- 얇지만 긴 층은 면적 기반 small 정의에서 빠질 수 있으므로 class별 결과도 확인하세요.
- grid_seconds: 캐시 특징 로드 이후 query+후처리 시간, end-to-end cold latency와 다름.

### B. GT 중심점 — 분할/보정 진단 평가

각 GT 영역의 내부 중심점 1개를 자동 생성하여 모든 모델에 똑같이 줍니다.
작은 층을 grid가 놓친 문제와, 점을 줘도 분할하지 못한 문제를 분리합니다.
**GT를 이용해 prompt를 만들므로 완전자동 성능으로 보고하면 안 됩니다.**
best checkpoint는 val의 이 진단 평가에서 이미지별 평균 Dice를 기준으로 선택합니다.
grid 최적 모델과 진단 최적 모델은 다를 수 있습니다. grid 선택 기준으로 변경할 경우 val에서만 변경하세요.
시험 GT는 학습/threshold 설정에 쓰지 않습니다. 시험을 보고 설정을 바꾸면 별도 최종 holdout이 필요합니다.

## 산출물

`runs/.../decoder_noabl` 등의 `best.pt`, `last.pt`, `history.json`, 설정과 분할 snapshot.
`evaluation/test/comparison.csv`, 이미지별/GT별 CSV, grid overlay, GT overlay,
진단별 예측 경계(색)+GT 경계(흰색), `grid_candidates.npz`, 수동 수정시간 기록 양식.
NPZ는 메모리/파일 용량 절약을 위해 packbits로 저장됩니다. notebook에 읽는 예가 있습니다.
사람의 수정 시간과 추가 클릭 수는 자동으로 측정할 수 없으므로 동일 완료 기준으로 수동 기록합니다.
스케일이 이미지마다 다르면 픽셀 오차를 그대로 nm로 비교하지 마세요. 검증된 nm/px로 변환해야 합니다.

## 웹 UI 연결

`export_bundle()`로 adaptation.pt + Python 모델/추론 코드 + manifest를 내보냅니다.
기존 큰 ViT-H checkpoint는 별도로 유지합니다. 원본 체크포인트는 덮어쓰지 않습니다.
decoder 실험은 기존 SAM mask_decoder에 저장된 가중치를 로드합니다.
refiner 실험은 SAM 뒤에 동일한 ResidualRefiner 구조를 생성하고 저장된 가중치를 로드합니다.
**기존 웹 UI에 .pt 파일만 업로드한다고 자동으로 연결되지는 않습니다.**
`temlab.models.Predictor` 또는 내보낸 web_adapter_example.py를 GPU backend에서 호출하세요.
전처리, native 좌표, mask threshold, grid/NMS 규칙을 학습·시험과 맞추세요.
기본 클래스 이름 출력은 없으며, material semantic map이나 MTS 자동계측은 별도 단계입니다.
동시 웹 요청에서는 set_image 상태를 공유하지 않거나 요청 잠금을 두세요.

## 검증 범위와 제한

작성 환경에서 CPU + 공식 SAM 구성요소를 축소한 무작위 모델로 4조건 학습/평가/저장/재로딩을 검사합니다.
이 검사는 실제 사전학습 ViT-H 성능, 회사 CUDA 호환성, TEM 정확도를 검증하지 않습니다.
실제 이미지와 가중치는 사용자가 서버에서 제공해야 합니다.
ABL은 원 저자 구현을 호환성/ignore 처리에 맞게 수정한 버전입니다. THIRD_PARTY_NOTICES.md를 참고하세요.
같은 semantic 클래스 내에서 GT에 없는 경계를 새로 배우지는 않습니다.
전체 모델 재학습, HQ-SAM, MTP-MAVED 사전학습, GUI, 자동 배포는 이 패키지에 포함하지 않습니다.

재현 가능한 개발 테스트: `python -m unittest discover -s tests -v`.
