# Validation record — 2026-09-29

Passed in the authoring environment:

- Python source and all code cells parsed successfully.
- All 3 Jupyter notebooks passed nbformat schema validation.
- 4 unittest tests passed, including a full integration test that trains all
  four variants for 2 epochs, evaluates baseline + four variants with fixed grid
  and GT-center diagnostics, exports each trained checkpoint, reloads it through
  the UI Predictor, and predicts an output with the original image dimensions.
- ABL directional loss produced finite nonzero gradients on a synthetic target;
  no-target handling and ignored-pixel BCE/Dice gradients were checked.
- The residual refiner starts as an identity in logit space at the same resolution.
- Perfect/missing-region metric behavior and same-group split rejection were checked.
- Exported inference threshold configuration survives checkpoint reload.

Runtime: Python 3.12, torch 2.14.0+cpu, torchvision 0.29.0+cpu.
Integration used official SAM model components with a tiny, randomly initialized
64px encoder. Test images and labels were generated synthetically in a temporary
directory. Accuracy numbers from these tests have no scientific meaning.

Not verified here:

- Actual pretrained ViT-H checkpoint execution or GPU/CUDA memory and speed.
- Company TEM images/GT, their label schema, specimen split, or achieved accuracy.
- An existing web application's integration, concurrent users, or deployment.
- Exact reproduction of ABL or MTP-MAVED paper metrics.

Run the tests again in the company Python environment if needed:
`python -m unittest discover -s tests -v`

Then use the notebooks with the actual local base checkpoint and user-supplied
image/GT pairs. Final test data must remain separate from training and selection.


## v1.1 setup update validation
- All four notebooks: Python code cells compile.
- HF helper: synthetic successful download, pinned space/revision and public token=False arguments, size/SHA256 verification, offline reuse, corruption rejection without overwriting, missing offline file rejection.
- Installer: mocked pip commands preserve existing torch/torchvision versions and install bundled SAM with --no-deps --no-build-isolation.
- Earlier GT add-on: synthetic JPEG regions, ignore=255, PNG roundtrip and invalid rectangle checks.
- Not executed: full 2.56 GB HF download, corporate pip/proxy/CDN access, pretrained ViT-H/CUDA training.
