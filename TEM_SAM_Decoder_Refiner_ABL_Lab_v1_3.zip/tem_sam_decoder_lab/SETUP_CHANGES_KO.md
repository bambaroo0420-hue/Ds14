# v1.1 설치 변경
- 패키지 설치/HF 원본 SAM ViT-H 다운로드/검증을 00 노트북으로 통합.
- 기존 config 보존. 노트북 안에서 train/val/test 및 group 지정 가능.
- 이전에 전달한 JPG GT 준비·사각형 무시영역 추가 기능 포함.
- 학습 구조·가중치 형식은 v1과 동일. analyzer 연동 코드는 이 업데이트에 포함하지 않음.
- 기존 프로젝트에서는 requirements.txt, notebooks/00_data_setup.ipynb, temlab/setup_utils.py 교체/추가.
- GT 추가 기능이 없었다면 notebooks/00a_gt_prepare.ipynb, temlab/gt_prepare.py도 복사.
- data, weights, runs, cache, config.local.json은 덮어쓰지 마세요.
- 노트북 문법, 합성 다운로드 응답/검증/오프라인 재사용, 설치 명령 생성 검증 수행.
- 2.56 GB 실제 가중치 전체 전송, 사내망 pip 설치, CUDA 학습은 이 환경에서 실행하지 않음.
