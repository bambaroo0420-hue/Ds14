GT 없는 새 test 이미지를 이 폴더에 넣으세요. 03_predict_test_images.ipynb로 예측합니다.
