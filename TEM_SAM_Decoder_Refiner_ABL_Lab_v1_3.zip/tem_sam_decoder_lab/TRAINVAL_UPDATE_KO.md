# v1.2 교체 안내
전체 ZIP을 새 폴더에 풀어 시작하거나 아래 파일들을 기존 프로젝트의 같은 위치에 복사하세요.
- notebooks/00_data_setup.ipynb: 8:2 랜덤 분할, 분할 재사용
- temlab/split_data.py: 새 분할 도우미
- temlab/data.py: test 없이 train/val 학습 허용
- notebooks/00a_gt_prepare.ipynb: 현재 manifest와 JPG 원본 경로 사용
- temlab/evaluate.py, notebooks/02_evaluate_export.ipynb: test GT가 없을 때 명시적으로 정량시험 생략
- notebooks/03_predict_test_images.ipynb: data/test 이미지 전용 예측
- notebooks/01_train.ipynb: 안내문 갱신

00 한 파일만 교체하면 split_data.py를 찾지 못하므로 관련 파일도 함께 복사하세요.
기존 data/weights/runs/cache/config.local.json은 보존하고 커널을 재시작하세요.
순서: 00 설치·다운로드·분할 → JPG GT이면 00a → 00 audit → 01 학습 → 02 val/export → 03 test 예측.
test GT가 없으면 Dice/IoU 점수는 계산하지 않습니다.
