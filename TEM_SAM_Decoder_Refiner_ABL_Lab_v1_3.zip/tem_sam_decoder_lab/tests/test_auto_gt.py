import csv
import json
import tempfile
import unittest
from pathlib import Path
import numpy as np
from PIL import Image
from temlab.auto_gt import automatic_colors, clip_rectangles, prepare_project
from temlab.data import read_manifest, audit, sha256
from temlab.split_data import split_trainval


class AutoGTTests(unittest.TestCase):
    def test_exact_close_colors_and_tiny_area(self):
        a = np.zeros((30,30,3), np.uint8)
        a[:] = [100,30,40]; a[:,15:] = [101,30,40]; a[1,1] = [1,2,3]
        labels, palette, report = automatic_colors(a, np.zeros(a.shape[:2], bool))
        self.assertEqual(len(palette), 3)
        self.assertNotEqual(labels[20,10], labels[20,20])
        self.assertEqual((labels == labels[1,1]).sum(), 1)
        self.assertEqual(report['uncertain_pixels'], 0)

    def test_jpeg_more_than_eight_colors_small_region(self):
        with tempfile.TemporaryDirectory() as d:
            a = np.zeros((256,256,3), np.uint8)
            colors = [[20,40,180],[180,30,40],[30,170,70],[180,170,30],
                      [50,180,200],[190,60,180],[90,90,90],[230,230,230],[80,40,10]]
            for i,c in enumerate(colors):
                y,x = divmod(i,3); a[y*80:(y+1)*80,x*80:(x+1)*80] = c
            a[240:,:] = colors[0]; a[:,240:] = colors[0]
            a[20:36,20:36] = [250,120,20]
            p = Path(d)/'mask.jpg'; Image.fromarray(a).save(p, quality=95)
            rgb = np.asarray(Image.open(p).convert('RGB'))
            ignored,_,_ = clip_rectangles(a.shape, [(220,220,300,300)])
            labels,palette,report = automatic_colors(rgb, ignored, lossy=True)
            samples = [int(labels[y*80+50,x*80+50]) for y in range(3) for x in range(3)]
            self.assertEqual(len(set(samples)),9); self.assertNotIn(255,samples)
            self.assertNotIn(int(labels[27,27]), samples+[255])
            self.assertTrue((labels[ignored]==255).all())
            self.assertGreater(report['raw_rgb_count'],len(palette))
            self.assertLess(report['uncertain_fraction'],.1)

    def test_rects_full_size_and_clipping(self):
        from temlab.auto_gt import DEFAULT_RECTS
        ignored,effective,notes = clip_rectangles((2048,2048),DEFAULT_RECTS)
        self.assertEqual(int(ignored.sum()),1780*200+180*100)
        self.assertEqual(len(effective),2); self.assertFalse(notes)
        ignored,effective,notes = clip_rectangles((100,100),DEFAULT_RECTS)
        self.assertEqual(int(ignored.sum()),80*80)
        self.assertEqual(len(effective),1); self.assertEqual(len(notes),2)

    def project(self,root,rgb=True):
        rows=[]
        for i in range(10):
            im=root/f'image{i}.png'; mask=root/f'mask{i}.png'
            Image.fromarray(np.random.default_rng(i).integers(0,255,(48,64,3),dtype=np.uint8)).save(im)
            gt=np.zeros((48,64,3) if rgb else (48,64),np.uint8)
            if rgb:
                gt[:]=[20,30,180]; gt[:,32:]=[170,40,30]
                if i%2: gt[5:12,5:12]=[10,210,50]
            else: gt[:,32:]=5
            Image.fromarray(gt).save(mask)
            rows.append(dict(image_id=f'im{i}',image=str(im),mask=str(mask),group=f'g{i}',split=''))
        manifest=root/'raw.csv'
        with manifest.open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
        dest=root/'split.csv';split_trainval(manifest,dest)
        cfg=json.loads((Path(__file__).resolve().parents[1]/'config.example.json').read_text())
        cfg.update(manifest=str(dest),output_dir=str(root/'runs'),preprocessing='uint8')
        (root/'config.local.json').write_text(json.dumps(cfg))
        return dest

    def test_batch_audit_rerun_split_and_originals(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);split=self.project(root);before=sha256(root/'mask0.png')
            cfg,summary=prepare_project(root,ignore_rects=[(0,0,5,5)])
            self.assertEqual(len(cfg['class_names']),3)
            rows=read_manifest(cfg['manifest']);self.assertEqual(len(audit(rows,cfg)),10)
            self.assertEqual(sum(r['split']=='val' for r in rows),2)
            self.assertEqual(sha256(root/'mask0.png'),before)
            self.assertIsNone(cfg['rgb_label_map'])
            again,_=prepare_project(root,ignore_rects=[(0,0,5,5)])
            self.assertEqual(again['manifest'],cfg['manifest'])
            split_trainval(again['manifest'],split)
            again['manifest']=str(split);(root/'config.local.json').write_text(json.dumps(again))
            after,_=prepare_project(root,ignore_rects=[(0,0,5,5)])
            self.assertEqual(after['auto_gt_fingerprint'],cfg['auto_gt_fingerprint'])
            self.assertEqual([(r['image_id'],r['split']) for r in read_manifest(after['manifest'])],
                             [(r['image_id'],r['split']) for r in rows])
            Image.fromarray(np.zeros((48,64),np.uint8)).save(rows[0]['mask'])
            with self.assertRaisesRegex(ValueError,'changed or missing'):
                prepare_project(root,ignore_rects=[(0,0,5,5)])

    def test_index_masks_and_failed_conversion_preserve_config(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);self.project(root,rgb=False)
            cfg,_=prepare_project(root,ignore_rects=[])
            self.assertEqual(cfg['class_names'],{'5':'region_color_005'})
            audit(read_manifest(cfg['manifest']),cfg)
            before=(root/'config.local.json').read_bytes()
            with self.assertRaises(ValueError):prepare_project(root,ignore_rects=[(0,0,999,999)])
            self.assertEqual((root/'config.local.json').read_bytes(),before)

    def test_uncertain_not_forced_into_wrong_color(self):
        from temlab.auto_gt import nearest_colors
        a=np.array([[[250,0,0],[0,250,0],[125,125,0],[0,0,255]]],np.uint8)
        labels,count=nearest_colors(a,[[250,0,0],[0,250,0]],np.ones((1,4),bool),max_distance=50,ambiguity_margin=2)
        self.assertEqual(labels.tolist(),[[1,2,255,255]]);self.assertEqual(count,2)

if __name__=='__main__':unittest.main()
