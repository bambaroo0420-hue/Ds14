import csv
import tempfile
import unittest
from pathlib import Path
import numpy as np
from PIL import Image
from temlab.split_data import split_trainval
from temlab.data import read_manifest, audit


class SplitTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.src = self.root / 'manifest.csv'
        self.dest = self.root / 'split.csv'
        self.rows = []
        for i in range(10):
            im, gt = self.root / f'im{i}.png', self.root / f'gt{i}.png'
            Image.fromarray(np.full((8, 8, 3), i, np.uint8)).save(im)
            Image.fromarray(np.ones((8, 8), np.uint8)).save(gt)
            self.rows.append(dict(image_id=f'im{i}', image=im.name, mask=gt.name,
                                 group=f'im{i}', split=''))
        self.write()

    def write(self):
        with self.src.open('w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=list(self.rows[0]))
            w.writeheader(); w.writerows(self.rows)

    def tearDown(self):
        self.tmp.cleanup()

    def test_trainval_without_test_and_reuse(self):
        rows = split_trainval(self.src, self.dest)
        self.assertEqual(sum(r['split'] == 'val' for r in rows), 2)
        loaded = read_manifest(self.dest)
        report = audit(loaded, dict(preprocessing='uint8', class_names={'1':'A'},
            background_label=0, ignore_label=255, min_gt_area=1))
        self.assertEqual(len(report), 10)
        self.rows.reverse(); self.write()
        again = split_trainval(self.src, self.dest)
        self.assertEqual({r['image_id']:r['split'] for r in rows},
                         {r['image_id']:r['split'] for r in again})
        with self.assertRaises(ValueError):
            split_trainval(self.src, self.dest, seed=43)

    def test_related_crops_stay_together(self):
        for i, r in enumerate(self.rows): r['group'] = f'cell{i//2}'
        self.write()
        rows = split_trainval(self.src, self.dest)
        groups = {}
        for r in rows:
            groups.setdefault(r['group'], set()).add(r['split'])
        self.assertTrue(all(len(v) == 1 for v in groups.values()))

    def test_old_test_excluded_and_new_images_rejected(self):
        self.rows[0]['split'] = 'test'; self.write()
        rows = split_trainval(self.src, self.dest)
        self.assertNotIn('im0', {r['image_id'] for r in rows})
        self.rows[1]['split'] = 'test'; self.write()
        with self.assertRaises(ValueError): split_trainval(self.src, self.dest)

    def test_one_group_and_existing_destination_rejected(self):
        for r in self.rows:r['group'] = 'same'
        self.write()
        with self.assertRaises(ValueError): split_trainval(self.src, self.dest)
        for r in self.rows:r['group'] = r['image_id']
        self.write(); self.dest.write_text('existing')
        with self.assertRaises(FileExistsError): split_trainval(self.src, self.dest)
        self.assertEqual(self.dest.read_text(), 'existing')


if __name__ == '__main__': unittest.main()
