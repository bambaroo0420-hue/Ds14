# Validation record — 2026-09-29

Passed in the authoring environment:

- Python source and all code cells parsed successfully.
- All 3 Jupyter notebooks passed nbformat schema validation.
- 4 unittest tests passed, including a full integration test that trains all
  four variants for 2 epochs, evaluates baseline + four variants with fixed grid
  and GT-center diagnostics, exports each trained checkpoint, reloads it through
  the UI Predictor, and predicts an output with the original image dimensions.
- ABL directional loss produced finite nonzero gradients on a synthetic target;
  no-target handling and ignored-pixel BCE/Dice gradients were checked.
- The residual refiner starts as an identity in logit space at the same resolution.
- Perfect/missing-region metric behavior and same-group split rejection were checked.
- Exported inference threshold configuration survives checkpoint reload.

Runtime: Python 3.12, torch 2.14.0+cpu, torchvision 0.29.0+cpu.
Integration used official SAM model components with a tiny, randomly initialized
64px encoder. Test images and labels were generated synthetically in a temporary
directory. Accuracy numbers from these tests have no scientific meaning.

Not verified here:

- Actual pretrained ViT-H checkpoint execution or GPU/CUDA memory and speed.
- Company TEM images/GT, their label schema, specimen split, or achieved accuracy.
- An existing web application's integration, concurrent users, or deployment.
- Exact reproduction of ABL or MTP-MAVED paper metrics.

Run the tests again in the company Python environment if needed:
`python -m unittest discover -s tests -v`

Then use the notebooks with the actual local base checkpoint and user-supplied
image/GT pairs. Final test data must remain separate from training and selection.


## v1.1 setup update validation
- All four notebooks: Python code cells compile.
- HF helper: synthetic successful download, pinned space/revision and public token=False arguments, size/SHA256 verification, offline reuse, corruption rejection without overwriting, missing offline file rejection.
- Installer: mocked pip commands preserve existing torch/torchvision versions and install bundled SAM with --no-deps --no-build-isolation.
- Earlier GT add-on: synthetic JPEG regions, ignore=255, PNG roundtrip and invalid rectangle checks.
- Not executed: full 2.56 GB HF download, corporate pip/proxy/CDN access, pretrained ViT-H/CUDA training.


## v1.2 train/val workflow validation
- Four targeted tests passed: train/val-only read+audit and split reuse; related crops grouped; old test rows excluded and changed image sets rejected; one-group and existing destination rejection.
- Exact 00 notebook split cell executed twice with 10 synthetic image/GT pairs: 8 train, 2 val, persisted config, unchanged split.
- All five notebooks: Python cells compile; cell IDs unique.
- Full pretrained SAM/CUDA training and company test images were not available for this change.

## v1.3 automatic GT update validation
- 6 targeted auto-GT tests and 4 existing train/val tests passed.
- Exact low-color lossless RGB: neighboring RGB values and a one-pixel region remain separate.
- Synthetic JPEG with >8 painted colors and a small region: distinct interior assignments; ambiguity/outlier pixels ignored explicitly.
- User rectangles at 2048x2048, clipping to smaller images, full-image exclusion rejection.
- Batch conversion -> read_manifest/audit, index-label preservation, original file hashes, failed conversion preserving config, repeat conversion cache, split rerun recovery, and prepared-mask corruption rejection.
- Exact 00 notebook split/conversion/audit cells executed twice on 10 synthetic pairs: stable 8/2 split and reused prepared masks.
- Synthetic JPEG preview visually inspected: 10 colors detected, 1.42% non-rectangle uncertain pixels in this example. This is not a company-data accuracy measurement.
- All Python sources and 5 notebooks' Python cells compiled; notebook cell IDs unique. nbformat schema validation was not rerun because nbformat is absent in the current authoring runtime.
- The earlier full SAM integration suite was not rerun for this GT-only change. Its synthetic label fixture now defines its class_names explicitly because config.example starts empty until preparation.
- No actual company images, pretrained ViT-H/CUDA run, or new HF download were used.
