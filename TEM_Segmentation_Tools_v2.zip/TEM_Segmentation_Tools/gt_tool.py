"""Local multi-layer TEM ground-truth editor V2."""
from __future__ import annotations
import argparse
from pathlib import Path
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog, colorchooser

import numpy as np
from PIL import Image, ImageTk
from scipy import ndimage as ndi
from skimage.segmentation import find_boundaries

from core import Project, UNKNOWN, UNCERTAIN, EXCLUDED, SPECIAL, COLORS, boundary_data, display_rgb, normalized

BASE = Path(__file__).resolve().parent


class GTApp:
    def __init__(self, root, autosave=True):
        self.root = root
        root.title('TEM GT Studio V2 — 다층 / 계면 Ground Truth')
        root.geometry(f'{min(1500,root.winfo_screenwidth()-60)}x{min(960,root.winfo_screenheight()-100)}'); root.minsize(1120, 700)
        self.project = None; self.project_path = None
        self.scale = 1.; self.ox = self.oy = 0.
        self.roi = None; self.drag = None; self.last = None
        self.stroke_count = 0; self.stroke_checkpoint = False
        self.painted_segments = set()
        self.preview = None; self.preview_stats = None; self.preview_revision = None
        self.original = False; self.space_down = False
        self.base_rgb = None; self.composite = None
        self.mode = tk.StringVar(value='superpixel')
        self.radius = tk.IntVar(value=5); self.segments = tk.IntVar(value=800)
        self.compact = tk.DoubleVar(value=.08); self.sigma = tk.DoubleVar(value=1.)
        self.alpha = tk.DoubleVar(value=.38)
        self.show_pieces = tk.BooleanVar(value=False); self.show_edges = tk.BooleanVar(value=True)
        self.unknown_only = tk.BooleanVar(value=False); self.protect_brush = tk.BooleanVar(value=True)
        self.pair_a = tk.StringVar(); self.pair_b = tk.StringVar()
        self.snap_radius = tk.IntVar(value=3); self.snap_sigma = tk.DoubleVar(value=1.)
        self.snap_threshold = tk.DoubleVar(value=.02)
        self.status = tk.StringVar(value='이미지를 열고 층 목록에서 라벨을 선택하세요. Space: 원본 비교')
        self.view_status = tk.StringVar(value='편집 화면')
        self._build()
        self.root.protocol('WM_DELETE_WINDOW', self.close)
        self.root.bind('<KeyPress-space>', self.space_press)
        self.root.bind('<KeyRelease-space>', self.space_release)
        self.root.bind('<FocusOut>', self.focus_out)
        self.root.bind('<Control-z>', lambda e:self.undo())
        self.root.bind('<Control-y>', lambda e:self.undo(True))
        self.root.bind('<Control-s>', lambda e:self.save())
        self.root.bind('<Escape>', lambda e:self.cancel_preview())
        self.root.bind('<KeyPress-bracketleft>', lambda e:self.brush_size(-1))
        self.root.bind('<KeyPress-bracketright>', lambda e:self.brush_size(1))
        self.autosave_enabled = autosave
        if autosave:
            root.after(60000, self.autosave)

    def _build(self):
        toolbar = ttk.Frame(self.root, padding=5); toolbar.pack(fill='x')
        actions = [('이미지 열기', self.open_image), ('프로젝트 열기', self.open_project),
                   ('V1 가져오기', self.import_v1), ('저장', self.save), ('다른 이름 저장', lambda:self.save(True)),
                   ('GT 내보내기', self.export), ('자동저장 복원', self.recover), ('정보·검수', self.metadata)]
        for name, command in actions:
            ttk.Button(toolbar, text=name, command=command).pack(side='left', padx=2)
        body = ttk.Panedwindow(self.root, orient='horizontal'); body.pack(fill='both', expand=True)
        sidebar = ttk.Frame(body, width=315); body.add(sidebar, weight=0)
        scroll = tk.Canvas(sidebar, width=295, highlightthickness=0)
        scrollbar = ttk.Scrollbar(sidebar, orient='vertical', command=scroll.yview)
        scrollbar.pack(side='right',fill='y'); scroll.pack(side='left',fill='both',expand=True)
        scroll.configure(yscrollcommand=scrollbar.set)
        left = ttk.Frame(scroll, padding=8)
        window = scroll.create_window((0,0),window=left,anchor='nw')
        left.bind('<Configure>',lambda e:scroll.configure(scrollregion=scroll.bbox('all')))
        scroll.bind('<Configure>',lambda e:scroll.itemconfigure(window,width=e.width))
        right = ttk.Frame(body); body.add(right, weight=1)
        ttk.Label(left, text='층 / 작업 상태', font=('맑은 고딕', 12, 'bold')).pack(anchor='w')
        self.layers = ttk.Treeview(left, columns=('lock','visible'), show='tree headings', height=7, selectmode='browse')
        self.layers.heading('#0', text='ID · 이름'); self.layers.column('#0', width=145, minwidth=100)
        self.layers.heading('lock', text='잠금'); self.layers.column('lock', width=42, stretch=False)
        self.layers.heading('visible', text='표시'); self.layers.column('visible', width=42, stretch=False)
        self.layers.pack(fill='x', pady=4)
        self.layers.bind('<<TreeviewSelect>>', self.select_layer)
        row = ttk.Frame(left); row.pack(fill='x')
        for name, cmd in [('추가', self.add_layer), ('이름', self.rename_layer), ('색상', self.layer_color)]:
            ttk.Button(row, text=name, command=cmd, width=7).pack(side='left')
        row = ttk.Frame(left); row.pack(fill='x', pady=3)
        ttk.Button(row,text='잠금 / 해제',command=self.toggle_lock).pack(side='left', expand=True, fill='x')
        ttk.Button(row,text='표시 / 숨김',command=self.toggle_visible).pack(side='left', expand=True, fill='x')
        modes = ttk.LabelFrame(left, text='편집 도구', padding=6); modes.pack(fill='x', pady=5)
        for text, value in [('Superpixel 선택', 'superpixel'), ('Brush', 'brush'), ('지우개 → 미작업', 'erase'),
                            ('ROI 사각형 선택', 'roi'), ('화면 이동', 'pan'), ('밝기 프로파일', 'profile')]:
            ttk.Radiobutton(modes,text=text,value=value,variable=self.mode,command=self.mode_changed).pack(anchor='w')
        row = ttk.Frame(modes); row.pack(fill='x')
        ttk.Label(row,text='Brush 반경 (원본 px)').pack(side='left')
        ttk.Spinbox(row,from_=1,to=200,width=5,textvariable=self.radius).pack(side='right')
        ttk.Checkbutton(modes,text='미작업 픽셀에만 칠하기',variable=self.unknown_only).pack(anchor='w')
        ttk.Checkbutton(modes,text='Superpixel에서 brush 수정 보호',variable=self.protect_brush).pack(anchor='w')
        split = ttk.LabelFrame(left,text='Superpixel / 선택 ROI',padding=6); split.pack(fill='x',pady=5)
        for label, variable, lo, hi, inc in [('조각 수',self.segments,10,20000,100),
                                           ('Compactness',self.compact,.001,5,.01),('Sigma',self.sigma,0,5,.1)]:
            row=ttk.Frame(split);row.pack(fill='x')
            ttk.Label(row,text=label).pack(side='left')
            ttk.Spinbox(row,from_=lo,to=hi,increment=inc,textvariable=variable,width=8).pack(side='right')
        ttk.Button(split,text='현재 ROI 재분할 (GT 보존)',command=self.split).pack(fill='x',pady=2)
        ttk.Button(split,text='ROI 해제 → 전체 이미지',command=self.clear_roi).pack(fill='x')
        view = ttk.LabelFrame(left,text='보기 / 복구',padding=6);view.pack(fill='x',pady=5)
        ttk.Checkbutton(view,text='Superpixel 선',variable=self.show_pieces,command=self.invalidate).pack(anchor='w')
        ttk.Checkbutton(view,text='최종 계면선',variable=self.show_edges,command=self.invalidate).pack(anchor='w')
        ttk.Label(view,text='층 색상 투명도').pack(anchor='w')
        ttk.Scale(view,from_=0,to=.8,variable=self.alpha,command=lambda _:self.invalidate()).pack(fill='x')
        row=ttk.Frame(view);row.pack(fill='x')
        for name,cmd in [('화면 맞춤',self.fit),('1:1',self.one_to_one),('Undo',self.undo),('Redo',lambda:self.undo(True))]:
            ttk.Button(row,text=name,width=7,command=cmd).pack(side='left')
        ttk.Button(left,text='미작업 영역으로 이동',command=self.next_unknown).pack(fill='x',pady=2)
        ttk.Button(left,text='라벨 통계 / 작은 영역 확인',command=self.quality).pack(fill='x',pady=2)
        ttk.Label(left,text='휠: 확대/축소 · 우클릭 드래그: 이동\nSpace: 원본 ↔ 편집 · [ / ]: brush 크기\nCtrl+Z/Y: Undo/Redo · Ctrl+S: 저장',foreground='#555').pack(anchor='w',pady=6)
        top=ttk.Frame(right,padding=5);top.pack(fill='x')
        ttk.Label(top,textvariable=self.view_status,font=('맑은 고딕',11,'bold')).pack(side='left')
        ttk.Button(top,text='원본 비교 (Space)',command=self.toggle_original).pack(side='right')
        self.canvas=tk.Canvas(right,bg='#20252b',highlightthickness=0);self.canvas.pack(fill='both',expand=True)
        self.canvas.bind('<Configure>',lambda e:self.draw())
        self.canvas.bind('<ButtonPress-1>',self.down)
        self.canvas.bind('<B1-Motion>',self.motion)
        self.canvas.bind('<ButtonRelease-1>',self.up)
        self.canvas.bind('<Motion>',self.cursor)
        self.canvas.bind('<MouseWheel>',self.wheel)
        self.canvas.bind('<Button-4>',lambda e:self.zoom_at(e.x,e.y,1.2))
        self.canvas.bind('<Button-5>',lambda e:self.zoom_at(e.x,e.y,1/1.2))
        self.canvas.bind('<ButtonPress-3>',self.pan_start)
        self.canvas.bind('<B3-Motion>',self.pan_motion)
        snap=ttk.LabelFrame(right,text='실험적 Gradient 보정 — 두 층 잠금 해제 → ROI 선택 → 미리보기 → 승인',padding=5)
        snap.pack(fill='x')
        row=ttk.Frame(snap);row.pack(fill='x')
        self.a_combo=ttk.Combobox(row,textvariable=self.pair_a,state='readonly',width=17);self.a_combo.pack(side='left')
        ttk.Label(row,text=' ↔ ').pack(side='left')
        self.b_combo=ttk.Combobox(row,textvariable=self.pair_b,state='readonly',width=17);self.b_combo.pack(side='left')
        for title,var,lo,hi,inc in [('반경 px',self.snap_radius,1,20,1),('Sigma',self.snap_sigma,.3,5,.1),
                                  ('최소 gradient',self.snap_threshold,.001,1,.005)]:
            ttk.Label(row,text=title).pack(side='left',padx=3)
            ttk.Spinbox(row,textvariable=var,width=5,from_=lo,to=hi,increment=inc).pack(side='left')
        row=ttk.Frame(snap);row.pack(fill='x',pady=3)
        ttk.Button(row,text='보정 미리보기',command=self.gradient).pack(side='left')
        self.apply_button=ttk.Button(row,text='후보 적용',command=self.apply_gradient,state='disabled');self.apply_button.pack(side='left',padx=3)
        ttk.Button(row,text='후보 취소 (Esc)',command=self.cancel_preview).pack(side='left')
        ttk.Label(row,text='노랑: 기존 경계 · 자홍: 후보 · 후보 보기 중 편집 중지').pack(side='left',padx=8)
        ttk.Label(self.root,textvariable=self.status,anchor='w',padding=5,wraplength=1400).pack(fill='x')

    def error(self, exc):
        messagebox.showerror('TEM GT V2',str(exc),parent=self.root)

    def require_project(self):
        return self.project is not None

    def confirm_discard(self):
        if not self.project or not self.project.dirty:
            return True
        choice=messagebox.askyesnocancel('저장되지 않은 변경','현재 프로젝트를 저장할까요?\n아니요: 변경을 버리고 계속',parent=self.root)
        if choice is None:return False
        return self.save() if choice else True

    def attach(self, project, path=None):
        self.project=project;self.project_path=Path(path) if path else None
        self.base_rgb=display_rgb(project.raw);self.roi=None;self.original=False
        self.preview=None;self.preview_stats=None;self.apply_button.config(state='disabled')
        self.refresh_layers();self.composite=None
        self.root.update_idletasks();self.fit()
        self.status.set(f'{project.raw.shape[1]} × {project.raw.shape[0]} px · {project.raw.dtype} · 원본 해상도로 편집/저장')

    def open_image(self, path=None):
        if not self.confirm_discard():return
        path=path or filedialog.askopenfilename(filetypes=[('이미지','*.png *.jpg *.jpeg *.tif *.tiff *.bmp')])
        if not path:return
        try:self.attach(Project.from_image(path))
        except Exception as exc:self.error(exc)

    def open_project(self):
        if not self.confirm_discard():return
        path=filedialog.askopenfilename(filetypes=[('TEM GT 프로젝트','*.npz')])
        if not path:return
        try:self.attach(Project.load(path),path)
        except Exception as exc:self.error(exc)

    def import_v1(self):
        if not self.confirm_discard():return
        folder=filedialog.askdirectory(title='V1 image.png / mask.png / metadata.json 폴더')
        if not folder:return
        try:self.attach(Project.import_v1(folder))
        except Exception as exc:self.error(exc)

    def save(self, save_as=False):
        if not self.project:return False
        path=None if save_as else self.project_path
        if path is None:
            path=filedialog.asksaveasfilename(defaultextension='.temgt.npz',filetypes=[('TEM GT 프로젝트','*.temgt.npz')])
        if not path:return False
        try:
            self.project.save(path);self.project_path=Path(path)
            self.status.set(f'저장됨: {path} · {self.project.meta["review_status"]} (미적용 후보는 저장하지 않음)')
            return True
        except Exception as exc:self.error(exc);return False

    def export(self):
        if not self.project:return
        folder=filedialog.askdirectory(title='GT를 내보낼 빈 폴더를 선택하세요')
        if not folder:return
        try:
            self.project.export(folder)
            self.status.set(f'GT 내보내기 완료: {folder} · 검수 상태 {self.project.meta["review_status"]} · 미적용 후보 제외')
        except Exception as exc:self.error(exc)

    def autosave_path(self):
        return BASE/'autosave'/f'{self.project.meta["source_id"][:16]}.temgt.npz'

    def autosave(self):
        try:
            if self.project and self.project.dirty and self.drag is None:
                self.project.save(self.autosave_path(),mark_saved=False)
        except Exception as exc:
            self.status.set(f'자동저장 실패: {exc} — 수동 저장하세요.')
        finally:
            if self.autosave_enabled:self.root.after(60000,self.autosave)

    def recover(self):
        if not self.confirm_discard():return
        path=filedialog.askopenfilename(initialdir=str(BASE/'autosave'),filetypes=[('자동저장 프로젝트','*.npz')])
        if not path:return
        try:
            p=Project.load(path);p.dirty=True;self.attach(p)
            self.status.set('자동저장 복원됨. 다른 이름으로 프로젝트를 저장하세요.')
        except Exception as exc:self.error(exc)

    def close(self):
        if self.confirm_discard():self.root.destroy()

    def selected_id(self):
        values=self.layers.selection()
        return int(values[0]) if values else 1

    def refresh_layers(self, selected=None):
        if not self.project:return
        selected=self.selected_id() if selected is None else selected
        self.layers.delete(*self.layers.get_children())
        for c in self.project.classes:
            tag=f'c{c["id"]}';self.layers.tag_configure(tag,foreground=c['color'])
            self.layers.insert('', 'end',iid=str(c['id']),text=f'{c["id"]} · {c["name"]}',
                               values=('잠금' if c['locked'] else '', 'ON' if c['visible'] else 'OFF'),tags=(tag,))
        for label,name in SPECIAL.items():
            self.layers.insert('','end',iid=str(label),text=name,values=('',''))
        if self.layers.exists(str(selected)):self.layers.selection_set(str(selected))
        items=[f'{c["id"]}: {c["name"]}' for c in self.project.classes]
        for combo,var,index in [(self.a_combo,self.pair_a,0),(self.b_combo,self.pair_b,1)]:
            combo['values']=items
            if var.get() not in items:var.set(items[min(index,len(items)-1)])

    def current_class(self):
        if not self.project:return None
        return next((c for c in self.project.classes if c['id']==self.selected_id()),None)

    def select_layer(self,event=None):
        c=self.current_class()
        if c:self.status.set(f'선택: {c["name"]} · '+('잠김 — 해제 후 편집 가능' if c['locked'] else '편집 가능'))

    def add_layer(self):
        if not self.project:return
        name=simpledialog.askstring('층 추가','층 이름 (예: Top electrode, Oxide, Layer 2)',parent=self.root)
        if not name or not name.strip():return
        label=max(c['id'] for c in self.project.classes)+1
        if label>=EXCLUDED:self.error('층 ID 한도 초과');return
        self.project.checkpoint()
        self.project.classes.append(dict(id=label,name=name.strip(),color=COLORS[(label-1)%len(COLORS)],locked=False,visible=True))
        self.project.changed('add_layer');self.cancel_preview();self.refresh_layers(label);self.invalidate()

    def rename_layer(self):
        c=self.current_class()
        if not c:return
        name=simpledialog.askstring('층 이름','고정 ID의 이름 변경 (다른 재료로 재정의하지 마세요)',initialvalue=c['name'],parent=self.root)
        if not name or not name.strip():return
        self.project.checkpoint();c['name']=name.strip();self.project.changed('rename_layer')
        self.cancel_preview();self.refresh_layers();self.invalidate()

    def layer_color(self):
        c=self.current_class()
        if not c:return
        color=colorchooser.askcolor(c['color'],parent=self.root)[1]
        if color:
            self.project.checkpoint();c['color']=color;self.project.dirty=True
            self.refresh_layers();self.invalidate()

    def toggle_lock(self):
        c=self.current_class()
        if not c:return
        self.project.checkpoint();c['locked']=not c['locked']
        self.project.revision+=1;self.project.dirty=True
        self.cancel_preview();self.refresh_layers();self.invalidate()

    def toggle_visible(self):
        c=self.current_class()
        if c:
            c['visible']=not c['visible'];self.project.dirty=True
            self.refresh_layers();self.invalidate()

    def undo(self,redo=False):
        if not self.project or self.drag is not None:return
        if self.project.undo(redo):
            self.cancel_preview();self.refresh_layers();self.invalidate()
            self.status.set('Redo' if redo else 'Undo (검수 상태: draft)')

    def mode_changed(self):
        self.drag=None;self.canvas.delete('cursor')
        self.status.set('ROI는 편집 범위입니다. 원본/GT 좌표를 자르거나 변경하지 않습니다.' if self.mode.get()=='roi' else f'도구: {self.mode.get()}')

    def clear_roi(self):
        self.roi=None;self.cancel_preview();self.draw()

    def work_box(self):
        h,w=self.project.mask.shape
        return self.roi or (0,0,w,h)

    def split(self):
        if not self.project:return
        try:
            n=int(self.segments.get());compact=float(self.compact.get());sigma=float(self.sigma.get())
            if not 10<=n<=20000 or not .001<=compact<=5 or not 0<=sigma<=5:raise ValueError('Superpixel 설정 범위를 확인하세요.')
            self.status.set('Superpixel 계산 중…');self.root.update_idletasks()
            self.project.split(self.work_box(),n,compact,sigma)
            self.mode.set('superpixel');self.show_pieces.set(True);self.invalidate()
            self.status.set('재분할 완료. 기존 GT/brush/잠금 보존. 선 표시를 끄면 최종 계면을 확인하기 쉽습니다.')
        except Exception as exc:self.error(exc)

    def invalidate(self):
        self.composite=None;self.draw()

    def image_composite(self):
        if self.original:return self.base_rgb
        if self.composite is not None:return self.composite
        p=self.project;out=self.base_rgb.astype(np.float32).copy();alpha=self.alpha.get()
        for c in p.classes:
            if not c['visible']:continue
            rgb=np.array([int(c['color'][i:i+2],16) for i in (1,3,5)])
            sel=p.mask==c['id'];out[sel]=out[sel]*(1-alpha)+rgb*alpha
        for label,color in [(UNCERTAIN,[240,70,180]),(EXCLUDED,[80,80,80])]:
            sel=p.mask==label;out[sel]=out[sel]*.6+np.array(color)*.4
        if self.show_pieces.get():
            sel=find_boundaries(p.seg,mode='inner') & (p.seg>0);out[sel]=[165,175,185]
        if self.show_edges.get() or self.preview is not None:
            edge,_,_=boundary_data(p.mask,[c['id'] for c in p.classes]);out[edge]=[255,240,90]
        if self.preview is not None:
            edge,_,_=boundary_data(self.preview,[c['id'] for c in p.classes]);out[edge]=[255,40,230]
        self.composite=np.uint8(np.clip(out,0,255));return self.composite

    def draw(self):
        self.canvas.delete('image');self.canvas.delete('roi')
        if not self.project:return
        im=self.image_composite();h,w=im.shape[:2]
        cw,ch=max(1,self.canvas.winfo_width()),max(1,self.canvas.winfo_height())
        # Resample only the viewport, never allocate an enormous zoomed image.
        box=(-self.ox/self.scale,-self.oy/self.scale,(cw-self.ox)/self.scale,(ch-self.oy)/self.scale)
        view=Image.fromarray(im).transform((cw,ch),Image.Transform.EXTENT,box,
                                         resample=Image.Resampling.NEAREST if self.scale>=1 else Image.Resampling.BILINEAR,
                                         fillcolor=(32,37,43))
        self.photo=ImageTk.PhotoImage(view)
        self.canvas.create_image(0,0,image=self.photo,anchor='nw',tags='image');self.canvas.tag_lower('image')
        if self.roi and not self.original:
            x0,y0,x1,y1=self.roi
            self.canvas.create_rectangle(self.ox+x0*self.scale,self.oy+y0*self.scale,
                                         self.ox+x1*self.scale,self.oy+y1*self.scale,outline='#54e5c1',dash=(6,3),tags='roi')
        label='원본 비교 — 편집 중지' if self.original else ('보정 후보 미리보기 — 편집 중지' if self.preview is not None else '편집 화면')
        self.view_status.set(f'{label}  |  {self.scale*100:.0f}%  |  {self.project.meta["review_status"]}')

    def fit(self):
        if not self.project:return
        h,w=self.project.mask.shape;cw,ch=max(10,self.canvas.winfo_width()),max(10,self.canvas.winfo_height())
        self.scale=max(.02,min(max(1,cw-20)/w,max(1,ch-20)/h))
        self.ox=(cw-w*self.scale)/2;self.oy=(ch-h*self.scale)/2;self.draw()

    def one_to_one(self):
        self.zoom_at(self.canvas.winfo_width()/2,self.canvas.winfo_height()/2,1/self.scale)

    def zoom_at(self,x,y,factor):
        if not self.project:return
        new=min(32,max(.02,self.scale*factor));ratio=new/self.scale
        self.ox=x-(x-self.ox)*ratio;self.oy=y-(y-self.oy)*ratio;self.scale=new;self.draw()

    def wheel(self,e):
        self.zoom_at(e.x,e.y,1.2 if e.delta>0 else 1/1.2)

    def point(self,e,clamp=False):
        x,y=int(np.floor((e.x-self.ox)/self.scale)),int(np.floor((e.y-self.oy)/self.scale))
        h,w=self.project.mask.shape
        if clamp:return max(0,min(w-1,x)),max(0,min(h-1,y))
        return (x,y) if 0<=x<w and 0<=y<h else None

    def pan_start(self,e):
        self.pan_last=(e.x,e.y)

    def pan_motion(self,e):
        if hasattr(self,'pan_last'):
            self.ox+=e.x-self.pan_last[0];self.oy+=e.y-self.pan_last[1]
            self.pan_last=(e.x,e.y);self.draw()

    def down(self,e):
        self.canvas.focus_set()
        if not self.project:return
        if self.mode.get()=='pan':self.pan_start(e);self.drag='pan';return
        p=self.point(e)
        if p is None:return
        if self.mode.get()=='profile':self.drag=p;return
        if self.original or self.preview is not None:return
        self.drag=p;self.last=p;self.stroke_count=0;self.stroke_checkpoint=False;self.painted_segments=set()
        if self.mode.get() not in ('roi',):self.paint_at(p)

    def motion(self,e):
        if self.drag is None:return
        if self.drag=='pan':self.pan_motion(e);return
        p=self.point(e,True)
        if self.mode.get() in ('roi','profile'):
            self.canvas.delete('selection')
            x,y=self.drag
            fn=self.canvas.create_line if self.mode.get()=='profile' else self.canvas.create_rectangle
            kwargs={'fill':'#54e5c1'} if self.mode.get()=='profile' else {'outline':'#54e5c1'}
            fn(self.ox+x*self.scale,self.oy+y*self.scale,self.ox+p[0]*self.scale,self.oy+p[1]*self.scale,tags='selection',width=2,**kwargs)
        elif not self.original and self.preview is None:
            distance=max(abs(p[0]-self.last[0]),abs(p[1]-self.last[1]))
            spacing=max(1,self.radius.get()//2) if self.mode.get()!='superpixel' else 1
            for t in np.linspace(0,1,max(2,int(distance/spacing)+1)):
                q=tuple(round(a+(b-a)*t) for a,b in zip(self.last,p));self.paint_at(q,False)
            self.invalidate()
        self.last=p

    def up(self,e):
        if self.drag is None:return
        if self.drag=='pan':self.drag=None;return
        p=self.point(e,True)
        if self.mode.get()=='roi':
            x0,x1=sorted((self.drag[0],p[0]));y0,y1=sorted((self.drag[1],p[1]))
            if x1-x0>=2 and y1-y0>=2:self.roi=(x0,y0,x1+1,y1+1)
            self.canvas.delete('selection');self.draw()
        elif self.mode.get()=='profile':
            start=self.drag;self.canvas.delete('selection');self.show_profile(start,p)
        elif self.stroke_count:
            self.project.changed(f'{self.mode.get()} stroke: {self.stroke_count} pixels')
            self.status.set(f'{self.stroke_count} px 변경 · 잠긴 픽셀은 보호됨');self.draw()
        self.drag=None

    def paint_at(self,p,redraw=True):
        mode=self.mode.get();label=UNKNOWN if mode=='erase' else self.selected_id()
        if label in self.project.locked_ids():
            self.status.set('선택한 층이 잠겨 있습니다. 먼저 잠금을 해제하세요.');return
        h,w=self.project.mask.shape;x,y=p
        box=self.work_box();x0,y0,x1,y1=box
        if not (x0<=x<x1 and y0<=y<y1):return
        selection=np.zeros((h,w),bool)
        if mode=='superpixel':
            segment=int(self.project.seg[y,x])
            if segment<=0:self.status.set('이 영역을 먼저 Superpixel로 분할하세요.');return
            if segment in self.painted_segments:return
            self.painted_segments.add(segment)
            selection[y0:y1,x0:x1]=self.project.seg[y0:y1,x0:x1]==segment
        else:
            try:r=max(1,min(200,int(self.radius.get())))
            except (ValueError,tk.TclError):return
            bx0,bx1=max(x0,x-r),min(x1,x+r+1);by0,by1=max(y0,y-r),min(y1,y+r+1)
            yy,xx=np.ogrid[by0:by1,bx0:bx1]
            selection[by0:by1,bx0:bx1]=(xx-x)**2+(yy-y)**2<=r*r
        # Avoid allocating history for gestures which cannot change any pixel.
        possible=selection & (self.project.mask!=label) & ~np.isin(self.project.mask,self.project.locked_ids())
        if self.unknown_only.get():possible &= self.project.mask==UNKNOWN
        if mode=='superpixel' and self.protect_brush.get():possible &= ~self.project.brushed
        if not possible.any():return
        if not self.stroke_checkpoint:self.project.checkpoint();self.stroke_checkpoint=True
        self.stroke_count+=self.project.paint(selection,label,self.unknown_only.get(),
                                             mode=='superpixel' and self.protect_brush.get(),mode!='superpixel')
        if redraw:self.invalidate()

    def brush_size(self,delta):
        if isinstance(self.root.focus_get(),(tk.Entry,ttk.Entry,ttk.Spinbox,ttk.Combobox)):return
        try:self.radius.set(max(1,min(200,self.radius.get()+delta)))
        except tk.TclError:self.radius.set(5)

    def cursor(self,e):
        self.canvas.delete('cursor')
        if self.project and self.mode.get() in ('brush','erase') and not self.original:
            try:r=max(1,self.radius.get())*self.scale
            except tk.TclError:return
            self.canvas.create_oval(e.x-r,e.y-r,e.x+r,e.y+r,outline='white',tags='cursor')

    def toggle_original(self):
        if self.drag is not None:return
        self.original=not self.original;self.draw()

    def space_press(self,e):
        if isinstance(e.widget,(tk.Entry,ttk.Entry,ttk.Spinbox,ttk.Combobox,tk.Text)):return
        if not self.space_down:self.toggle_original();self.space_down=True
        return 'break'

    def space_release(self,e):
        self.space_down=False
        if not isinstance(e.widget,(tk.Entry,ttk.Entry,ttk.Spinbox,ttk.Combobox,tk.Text)):return 'break'

    def focus_out(self,e):
        self.space_down=False

    def gradient(self):
        if not self.project:return
        try:
            a=int(self.pair_a.get().split(':')[0]);b=int(self.pair_b.get().split(':')[0])
            self.status.set('국소 법선 gradient 후보 계산 중…');self.root.update_idletasks()
            candidate,stats=self.project.gradient_preview(a,b,self.work_box(),self.snap_radius.get(),self.snap_sigma.get(),self.snap_threshold.get())
            self.preview=candidate;self.preview_stats=stats;self.preview_revision=self.project.revision
            self.original=False;self.show_pieces.set(False)
            self.apply_button.config(state='normal' if stats['topology_ok'] and stats['changed_pixels'] else 'disabled')
            self.invalidate()
            self.status.set(f'후보 {stats["changed_pixels"]} px 변경 · 근거 통과 {stats["candidate_points"]}, 보류 {stats["held_points"]} 경계점 · '
                            +('Space로 원본 확인 후 적용하세요.' if stats['topology_ok'] else '연결/구멍 구조 변화 감지: 적용 차단'))
        except Exception as exc:self.error(exc)

    def apply_gradient(self):
        if self.preview is None:return
        try:
            self.project.apply_preview(self.preview,self.preview_stats,self.preview_revision)
            self.cancel_preview();self.status.set('보정 적용됨. Segmentation/edge 함께 갱신. Ctrl+Z로 복원 가능.')
        except Exception as exc:self.error(exc)

    def cancel_preview(self):
        self.preview=None;self.preview_stats=None;self.preview_revision=None
        self.apply_button.config(state='disabled');self.invalidate()

    def next_unknown(self):
        if not self.project:return
        labels,n=ndi.label(self.project.mask==UNKNOWN)
        if not n:self.status.set('미작업 픽셀이 없습니다.');return
        sizes=np.bincount(labels.ravel());sizes[0]=0
        component=labels==int(np.argmax(sizes));yy,xx=np.where(component)
        cy,cx=yy[len(yy)//2],xx[len(xx)//2]
        self.scale=max(self.scale,1.)
        self.ox=self.canvas.winfo_width()/2-cx*self.scale;self.oy=self.canvas.winfo_height()/2-cy*self.scale
        self.draw();self.status.set(f'가장 큰 미작업 영역: {int(component.sum())} px')

    def quality(self):
        if not self.project:return
        lines=[]
        for c in self.project.classes:
            selected=self.project.mask==c['id'];components,n=ndi.label(selected)
            sizes=np.bincount(components.ravel())[1:]
            lines.append(f'{c["id"]} {c["name"]}: {int(selected.sum())} px / 연결 영역 {n}개 / 9 px 이하 {int((sizes<=9).sum())}개')
        for label,name in SPECIAL.items():lines.append(f'{name}: {int((self.project.mask==label).sum())} px')
        lines.append('\n작은 영역은 오류가 아닐 수 있습니다. 자동 삭제하지 않습니다.\n픽셀 크기/층 기준/불확실 구간을 별도 검수하세요.')
        messagebox.showinfo('GT 품질 점검', '\n'.join(lines),parent=self.root)

    def show_profile(self,start,end):
        if start==end:return
        length=float(np.hypot(end[0]-start[0],end[1]-start[1]))
        count=max(3,int(length*2)+1)
        x=np.linspace(start[0],end[0],count);y=np.linspace(start[1],end[1],count)
        intensity=ndi.map_coordinates(normalized(self.project.raw),[y,x],order=1)
        gradient=np.gradient(intensity,length/(count-1))
        win=tk.Toplevel(self.root);win.title('선택 단면 밝기 / Gradient (원본 min-max 정규화)');win.geometry('800x430')
        ttk.Label(win,text=f'{start} → {end} · 길이 {length:.2f} px · 검정: 밝기 / 자홍: |gradient| (별도 최대값으로 표시)').pack()
        cv=tk.Canvas(win,width=780,height=330,bg='white');cv.pack(fill='both',expand=True)
        def plot(event=None):
            cv.delete('all');w=max(100,cv.winfo_width());h=max(100,cv.winfo_height())
            cv.create_line(45,20,45,h-35,w-20,h-35,fill='#888')
            for values,color in [(intensity,'#222222'),(np.abs(gradient)/max(float(np.max(np.abs(gradient))),1e-12),'#db2690')]:
                pts=[]
                for i,v in enumerate(values):pts.extend([45+i/(count-1)*(w-70),h-35-v*(h-65)])
                cv.create_line(*pts,fill=color,width=2)
            cv.create_text(45,h-16,text='0 px');cv.create_text(w-55,h-16,text=f'{length:.1f} px')
            cv.create_text(w/2,12,text=f'밝기 범위 0~1 · 최대 |gradient| {np.max(np.abs(gradient)):.4f}/px')
        cv.bind('<Configure>',plot)
        def export_profile():
            path=filedialog.asksaveasfilename(parent=win,defaultextension='.csv',filetypes=[('CSV','*.csv')])
            if path:np.savetxt(path,np.column_stack([np.linspace(0,length,count),x,y,intensity,gradient]),delimiter=',',header='distance_px,x,y,normalized_intensity,gradient_per_px',comments='')
        ttk.Button(win,text='프로파일 CSV 저장',command=export_profile).pack()

    def metadata(self):
        if not self.project:return
        win=tk.Toplevel(self.root);win.title('프로젝트 정보 / 검수');win.transient(self.root);win.grab_set()
        fields={}
        for i,(key,title) in enumerate([('device','소자/공정'),('department','부서'),('criterion_version','작업 기준서 버전'),
                                        ('author','작성자'),('reviewer','검수자'),('pixel_size_nm','nm/pixel (등방성, 확인된 값만)')]):
            ttk.Label(win,text=title).grid(row=i,column=0,padx=10,pady=5,sticky='w')
            value=self.project.meta.get(key,'')
            var=tk.StringVar(value='' if value is None else str(value));fields[key]=var
            ttk.Entry(win,textvariable=var,width=35).grid(row=i,column=1,padx=10,pady=5)
        state=tk.StringVar(value=self.project.meta['review_status'])
        ttk.Label(win,text='검수 상태').grid(row=6,column=0,padx=10,pady=5,sticky='w')
        ttk.Combobox(win,textvariable=state,values=['draft','pending_review','approved'],state='readonly').grid(row=6,column=1)
        ttk.Label(win,text='nm/pixel 미설정: px 단위만 사용합니다.\n승인은 실제 검수 후 선택하세요. 라벨 변경 시 draft로 돌아갑니다.').grid(row=7,column=0,columnspan=2,padx=10,pady=10)
        def apply():
            try:
                values={k:v.get().strip() for k,v in fields.items()}
                val=values['pixel_size_nm'];values['pixel_size_nm']=float(val) if val else None
                if val and (not np.isfinite(values['pixel_size_nm']) or values['pixel_size_nm']<=0):raise ValueError('양수인 nm/pixel 값을 입력하세요.')
                if state.get()=='approved':
                    if not values['author'] or not values['reviewer'] or not values['criterion_version']:raise ValueError('승인에는 작성자, 검수자, 기준서 버전이 필요합니다.')
                    if (self.project.mask==UNKNOWN).any():raise ValueError('미작업 픽셀이 남아 있습니다. 작업하거나 판단 불가/분석 제외로 지정하세요.')
                    if self.preview is not None:raise ValueError('미리보기 후보를 적용하거나 취소한 뒤 승인하세요.')
                self.project.checkpoint();self.project.meta.update(values)
                self.project.changed('metadata/review');self.project.meta.update(values,review_status=state.get())
                self.cancel_preview();win.destroy();self.draw()
            except Exception as exc:messagebox.showerror('정보',str(exc),parent=win)
        ttk.Button(win,text='적용',command=apply).grid(row=8,column=0,columnspan=2,pady=10)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--image');args=parser.parse_args()
    root=tk.Tk();app=GTApp(root)
    if args.image:root.after(150,lambda:app.open_image(args.image))
    root.mainloop()


if __name__=='__main__':main()
