"""TEM GT V2 data model. No display or ML framework required."""
from __future__ import annotations
import copy
import hashlib
import json
import os
from pathlib import Path
import tempfile
from datetime import datetime, timezone

import numpy as np
from PIL import Image
from scipy import ndimage as ndi
from skimage.segmentation import slic
from skimage.measure import euler_number

UNKNOWN, UNCERTAIN, EXCLUDED = 65535, 65534, 65533
SPECIAL = {UNKNOWN: '미작업', UNCERTAIN: '판단 불가', EXCLUDED: '분석 제외'}
COLORS = ['#ffad33', '#36c9dd', '#d38aff', '#79d467', '#f56b88', '#f3df62', '#8fafff']


def now():
    return datetime.now(timezone.utc).isoformat()


def normalized(raw):
    a = np.asarray(raw, dtype=np.float32)
    if a.ndim == 3:
        a = a[..., :3] @ np.array([.299, .587, .114], np.float32)
    lo, hi = np.nanmin(a), np.nanmax(a)
    return np.nan_to_num((a - lo) / max(float(hi - lo), 1e-12)).astype(np.float32)


def display_rgb(raw):
    if raw.dtype == np.uint8 and raw.ndim == 3:
        return raw[..., :3].copy()
    g = np.uint8(np.clip(normalized(raw) * 255, 0, 255))
    return np.repeat(g[..., None], 3, axis=2)


def boundary_data(mask, class_ids):
    """Both incident pixels marked. Ignore and image perimeter are invalid.

    Pair coordinate arrays preserve multiple pair memberships at junctions.
    This is a two-sided raster boundary, NOT a subpixel centerline.
    """
    known = np.isin(mask, list(class_ids))
    valid = ndi.binary_erosion(known, structure=ndi.generate_binary_structure(2, 1), border_value=0)
    pairs = {}
    edge = np.zeros(mask.shape, bool)
    for axis in (0, 1):
        sl1 = (slice(None, -1), slice(None)) if axis == 0 else (slice(None), slice(None, -1))
        sl2 = (slice(1, None), slice(None)) if axis == 0 else (slice(None), slice(1, None))
        a, b = mask[sl1], mask[sl2]
        ok = known[sl1] & known[sl2] & (a != b)
        yy, xx = np.where(ok)
        if len(yy) == 0:
            continue
        pa = np.minimum(a[ok], b[ok]).astype(np.int64)
        pb = np.maximum(a[ok], b[ok]).astype(np.int64)
        for key in np.unique(pa * 65536 + pb):
            take = pa * 65536 + pb == key
            coords = np.column_stack((yy[take], xx[take]))
            other = coords.copy(); other[:, axis] += 1
            coords = np.concatenate((coords, other))
            coords = coords[valid[coords[:, 0], coords[:, 1]]]
            name = f'{int(key // 65536)}_{int(key % 65536)}'
            pairs.setdefault(name, []).append(coords)
    for key in list(pairs):
        coords = np.unique(np.concatenate(pairs[key]), axis=0)
        if not len(coords):
            del pairs[key]; continue
        pairs[key] = coords.astype(np.int32)
        edge[coords[:, 0], coords[:, 1]] = True
    return edge, valid, pairs


class Project:
    def __init__(self, raw, source=''):
        if raw.ndim not in (2, 3) or (raw.ndim == 3 and raw.shape[2] != 3):
            raise ValueError('2D grayscale 또는 RGB 이미지만 지원합니다.')
        self.raw = np.asarray(raw).copy()
        self.mask = np.full(raw.shape[:2], UNKNOWN, np.uint16)
        self.brushed = np.zeros(raw.shape[:2], bool)
        self.seg = np.zeros(raw.shape[:2], np.int32)
        self.classes = [dict(id=0, name='Background', color='#4585c9', locked=False, visible=True),
                        dict(id=1, name='Layer 1', color=COLORS[0], locked=False, visible=True)]
        self.meta = dict(schema_version=2, source_name=str(source), source_shape=list(raw.shape),
                         source_dtype=str(raw.dtype), source_id=hashlib.sha256(raw.tobytes()).hexdigest(),
                         pixel_size_nm=None, criterion_version='', device='', department='',
                         author='', reviewer='', review_status='draft', created=now(), events=[])
        self.history, self.future = [], []
        self.revision = 0
        self.dirty = True

    @classmethod
    def from_image(cls, path):
        with Image.open(path) as im:
            if getattr(im, 'n_frames', 1) > 1:
                raise ValueError('다중 페이지 이미지는 단일 프레임 TIFF로 내보낸 후 여세요.')
            raw = np.asarray(im if im.mode in ('L', 'I', 'I;16', 'F') or im.mode.startswith('I;16') else im.convert('RGB'))
        if not np.isfinite(raw).all():
            raise ValueError('NaN/Inf가 있는 영상은 지원하지 않습니다.')
        return cls(raw, str(Path(path).resolve()))

    def snapshot(self):
        return (self.mask.copy(), self.brushed.copy(), copy.deepcopy(self.classes), copy.deepcopy(self.meta))

    def checkpoint(self):
        self.history.append(self.snapshot())
        # Mask + brush history capped by count and approximately 256 MiB.
        limit = max(1, min(30, 256 * 1024**2 // max(self.mask.nbytes + self.brushed.nbytes, 1)))
        self.history = self.history[-limit:]
        self.future.clear()

    def changed(self, action):
        self.meta['review_status'] = 'draft'
        self.meta['reviewer'] = ''
        self.meta['events'].append(dict(time=now(), action=action))
        self.revision += 1; self.dirty = True

    def undo(self, redo=False):
        src, dst = (self.future, self.history) if redo else (self.history, self.future)
        if not src:
            return False
        dst.append(self.snapshot())
        self.mask, self.brushed, self.classes, self.meta = src.pop()
        self.meta['review_status'] = 'draft'; self.meta['reviewer'] = ''
        self.revision += 1; self.dirty = True
        return True

    def locked_ids(self):
        return [c['id'] for c in self.classes if c['locked']]

    def paint(self, selection, label, only_unknown=False, protect_brush=False, brush=False):
        if label in self.locked_ids():
            return 0
        if label not in SPECIAL and label not in [c['id'] for c in self.classes]:
            raise ValueError('알 수 없는 라벨 ID')
        allowed = selection & ~np.isin(self.mask, self.locked_ids())
        if only_unknown:
            allowed &= self.mask == UNKNOWN
        if protect_brush:
            allowed &= ~self.brushed
        allowed &= self.mask != label
        count = int(allowed.sum())
        if count:
            self.mask[allowed] = label
            if brush:
                self.brushed[allowed] = True
        return count

    def split(self, box, count=500, compactness=.08, sigma=1):
        x0, y0, x1, y1 = box
        gray = normalized(self.raw)[y0:y1, x0:x1]
        if min(gray.shape) < 3:
            raise ValueError('ROI는 최소 3 × 3 픽셀이어야 합니다.')
        seg = slic(gray, n_segments=int(count), compactness=float(compactness),
                   sigma=float(sigma), channel_axis=None, start_label=1)
        # Only superpixel selection topology changes; GT is untouched.
        offset = int(self.seg.max())
        self.seg[y0:y1, x0:x1] = seg.astype(np.int32) + offset
        self.meta['superpixel'] = dict(box=list(box), count=int(count), compactness=float(compactness), sigma=float(sigma))
        self.dirty = True

    def gradient_preview(self, a, b, box, radius=3, sigma=1, min_gradient=.02, ambiguity=.8):
        """Experimental normal-profile snap, confined to original pair boundary.

        Low contrast / competing peaks / normals near corners are held fixed.
        Topology checks and user approval remain mandatory.
        """
        if a == b or a in self.locked_ids() or b in self.locked_ids():
            raise ValueError('서로 다른 두 층을 선택하고 해당 층의 잠금을 해제하세요.')
        radius = float(radius)
        if not 1 <= radius <= 20 or not .3 <= sigma <= 5:
            raise ValueError('탐색 반경 1~20 px, sigma 0.3~5 범위를 사용하세요.')
        _, valid, pairs = boundary_data(self.mask, [c['id'] for c in self.classes])
        key = f'{min(a,b)}_{max(a,b)}'
        if key not in pairs:
            raise ValueError('선택한 층 사이에 유효한 경계가 없습니다.')
        coords = pairs[key]
        inside = self.mask == a
        sdf = ndi.distance_transform_edt(inside) - ndi.distance_transform_edt(~inside)
        smooth = ndi.gaussian_filter(sdf, 1)
        ny, nx = np.gradient(smooth)
        norm = np.hypot(ny, nx)
        ny, nx = -ny / np.maximum(norm, 1e-8), -nx / np.maximum(norm, 1e-8)
        yy, xx = coords.T
        cy, cx = ny[yy, xx], nx[yy, xx]
        # Zero location between incident pixels, sampled at half-pixel intervals.
        center_y = yy + cy * np.sign(sdf[yy, xx]) * .5
        center_x = xx + cx * np.sign(sdf[yy, xx]) * .5
        gray = ndi.gaussian_filter(normalized(self.raw), sigma)
        gy, gx = np.gradient(gray)
        steps = np.arange(-radius, radius + .25, .5)
        sy = center_y[:, None] + cy[:, None] * steps
        sx = center_x[:, None] + cx[:, None] * steps
        sample_coords = np.array([sy, sx])
        score = np.abs(ndi.map_coordinates(gy, sample_coords, order=1, mode='nearest') * cy[:, None]
                       + ndi.map_coordinates(gx, sample_coords, order=1, mode='nearest') * cx[:, None])
        best = np.argmax(score, axis=1)
        peak = score[np.arange(len(best)), best]
        competing = score.copy()
        competing[np.abs(steps[None, :] - steps[best, None]) <= max(1., sigma)] = 0
        second = competing.max(axis=1)
        x0,y0,x1,y1 = box
        trusted = ((peak >= min_gradient) & (second < peak * ambiguity) &
                   (best > 0) & (best < len(steps)-1) & (norm[yy, xx] >= .8) &
                   (xx >= x0) & (xx < x1) & (yy >= y0) & (yy < y1))
        displacement = np.where(trusted, steps[best], 0)
        boundary = np.zeros(self.mask.shape, bool); boundary[yy, xx] = True
        offsets = np.zeros(self.mask.shape, np.float32); offsets[yy, xx] = displacement
        distance, nearest = ndi.distance_transform_edt(~boundary, return_indices=True)
        field = offsets[tuple(nearest)]
        # Use +/- half pixel signed distances to match between-pixel initial edge.
        real_sdf = np.sign(sdf) * (np.abs(sdf) - .5)
        pair = (self.mask == a) | (self.mask == b)
        roi = np.zeros(pair.shape, bool); roi[y0:y1, x0:x1] = True
        editable = pair & valid & roi & (distance <= radius) & (np.abs(real_sdf) <= radius)
        candidate = self.mask.copy()
        new_a = real_sdf + field > 0
        candidate[editable & new_a] = a
        candidate[editable & ~new_a] = b
        topology_ok = True
        for label in (a, b):
            before, after = self.mask == label, candidate == label
            if (ndi.label(before)[1] != ndi.label(after)[1] or
                    euler_number(before, connectivity=1) != euler_number(after, connectivity=1)):
                topology_ok = False
        stats = dict(pair=[int(a),int(b)], radius=radius, sigma=float(sigma),
                     min_gradient=float(min_gradient), ambiguity=float(ambiguity),
                     candidate_points=int(trusted.sum()), held_points=int((~trusted).sum()),
                     changed_pixels=int((candidate != self.mask).sum()), topology_ok=bool(topology_ok),
                     algorithm='normal_gradient_v2_experimental', box=list(box))
        return candidate, stats

    def apply_preview(self, candidate, stats, revision):
        if revision != self.revision:
            raise ValueError('미리보기 이후 GT가 변경되었습니다. 다시 계산하세요.')
        if not stats['topology_ok']:
            raise ValueError('층의 연결/구멍 구조 변화가 감지되어 적용할 수 없습니다.')
        a,b = stats['pair']
        if a in self.locked_ids() or b in self.locked_ids():
            raise ValueError('잠긴 층은 보정할 수 없습니다.')
        changed = candidate != self.mask
        if not changed.any():
            return
        if not np.isin(self.mask[changed], [a,b]).all() or not np.isin(candidate[changed], [a,b]).all():
            raise ValueError('보정 후보의 층 범위 오류')
        self.checkpoint()
        self.mask = candidate.copy(); self.brushed[changed] = True
        self.changed('gradient_apply')
        self.meta['events'][-1]['settings'] = stats

    def save(self, path, mark_saved=True):
        path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
        metadata = copy.deepcopy(self.meta)
        metadata.update(classes=self.classes, saved=now(),
                        special_labels={str(k): v for k,v in SPECIAL.items()},
                        boundary_encoding='4-neighbor two-sided raster; image perimeter and ignore adjacency invalid')
        descriptor, tmp = tempfile.mkstemp(prefix='.temgt-', suffix='.npz', dir=path.parent)
        os.close(descriptor)
        try:
            with open(tmp, 'wb') as f:
                np.savez_compressed(f, raw=self.raw, mask=self.mask, brushed=self.brushed,
                                    seg=self.seg, metadata=np.array(json.dumps(metadata, ensure_ascii=False)))
            os.replace(tmp, path)
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)
        if mark_saved:
            self.dirty = False

    @classmethod
    def load(cls, path):
        with np.load(path, allow_pickle=False) as d:
            raw, mask = d['raw'].copy(), d['mask'].copy()
            meta = json.loads(str(d['metadata']))
            if meta.get('schema_version') != 2:
                raise ValueError('지원하지 않는 프로젝트 버전')
            obj = cls(raw)
            if mask.shape != raw.shape[:2] or mask.dtype != np.uint16:
                raise ValueError('마스크 크기/자료형 오류')
            obj.classes = meta.pop('classes')
            ids = [c['id'] for c in obj.classes]
            if len(set(ids)) != len(ids) or any(not 0 <= i < EXCLUDED for i in ids):
                raise ValueError('층 ID 오류')
            if not np.isin(mask, ids + list(SPECIAL)).all():
                raise ValueError('정의되지 않은 마스크 라벨')
            obj.mask = mask; obj.meta = meta
            obj.brushed = d['brushed'].astype(bool); obj.seg = d['seg'].astype(np.int32)
            if obj.brushed.shape != mask.shape or obj.seg.shape != mask.shape:
                raise ValueError('편집 데이터 크기 오류')
            obj.dirty = False
            return obj

    @classmethod
    def import_v1(cls, folder):
        p = Path(folder)
        obj = cls.from_image(p/'image.png')
        m = np.array(Image.open(p/'mask.png'))
        if m.shape != obj.mask.shape or not np.isin(m,[0,1,255]).all():
            raise ValueError('V1 0/1/255 마스크가 아닙니다.')
        obj.mask = np.where(m == 255, UNKNOWN, m.astype(np.uint16)).astype(np.uint16)
        obj.meta['imported_v1'] = json.loads((p/'metadata.json').read_text(encoding='utf-8'))
        obj.changed('import_v1'); return obj

    def export(self, folder):
        p = Path(folder); p.mkdir(parents=True, exist_ok=True)
        if any(p.iterdir()):
            raise ValueError('덮어쓰기를 방지하기 위해 빈 폴더를 선택하세요.')
        self.save(p/'project.temgt.npz', mark_saved=False)
        np.save(p/'raw.npy', self.raw, allow_pickle=False)
        Image.fromarray(display_rgb(self.raw)).save(p/'image_preview.png')
        Image.fromarray(self.mask).save(p/'mask_labels_uint16.png')
        edge, valid, pairs = boundary_data(self.mask, [c['id'] for c in self.classes])
        Image.fromarray(edge.astype(np.uint8)*255).save(p/'edge.png')
        Image.fromarray(valid.astype(np.uint8)*255).save(p/'edge_valid.png')
        np.savez_compressed(p/'edge_pairs_yx.npz', **pairs)
        known = np.isin(self.mask, [c['id'] for c in self.classes])
        Image.fromarray(known.astype(np.uint8)*255).save(p/'segmentation_valid.png')
        metadata = dict(self.meta, classes=self.classes, exported=now(),
                        special_labels={str(k):v for k,v in SPECIAL.items()},
                        edge_convention='4-neighbor adjacency, both incident pixels; not a one-pixel centerline',
                        edge_pair_format='keys: smallerID_largerID; values: N x 2 [y,x] original pixel coordinates',
                        raw_file='raw.npy', mask_file='mask_labels_uint16.png')
        (p/'metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
