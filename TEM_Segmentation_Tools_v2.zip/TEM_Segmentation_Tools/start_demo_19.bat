@echo off
cd /d "%~dp0"
call start_gt.bat --image "%~dp0samples\19.jpg"
