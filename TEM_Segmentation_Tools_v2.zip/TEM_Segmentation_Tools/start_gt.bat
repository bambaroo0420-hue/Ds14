@echo off
cd /d "%~dp0"
call run_python.bat gt_tool.py %*
if errorlevel 1 (
  echo V2 could not start. Run setup_v2.bat to install dependencies.
  pause
)
