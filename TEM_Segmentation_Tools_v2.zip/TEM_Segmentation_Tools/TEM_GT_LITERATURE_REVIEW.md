# TEM GT 제작 논리: 논문·웹·GitHub 조사

조사일: 2026-09-19. 코드 변경 없음. 목적은 반도체 다층 TEM의 segmentation/edge GT 제작 요구사항을 검토하는 것이다. 체계적 문헌고찰 전체를 수행한 것은 아니며 공개 접근 가능한 1차 자료 중심의 조사다. 논문에 명시된 사실과 본 프로젝트에 대한 설계 제안을 구별한다.

## 1. 결론

확인한 사례에서는 전문가 수작업, threshold 등으로 초기 분할 후 수작업 수정, gradient 계면 검출 후 사용자 수정이 사용된다. 자동 검출 결과를 별도 검수 없이 물리적 정답으로 간주할 근거는 찾지 못했다. 반도체 ReRAM/MRAM/SRAM 다층 TEM 전체에 공통 적용되는 공개 GT 규칙도 이번 조사에서는 확인하지 못했다.

권고: superpixel/brush로 층 의미를 부여하고, gradient는 선택 계면의 후보 위치를 제안하며, 검수 승인된 segmentation에서 edge를 일관되게 생성한다. 이는 문헌을 바탕으로 한 설계 판단이지 특정 논문이 검증한 동일 파이프라인은 아니다.

## 2. 가장 직접적인 계면 정의 근거: ISO 20263:2024

[ISO 공식 페이지](https://www.iso.org/standard/87682.html)

- 다층 재료 단면 영상에서 두 층 사이의 평균 계면 위치 결정 절차를 다룬다.
- TEM/STEM 단면 영상과 EDS/EELS 원소 매핑 영상이 적용 범위에 포함된다.
- 공개 초록과 범위를 확인했다. 유료 본문 전체를 확보하거나 절차를 구현·검증한 것은 아니다.
- 평균 계면 위치 규격을 모든 곡선의 국소 픽셀 GT 또는 거칠기 측정 규격으로 동일시하면 안 된다.
- 부서 기준서 합의 시 우선 검토할 표준이다. 본문 확인 전 특정 gradient/중간 밝기 알고리즘을 ISO 준수라고 부르지 않는다.

## 3. 사례별 GT 제작 및 적용 범위

### A. AxonDeepSeg (2018): TEM 반자동 라벨 후 교차 검수

[논문](https://pmc.ncbi.nlm.nih.gov/articles/PMC5830647/) · [공식 GitHub](https://github.com/axondeepseg/axondeepseg)

TEM myelin을 밝기 threshold로 초기 분할한 뒤 사람이 수정하고, 안쪽 영역을 채워 axon 라벨을 만든다. GT는 최소 두 연구자가 교차 확인했다. 최종적으로 배경/myelin/axon의 클래스 마스크를 저장한다. 생물 TEM 사례이므로 재료 계면 정의를 반도체에 직접 적용할 수는 없지만 반자동 초안→수정→교차 검수 흐름의 명확한 근거다. 본문 라벨링 절의 검색 색인을 확인했으며 직접 페이지 재접속은 CAPTCHA로 제한되었다.

### B. TD U-Net (2025): 전문가가 shell 경계를 그려 마스크 생성

[논문](https://pmc.ncbi.nlm.nih.gov/articles/PMC12610756/)

Core-shell TiO2 TEM 영상에서 숙련 연구자가 Labelme로 shell 영역을 수동 주석하고 Python으로 이진 마스크로 변환했다. 나노입자 shell이며 반도체 적층 구조는 아니다. 확인한 데이터셋 설명에는 최대 gradient를 모든 경계의 통일 기준으로 사용하는 규칙이 제시되지 않았다. 공개 본문 검색 색인을 확인했으며 직접 페이지 재접속은 CAPTCHA로 제한되었다.

### C. WTEM-SST (2024): 반도체 wafer TEM, 상세 GT 규칙은 미확인

[IEEE 논문](https://ieeexplore.ieee.org/document/10517962/) · DOI: 10.1109/TSM.2024.3396423

반도체 wafer TEM의 노이즈, 불명확한 경계, 데이터 부족을 다루며 공정별 fine-tuning과 boundary-focused loss를 제안한다. 공개 초록을 확인했다. 상세 주석 도구, 애매한 경계의 픽셀 위치 결정, 검수자 수는 확인하지 못했다. 경계 손실이 존재한다는 사실만으로 GT를 gradient로 작성했다고 추론하면 안 된다.

### D. Boundary Enhanced Semantic Segmentation (EUSIPCO 2022): 반도체 SEM

[학회 원문 PDF](https://eurasip.org/Proceedings/Eusipco/Eusipco2022/pdfs/0000523.pdf)

전문가 지식이 필요한 IC SEM 주석에서 polygon 근사와 픽셀 수준 주석을 비교하고, 후자를 선택해 40개 영상을 수동 라벨링했다고 설명한다. 별도 boundary 학습과 Sobel 기반 boundary map도 다룬다. TEM이 아닌 SEM 사례이며, 원본 영상의 모든 gradient를 재료 계면 GT로 인정하는 근거는 아니다. 본 프로젝트의 edge 생성 구현은 클래스 마스크에서 유도하는 별도 명시적 규칙으로 설계한다.

### E. 다층 STEM 계면 검출과 사용자 보정 (2026 preprint)

[논문](https://arxiv.org/abs/2604.00359) · [원문·보충자료](https://arxiv.org/pdf/2604.00359) · [GitHub](https://github.com/utkarshp1161/thickness-mapping-webapp)

제목: AI-assisted Human-in-the-Loop Web Platform for Structural Characterization in Hard drive design.

HDD 다층 구조에서 smoothing, 세로 밝기 프로파일의 gradient peak, 거리 제약을 이용하고 사용자가 계면을 추가·삭제한다. 두께·거칠기를 계산한다. 보충자료는 인접 계면 간격을 고려한 탐색창 안에서 국소 gradient를 추적한다. 검증은 전문가 육안 비교로 제한되었다고 명시하며 사람 GT는 비공개다. 따라서 정량 정확도를 충분히 독립 검증한 표준 GT 생성법으로 해석하지 않는다.

아래 공개 `app.py`도 정적으로 읽었다. 설치나 실행은 하지 않았다.

[app.py](https://github.com/utkarshp1161/thickness-mapping-webapp/blob/main/app.py)

- `preprocess_image`: 가우시안 필터 후 행 평균 프로파일과 `np.gradient` 계산.
- `detect_peaks`: 절대 gradient의 percentile threshold, 최소 peak 간격, 개수 제한 사용.
- 원본/처리 영상/프로파일 표시와 자동·수동 계면의 색상 구분.
- 확인한 수동 peak 추가 경로는 x 범위를 입력받지만 계산은 전역 프로파일의 y 범위에서 수행한다. 완전한 국소 2D 계면 편집과 다르다.
- 픽셀 크기 메타데이터를 읽지 못하면 1.0을 설정하는 경로가 있다. 우리 도구에는 복사하지 않고 미보정 상태로 유지해야 한다.
- 공개 main 파일은 변경 가능하다. 도입 시 commit 고정, 라이선스 및 전체 코드·테스트 검토가 추가로 필요하다.

## 4. 관련 GitHub의 의미와 한계

### MatSAM

[공식 저장소](https://github.com/USTB-AI3DVIP/matsam) · [논문](https://arxiv.org/abs/2401.05638)

ROI와 grid 기반 prompt를 통해 재료 미세구조를 추출하는 SAM 기반 방법이다. 논문 초록의 주요 평가 범위는 OM/SEM이다. 반도체 다층 TEM의 계면 GT 정확도를 검증한 것으로 확대 해석하지 않는다. 자동 결과는 라벨 초안 후보로 평가할 수 있다.

### micro-sam

[공식 저장소](https://github.com/computational-cell-analytics/micro-sam)

현미경 영상의 interactive segmentation과 자동 분할을 제공한다. 클릭 기반 초안 생성 UI의 참고 자료이며 반도체 공정별 층 의미나 GT 경계 기준을 대신하지 않는다. 이번 조사에서는 README 수준 기능을 확인했다.

### pyCHIP

[PNNL 공식 저장소](https://github.com/pnnl/pychip_gui)

사용자가 TEM 영상의 작은 패치에 예시 라벨을 부여하여 특징을 분류하는 GUI다. README는 핵심 proprietary few-shot 모듈이 공개 배포에 포함되지 않았다고 명시한다. 완성된 픽셀 계면 GT 편집기로 간주하지 않는다.

### TEMImageNet

[연구팀 프로젝트](https://sites.google.com/view/temimagenet/home)

합성 ADF-STEM 영상에서 원자 좌표와 촬영 조건을 제공하여 원자 위치·원자열 관련 GT를 생성한다. 합성 영상의 알려진 좌표를 이용하는 접근으로, 실제 소자의 흐린 재료 계면을 수동 정의하는 문제와 다르다.

## 5. Superpixel과 edge GT에 대한 판단

이번 조사에서 superpixel+brush를 반도체 TEM 계면의 보편적인 정답 생성 표준으로 확인하지는 못했다. Superpixel은 작업량을 줄이는 편집 단위로 채택하고, 조각 경계가 재료 경계를 가로지를 때는 수정할 수 있어야 한다.

세 종류의 경계를 구별한다.

1. 원본 밝기 변화 edge: gradient/Canny 등의 후보. 내부 대비도 검출할 수 있다.
2. 승인한 클래스/층 사이 edge: segmentation에서 파생되는 학습용 계면 GT.
3. 계측 정의에 따른 계면 위치: 평균 위치, 법선 단면 위치 등 기준서가 정하는 측정 대상.

이 구분과 아래 설계는 조사 결과를 바탕으로 한 본 프로젝트의 제안이다.

## 6. 19.jpg 및 현업 고배율 영상에 적용할 요구사항

- 수평 적층용 전역 프로파일을 측벽과 모서리에 그대로 적용하지 않는다.
- 사람이 지정한 층 쌍·선택 구간에서 초기 경계 주위의 제한된 탐색대를 사용한다.
- 국소 법선 프로파일을 기본 후보로 하되 모서리/접합부는 구간 분리·anchor·수작업을 허용한다.
- 다중 peak, 약한 gradient, 인접 경계 침범, 큰 이동은 자동 적용하지 않는다.
- 원본 경계, 보정 후보, 승인 결과를 구분하고 보정 파라미터/버전을 저장한다.
- 승인 시 양쪽 segmentation을 갱신하고 edge를 재생성한다. 잠금은 모든 경로에서 보호한다.
- nm/pixel 미확인 상태에서는 px로만 보고한다. 고배율별 탐색 폭과 smoothing은 별도 검증한다.
- 실제 단차/거칠기를 평활화로 없애지 않도록 검수한다.

## 7. 코드 수정 전 결정사항

1. 대표 계면마다 물리적 층 의미와 영상상 경계 정의를 작성한다.
2. ISO 20263:2024 본문을 사내 표준 접근 경로로 확인하고 평균 계면 절차의 적용 범위를 검토한다.
3. 독립 수작업 GT를 만들고 합의 결과와 불확실 구간을 보존한다.
4. Gradient 후보와 비교할 때 보정 결과를 그대로 기준 GT로 사용하지 않는다.
5. 계면 위치 오차, 부호 있는 두께 편향, 큰 점프, 작업자 차이, 작업 시간을 비교한다.
6. 기본 다층 편집/잠금/비교/저장부터 구현하고 gradient는 미리보기 → 선택 적용 순서로 도입한다.

남은 한계: ReRAM/MRAM/SRAM 각각의 사내 계면 판정 기준은 공개 자료로 확정할 수 없다. 본 조사에서는 외부 모델 실행, 실제 고배율 영상 평가, 표준 적합성 검증을 수행하지 않았다.
