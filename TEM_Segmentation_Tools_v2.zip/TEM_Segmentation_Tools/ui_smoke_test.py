"""Exercise Tk callbacks with a hidden window, no human input or screenshot claims."""
from pathlib import Path
from types import SimpleNamespace
import tkinter as tk
import numpy as np
from core import Project, UNKNOWN
from gt_tool import GTApp

root=tk.Tk();root.withdraw();app=GTApp(root,autosave=False)
p=Project(np.tile(np.arange(100,dtype=np.uint8),(100,1)))
app.attach(p);root.update_idletasks()
app.scale=2;app.ox=10;app.oy=20
app.mode.set('brush');app.radius.set(3)
def event(x,y):return SimpleNamespace(x=10+x*2,y=20+y*2,widget=app.canvas)
app.down(event(30,30));app.motion(event(35,30));app.up(event(35,30))
assert p.mask[30,30]==1 and p.mask[30,35]==1
before=p.mask.copy();app.toggle_original()
app.down(event(60,60));app.up(event(60,60));np.testing.assert_array_equal(p.mask,before)
assert app.scale==2 and app.ox==10 and app.oy==20
app.space_press(event(0,0));value=app.original;app.space_press(event(0,0));assert app.original==value
app.space_release(event(0,0))
if app.original:app.toggle_original()
app.toggle_lock();app.mode.set('erase');app.down(event(30,30));app.up(event(30,30))
assert p.mask[30,30]==1
app.undo();assert not p.classes[1]['locked']
app.undo();assert (p.mask==UNKNOWN).all()
app.undo(True);assert p.mask[30,30]==1
app.mode.set('roi');app.down(event(20,20));app.motion(event(40,40));app.up(event(40,40))
assert app.roi==(20,20,41,41)
app.segments.set(30);app.split();assert p.seg[25,25]>0 and p.seg[0,0]==0
app.clear_roi();assert app.roi is None
app.quality = lambda: None
app.show_profile((10,10),(80,80));root.update_idletasks()
sample=Path(__file__).resolve().parent/'samples'/'19.jpg'
if not sample.exists():sample=Path(__file__).resolve().parents[2]/'sem_tem_cross_section_images'/'19.jpg'
if sample.exists():
    app.attach(Project.from_image(sample));app.scale=1.;app.ox=0;app.oy=0;app.draw();root.update_idletasks()
    assert app.project.raw.shape[:2]==(828,828)
print('PASS: brush interpolation, locked erase, original toggle/repeat, undo/redo, ROI, local SLIC, profile, 19.jpg render callbacks')
root.destroy()
