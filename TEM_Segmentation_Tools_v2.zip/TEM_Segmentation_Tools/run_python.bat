@echo off
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" %*
  exit /b
)
if exist "..\..\TEM_Segmentation_Tools_v1\TEM_Segmentation_Tools\.venv\Scripts\python.exe" (
  "..\..\TEM_Segmentation_Tools_v1\TEM_Segmentation_Tools\.venv\Scripts\python.exe" %*
  exit /b
)
python %*
