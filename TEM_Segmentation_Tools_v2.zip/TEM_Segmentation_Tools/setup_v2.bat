@echo off
cd /d "%~dp0"
python -m venv .venv
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
echo Setup complete. Run start_gt.bat or start_demo_19.bat.
pause
exit /b 0
:failed
echo Setup failed. Check Python and network/package access.
pause
exit /b 1
