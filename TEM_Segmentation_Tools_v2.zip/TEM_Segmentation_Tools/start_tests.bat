@echo off
cd /d "%~dp0"
call run_python.bat test_v2.py
if errorlevel 1 goto end
call run_python.bat ui_smoke_test.py
:end
pause
