"""Regression checks of GT safety and storage; no external data/network."""
import json
from pathlib import Path
import tempfile
import unittest
import numpy as np
from PIL import Image
from scipy import ndimage as ndi
from core import Project, UNKNOWN, UNCERTAIN, EXCLUDED, boundary_data


class GTTests(unittest.TestCase):
    def project(self):
        return Project(np.arange(64*64,dtype=np.uint16).reshape(64,64),'synthetic')

    def test_locked_pixels_and_destination(self):
        p=self.project();p.mask[:,:32]=1;p.classes[1]['locked']=True
        selection=np.ones(p.mask.shape,bool)
        p.paint(selection,0)
        self.assertTrue((p.mask[:,:32]==1).all())
        self.assertTrue((p.mask[:,32:]==0).all())
        self.assertEqual(p.paint(selection,1),0)
        p.paint(selection,UNKNOWN,brush=True)
        self.assertTrue((p.mask[:,:32]==1).all())

    def test_brush_protection_and_unknown_only(self):
        p=self.project();selection=np.zeros(p.mask.shape,bool);selection[10:20,10:20]=True
        p.paint(selection,1,brush=True)
        p.paint(np.ones(p.mask.shape,bool),0,protect_brush=True)
        self.assertTrue((p.mask[selection]==1).all())
        self.assertEqual(p.paint(selection,0,only_unknown=True),0)

    def test_undo_lock_order(self):
        p=self.project();p.checkpoint();p.mask[:]=1;p.changed('paint')
        p.checkpoint();p.classes[1]['locked']=True
        p.undo();self.assertFalse(p.classes[1]['locked']);self.assertTrue((p.mask==1).all())
        p.undo();self.assertTrue((p.mask==UNKNOWN).all())
        p.undo(True);self.assertTrue((p.mask==1).all())

    def test_split_preserves_gt_brush_locks(self):
        p=self.project();p.mask[20:40]=1;p.brushed[20:40]=True;p.classes[1]['locked']=True
        mask=p.mask.copy();brush=p.brushed.copy()
        p.split((0,0,64,64),100)
        p.split((16,16,48,48),50)
        np.testing.assert_array_equal(p.mask,mask);np.testing.assert_array_equal(p.brushed,brush)
        self.assertTrue(p.classes[1]['locked']);self.assertGreater(p.seg.max(),1)

    def test_roundtrip_16bit_and_state(self):
        p=self.project();p.mask[:20]=1;p.mask[20:30]=UNCERTAIN;p.mask[30:40]=EXCLUDED
        p.brushed[:10]=True;p.classes[1]['locked']=True;p.meta['author']='홍길동';p.split((0,0,64,64),100)
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'sample.temgt.npz';p.save(path);q=Project.load(path)
            np.testing.assert_array_equal(q.raw,p.raw);np.testing.assert_array_equal(q.mask,p.mask)
            np.testing.assert_array_equal(q.seg,p.seg);np.testing.assert_array_equal(q.brushed,p.brushed)
            self.assertEqual(q.classes,p.classes);self.assertEqual(q.meta['author'],'홍길동')
            self.assertEqual(q.raw.dtype,np.uint16);self.assertFalse(q.dirty)

    def test_edge_ignore_border_and_pair(self):
        p=self.project();p.mask[:,:32]=0;p.mask[:,32:]=1;p.mask[20:25]=UNKNOWN
        edge,valid,pairs=boundary_data(p.mask,[0,1])
        self.assertFalse(edge[0].any());self.assertFalse(edge[-1].any())
        self.assertFalse(edge[19:26].any());self.assertFalse(valid[19:26].any())
        self.assertEqual(set(pairs),{'0_1'})
        self.assertTrue(edge[10,31]);self.assertTrue(edge[10,32]);self.assertFalse(edge[10,30])

    def test_three_way_junction(self):
        m=np.zeros((20,20),np.uint16);m[:10,10:]=1;m[10:,10:]=2
        edge,valid,pairs=boundary_data(m,[0,1,2])
        self.assertEqual(set(pairs),{'0_1','0_2','1_2'})
        rebuilt=np.zeros_like(edge)
        for coords in pairs.values():rebuilt[coords[:,0],coords[:,1]]=True
        np.testing.assert_array_equal(edge,rebuilt)

    def test_export_empty_folder_and_label_integrity(self):
        p=self.project();p.mask[:,:32]=0;p.mask[:,32:]=1;p.mask[30:33]=UNCERTAIN
        with tempfile.TemporaryDirectory() as d:
            p.export(d)
            np.testing.assert_array_equal(np.array(Image.open(Path(d)/'mask_labels_uint16.png')),p.mask)
            np.testing.assert_array_equal(np.load(Path(d)/'raw.npy'),p.raw)
            with np.load(Path(d)/'edge_pairs_yx.npz',allow_pickle=False) as pairs:self.assertIn('0_1',pairs)
            with self.assertRaises(ValueError):p.export(d)

    def test_v1_import_no_automatic_approval(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d);Image.fromarray(np.zeros((20,20,3),np.uint8)).save(f/'image.png')
            m=np.zeros((20,20),np.uint8);m[5:10]=1;m[10:]=255;Image.fromarray(m).save(f/'mask.png')
            (f/'metadata.json').write_text(json.dumps({'gt_reviewed':True}),encoding='utf-8')
            p=Project.import_v1(f)
            self.assertTrue((p.mask[10:]==UNKNOWN).all());self.assertEqual(p.meta['review_status'],'draft')

    def test_gradient_moves_towards_known_synthetic_edge(self):
        # Image step is at x=34, annotation step at x=32.
        raw=np.zeros((64,64),np.float32);raw[:,34:]=1
        p=Project(raw);p.mask[:,:32]=0;p.mask[:,32:]=1
        before=p.mask.copy()
        candidate,stats=p.gradient_preview(0,1,(0,0,64,64),radius=5,sigma=1,min_gradient=.02)
        self.assertGreater(stats['changed_pixels'],0);self.assertTrue(stats['topology_ok'])
        truth=np.zeros_like(before);truth[:,34:]=1
        self.assertLess(np.count_nonzero(candidate[5:-5]!=truth[5:-5]),np.count_nonzero(before[5:-5]!=truth[5:-5]))
        changed=candidate!=before
        self.assertFalse(changed[:,:26].any());self.assertFalse(changed[:,38:].any())
        p.apply_preview(candidate,stats,p.revision);p.undo();np.testing.assert_array_equal(p.mask,before)

    def test_gradient_flat_and_locked_rejection(self):
        p=Project(np.zeros((64,64),np.uint8));p.mask[:,:32]=0;p.mask[:,32:]=1
        candidate,stats=p.gradient_preview(0,1,(0,0,64,64))
        np.testing.assert_array_equal(candidate,p.mask)
        self.assertEqual(stats['candidate_points'],0)
        p.classes[1]['locked']=True
        with self.assertRaises(ValueError):p.gradient_preview(0,1,(0,0,64,64))

    def test_gradient_roi_and_stale_preview(self):
        raw=np.zeros((64,64),np.uint8);raw[:,34:]=255
        p=Project(raw);p.mask[:,:32]=0;p.mask[:,32:]=1
        candidate,stats=p.gradient_preview(0,1,(20,20,45,45),radius=5)
        np.testing.assert_array_equal(candidate[:20],p.mask[:20])
        np.testing.assert_array_equal(candidate[45:],p.mask[45:])
        revision=p.revision;p.changed('edit')
        with self.assertRaises(ValueError):p.apply_preview(candidate,stats,revision)

    def test_image_load_preserves_uint16(self):
        with tempfile.TemporaryDirectory() as d:
            raw=np.arange(10000,dtype=np.uint16).reshape(100,100)
            path=Path(d)/'test.tif';Image.fromarray(raw).save(path)
            p=Project.from_image(path);np.testing.assert_array_equal(p.raw,raw)

    def test_edit_demotes_approval(self):
        p=self.project();p.meta.update(review_status='approved',reviewer='reviewer')
        p.changed('brush');self.assertEqual(p.meta['review_status'],'draft');self.assertEqual(p.meta['reviewer'],'')


if __name__=='__main__':unittest.main(verbosity=2)
