import csv,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
from PIL import Image
import torch
from test_pipeline import tiny_sam
from temlab.models import Engine,Predictor,sam_model_registry,safe_load
from temlab.train import train_experiment
from temlab.monitoring import summarize,improves


class LastLayerTests(unittest.TestCase):
    def fixture(self,p):
        sam_model_registry['vit_test']=tiny_sam
        torch.manual_seed(17)
        base=p/'base.pt';torch.save(tiny_sam().state_dict(),base)
        cfg=json.loads((Path(__file__).parents[1]/'config.example.json').read_text())
        cfg.update(sam_checkpoint=str(base),model_type='vit_test',device='cpu',encoder_amp=False,
                   class_names={'1':'synthetic'},
                   decoder_scope='last_layer',cache_dir=str(p/'cache'),output_dir=str(p/'runs'),
                   manifest=str(p/'manifest.csv'),epochs=2,patience=2,abl_warmup_epochs=0,
                   loss_side=64,prompts_per_region=1,background_samples_per_image=0)
        rows=[]
        for i,split in enumerate(['train','val']):
            im=np.random.default_rng(i).integers(0,255,(48,64,3),dtype=np.uint8)
            gt=np.zeros((48,64),np.uint8);gt[10:30,15:40]=1
            Image.fromarray(im).save(p/f'i{i}.png');Image.fromarray(gt).save(p/f'g{i}.png')
            rows.append(dict(image_id=str(i),image=str(p/f'i{i}.png'),mask=str(p/f'g{i}.png'),group=str(i),split=split))
        with open(cfg['manifest'],'w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
        return cfg,im

    def test_optimizer_changes_only_last_linear_and_reload_matches(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);cfg,im=self.fixture(p);engine=Engine(cfg,'decoder')
            names={n for n,v in engine.sam.named_parameters() if v.requires_grad}
            prefix='mask_decoder.output_hypernetworks_mlps.0.layers.2.'
            self.assertEqual(names,{prefix+'weight',prefix+'bias'})
            before={k:v.clone() for k,v in engine.sam.state_dict().items()}
            opt=torch.optim.AdamW([v for v in engine.trainable.parameters() if v.requires_grad],lr=1e-6,weight_decay=0.)
            enc=engine.encode(im);prompt=dict(points=[[20,20]],labels=[1])
            z,_=engine.predict_logits(im,enc,prompt,train=True)
            torch.nn.functional.binary_cross_entropy_with_logits(z,torch.ones_like(z)).backward();opt.step()
            changed={k for k,v in engine.sam.state_dict().items() if not torch.equal(v,before[k])}
            self.assertEqual(changed,names)
            engine.save(p/'adapt.pt')
            predictor=Predictor(cfg['sam_checkpoint'],p/'adapt.pt',device='cpu',cache_dir=p/'ui')
            predictor.set_image(im)
            actual=predictor.predict(**prompt)['probability']
            with torch.no_grad():expected=engine.predict_logits(im,enc,prompt)[0].sigmoid()[0,0].numpy()
            np.testing.assert_array_equal(actual,expected)

    def test_both_new_experiments_fallback_and_last_weights(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);cfg,_=self.fixture(p)
            cfg['selection_min_delta']=2. # Force failure even if synthetic scores improve.
            original=torch.load(cfg['sam_checkpoint'],weights_only=True)
            for name in ('decoder_last_noabl','decoder_last_abl'):
                path=Path(train_experiment(cfg,name));pack=safe_load(path)
                self.assertTrue(pack['extra']['baseline_fallback'])
                self.assertEqual(pack['extra']['epoch'],0)
                self.assertEqual(pack['method'],'decoder')
                self.assertEqual(pack['config']['decoder_lr'],1e-6)
                for k,v in pack['state'].items():self.assertTrue(torch.equal(v,original['mask_decoder.'+k]))
                last=safe_load(path.parent/'last.pt')
                changed={k for k,v in last['state'].items() if not torch.equal(v,pack['state'][k])}
                self.assertTrue(changed)
                self.assertTrue(all(k.startswith('output_hypernetworks_mlps.0.layers.2.') for k in changed))
                self.assertEqual(len(json.loads((path.parent/'history.json').read_text())),2)

    def test_paired_guard_rejects_regression_despite_average_gain(self):
        def row(i,d,b):return dict(image_id=str(i),gt_index=0,dice=d,iou=d,boundary_f1=b,mean_boundary_distance_px=1.)
        base=[row(0,.9,.9),row(1,.5,.4)]
        bad=[row(0,.86,.85),row(1,.8,.8)]
        s=summarize(bad,base,{})
        self.assertGreater(s['delta_boundary_f1'],0)
        self.assertEqual(s['regressed_good_targets'],1)
        self.assertFalse(improves(s,.65,{}))
        good=[row(0,.9,.9),row(1,.6,.6)]
        self.assertTrue(improves(summarize(good,base,{}),.65,{}))
        missing=summarize([row(1,.6,.6)],[row(1,.5,.4)],{})
        self.assertEqual(missing['baseline_good_targets'],0)

    def test_accepted_checkpoint_selection(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);cfg,_=self.fixture(p);cfg['epochs']=1
            def detail(b):return [dict(image_id='1',gt_index=0,class_id=1,dice=.9,iou=.82,boundary_f1=b,mean_boundary_distance_px=1.)]
            with patch('temlab.train.validate',side_effect=[(.9,detail(.85)),(.9,detail(.9))]):
                path=train_experiment(cfg,'decoder_last_noabl')
            pack=safe_load(path)
            self.assertFalse(pack['extra']['baseline_fallback'])
            self.assertEqual(pack['extra']['epoch'],1)
