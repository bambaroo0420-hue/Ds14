"""Paired validation diagnostics, not automatic grid performance guarantees."""
import numpy as np


def image_mean(rows, key):
    groups={}
    for row in rows:
        if row[key] is not None:
            groups.setdefault(row['image_id'],[]).append(row[key])
    return float(np.mean([np.mean(v) for v in groups.values()])) if groups else None


def summarize(rows, baseline, cfg):
    index=lambda r:(r['image_id'],r['gt_index'])
    original={index(r):r for r in baseline}
    if {index(r) for r in rows} != set(original):
        raise ValueError('Validation target identities changed')
    good=[r for r in rows if original[index(r)]['dice']>=cfg.get('retention_good_dice',.8)
          and original[index(r)]['boundary_f1']>=cfg.get('retention_good_boundary_f1',.8)]
    drop=cfg.get('retention_max_drop',.02)
    regressed=[r for r in good if any(original[index(r)][k]-r[k]>drop+1e-12
                                    for k in ('dice','boundary_f1'))]
    result={f'val_{k}':image_mean(rows,k) for k in
            ('dice','iou','boundary_f1','mean_boundary_distance_px')}
    result.update(delta_dice=result['val_dice']-image_mean(baseline,'dice'),
                  delta_boundary_f1=result['val_boundary_f1']-image_mean(baseline,'boundary_f1'),
                  retained_good_targets=len(good)-len(regressed),
                  baseline_good_targets=len(good),regressed_good_targets=len(regressed),
                  boundary_distance_valid_targets=sum(r['mean_boundary_distance_px'] is not None for r in rows),
                  validation_targets=len(rows))
    result['retention_pass']=not regressed and result['delta_dice']>=-cfg.get('max_mean_dice_drop',.005)-1e-12
    return result


def improves(summary, best_boundary_f1, cfg):
    return summary['retention_pass'] and summary['val_boundary_f1']>best_boundary_f1+cfg.get('selection_min_delta',.001)
