/* Recommendations do not mutate masks or assign layers. */
export function mountMaskMatching(T){
 const $=id=>document.getElementById(id);let result=null;
 const box=document.createElement('section');box.id='maskMatchResults';$('matchLayers').parentElement.append(box);
 const home=box.parentElement,large=document.createElement('button'),dialog=document.createElement('dialog'),close=document.createElement('button');
 large.textContent='추천 비교 크게 보기';home.insertBefore(large,box);dialog.style.cssText='width:min(1100px,92vw);max-height:90vh;overflow:auto';
 close.textContent='비교 창 닫기';dialog.append(close);document.body.append(dialog);
 large.onclick=()=>{dialog.append(box);dialog.showModal()};close.onclick=()=>dialog.close();dialog.addEventListener('close',()=>home.append(box));
 const batchMatch=document.querySelector('[data-job-step="match"]');if(batchMatch){batchMatch.nextSibling.textContent='마스크 상위 3개 추천만 (배정은 SAM·레이어에서)';}
 async function search(){
  result=null;box.replaceChildren();
  const r=await T.api('workflow/layers/match',{reference_image:$('referenceImage').value,image_id:T.current,threshold:+$('matchThreshold').value});
  result=r;render();T.say('상위 3개 추천 완료. 아직 배정하지 않았습니다. 후보를 비교하고 하나를 선택하세요.');
 }
 function render(){
  box.replaceChildren();if(!result)return;
  const note=document.createElement('p');note.textContent='청록=기준, 주황=후보, 흰색=겹침. 비교용 모양만 정렬하며 실제 마스크는 변경하지 않습니다. 회전 ±30°/5° 간격, 긴 변 64px 정규화. 순위는 IoU 우선·동점이면 윤곽 거리. 점수는 물질 정답 확률이 아닙니다.';box.append(note);
  for(const row of result.proposals){
   const section=document.createElement('fieldset'),legend=document.createElement('legend');legend.textContent=`${row.layer_name} · 기준 #${row.reference_candidate_id}${row.locked?' · 잠김':''}${row.assigned_candidate_id?' · 배정 완료 #'+row.assigned_candidate_id+' (교체하려면 기존 배정 해제)':''}`;section.append(legend);
   const ref=document.createElement('img');ref.src=row.reference_preview;ref.alt=`기준 마스크 ${row.reference_candidate_id}`;ref.width=112;section.append(ref);
   if(!row.candidates.length){const p=document.createElement('p');p.textContent='미배정 후보가 없습니다.';section.append(p);}
   const cards=document.createElement('div');cards.style.cssText='display:flex;flex-wrap:wrap;gap:12px';
   row.candidates.forEach((c,i)=>{
    const card=document.createElement('div');card.style.cssText='flex:1;min-width:190px;border:1px solid #64748b;padding:10px';
    const title=document.createElement('h4');title.textContent=`${i+1}위 · 후보 #${c.candidate_id}`;
    const im=document.createElement('img');im.src=c.overlay;im.alt=`후보 ${c.candidate_id} 정렬 비교`;im.width=160;
    const info=document.createElement('p');info.textContent=`IoU ${c.score.toFixed(3)} · 윤곽거리 ${(c.contour_distance*100).toFixed(2)}% · 면적비 ${c.area_ratio.toFixed(2)} · 크기보정 ${c.scale_to_reference.toFixed(2)}배 · 회전 ${c.angle}°${c.below_threshold?' · 낮은 유사도!':''}`;
    const locate=document.createElement('button');locate.textContent='원본에서 위치 보기';locate.onclick=async()=>{if(!result||result.image_id!==T.current){T.say('후보를 다시 검색하세요.');return;}if(dialog.open)dialog.close();await T.chooseCandidate(c.candidate_id);T.say(`후보 #${c.candidate_id} 선택. 원본 위의 후보 마스크를 확인하세요.`)};
    const label=document.createElement('label'),check=document.createElement('input');check.type='checkbox';label.append(check,document.createTextNode('낮은 유사도임을 확인'));label.hidden=!c.below_threshold;
    const apply=document.createElement('button');apply.textContent='이 후보 1개 배정';apply.disabled=row.locked||!!row.assigned_candidate_id||c.below_threshold;
    check.onchange=()=>{apply.disabled=row.locked||!!row.assigned_candidate_id||(c.below_threshold&&!check.checked)};
    apply.onclick=()=>T.task(async()=>{
     if(!result||result.image_id!==T.current)throw Error('후보를 다시 검색하세요.');
     await T.api('workflow/layers/match/accept',{reference_image:result.reference_image,image_id:result.image_id,signature:result.signature,threshold:result.threshold,reference_candidate_id:row.reference_candidate_id,candidate_id:c.candidate_id,allow_low_score:check.checked});
     result=null;box.replaceChildren();if(dialog.open)dialog.close();await T.refresh();T.say(`후보 #${c.candidate_id} 하나를 배정했습니다. 경계 검수는 별도입니다. 다음 배정 전 후보를 다시 검색하세요.`);
    });card.append(title,im,info,locate,label,apply);cards.append(card);
   });section.append(cards);
   const skip=document.createElement('button');skip.textContent='해당 없음 · 이 추천 닫기';skip.onclick=()=>{section.remove();T.say('배정하지 않았습니다. 후보 편집 또는 ROI 추가 분할 후 다시 검색하세요.')};section.append(skip);box.append(section);
  }
 }
 $('matchLayers').onclick=()=>T.task(search);
 for(const id of ['referenceImage','matchThreshold'])$(id).addEventListener('change',()=>{result=null;box.replaceChildren()});
 window.addEventListener('tem:refreshed',()=>{result=null;box.replaceChildren()});
}
