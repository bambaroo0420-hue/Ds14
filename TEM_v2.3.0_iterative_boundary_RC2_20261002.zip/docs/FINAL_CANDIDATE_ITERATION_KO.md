# 최종 후보 반복 검증 — 2026-10-02 오전 8시까지

## 시간과 원칙

- 시작: 2026-10-02 01:42 KST. 종료: 2026-10-02 08:00 KST = 2026-10-01 23:00 UTC.
- heartbeat 20분 간격으로 이 대화에서 이어간다. 매회 실제 시각 확인. 종료 후 새 실험 금지, 보고/패키징/자동화 정지.
- 원본 영상/GT/사용자 프로젝트 보존. 코드: `_tem_v2_build`. 시험: `test-output/final-candidate-20261002`.
- GT는 알고리즘 입력이 아닌 평가용. 합성/전문가/모델 결과(pseudo-GT)를 반드시 구분.
- 이전 교체 ZIP을 덮어쓰지 않는다. 검증 후 새 이름으로 패키징. 자동 GitHub 업로드나 Desktop 동기화 없음.

## 발견한 중요한 구현 사실

- 직전 패치: 마스크 top3 비교/1개 선택 배정. Python 248, JS 8 통과(직전 턴).
- `tem_analyzer/boundary.py`에는 이미 단회 폐곡선 법선 Gradient+DP가 있다. 법선 보정이 전혀 없다는 뜻이 아니다.
- 05:45 반복 법선/고정 최초 탐색띠 코어 추가, 06:31 UI/API/실제19 적용Undo확인. 실제22 비교완료. 연속 이동궤적/일괄연결/부분고정점 미완료. 기존 단회 기본값 유지.
- 기존 코드 `corner` 조건은 모서리점을 강제 고정한다. `uncertain`에 탐색 끝 도달점을 포함해 다시 원위치 고정한다. 그 때문에 큰 축소 마스크에서 이동이 제한될 가능성을 시험할 것.
- crossing()은 03:45 수정으로 자기접촉/공선중첩도 검사한다. 서로 다른 loop 간 연속 교차와 전체 이동궤적 안전성은 아직 보장하지 않는다.

## 수행 순서

1. [진행] 기존 자료 목록/출처/GT 신뢰도 점검, 기존 보정의 축소/팽창 마스크 baseline 측정.
2. [부분 완료] 실제 자료22개 경계 보정, 19 증강7개 top3/API 확인. 실제 GUI 전 기능/전 영상 검증은 미완료.
3. [부분 완료] 취소 보존·작은 contour·픽셀 중심 raster·교차 검사 개선. guarded 모서리는 실험용이며 기본값 채택하지 않음.
4. [부분 완료] Python275 통과, JS8 통과. GUI 경계프로파일/취소/반복적용Undo 확인. 07:17 19 +7도 이미지 회전·두께/CD·통계/좌표ZIP GUI 종단 검증 완료. 전 버튼·전 영상 검증을 뜻하지 않음.
5. [진행] 합성16 및 stress30, 실제22, 회전14조건, top3/API7건 결과·비교 PNG·한계 기록. 실제 영상의 전문가 GT 없음.
6. [부분 완료] RC1b 교체ZIP/checksum/사용·필수작업MD작성. 8시종료정리와heartbeat정지대기.

## 자료 후보

- `layer_benchmark/results_valid/synthetic/*/image.png`, `gt.png`: 기존 합성 자료. GT 배경/레이어값을 확인한 뒤 사용.
- `_tem_v2_build/test-output/crop19-v220`: 19 기반 회전/복수 cell 자료.
- `inspection/decoder_v1_4/extracted/tem_sam_decoder_lab/validation`: 공개 GT 검증 스크립트/자료 경로 조사.
- `layer_benchmark/results_valid/deliverables`: 모델/알고리즘 제안 마스크, 전문가 GT 아님.

## 실험 기록

### 01:42~ 초기 점검

시간 범위 확인, 코드 baseline 점검, 반복 작업 설정. 다음은 축소/팽창 입력의 기존 refine_all 측정.

### 첫 baseline 완료 (자동화 ID: tem-8)

- 추가 도구: `tools/audit_shrunken_boundary.py`. 실행: 기존 .venv Python으로 `tools/audit_shrunken_boundary.py --name baseline`.
- 기존 운영 알고리즘 소스는 아직 변경하지 않았다.
- 합성 영상 4개(뚜렷한 타원, 흐린 타원, 모서리 사각형, 오목한 L형) × 침식 3/8/15 px 및 팽창 8 px = 16개.
- GT는 도형의 분석적 정답. GT를 입력 마스크 생성/평가에만 사용, refine_all에는 영상·왜곡된 mask·전체 valid만 전달.
- 기존 기본 DP, inside/outside 25px. 평균 대칭 경계거리 8.173→2.509px. 16개 중 15개 경계거리 개선이나 이것만으로 성공 판정 금지.
- 작은 흐린 타원(-15px): IoU 0.580→0.967. 작은 선명 타원: 0.580→0.981.
- 작은 사각형(-15px): 0.569→0.858, 모서리 근처 계단형 미복구가 비교 이미지에 명확함.
- 팽창 사각형(+8px): 0.790→0.780, 오히려 악화.
- 작은 오목 L형(-15px): 0.426→0.442, 거의 복구 못함.
- 증거: `test-output/final-candidate-20261002/baseline/results.json`, `comparison.png` (초록 GT/빨강 입력/청록 보정). 이미지를 직접 확인함.
- 공개 decoder validation의 CamVid 스크립트는 색상 라벨 추출 검증이다. TEM 물질 경계 GT로 혼용하지 말 것.

## 다음 실행의 구체 작업

### 07:31~07:36 KST RC2 적용 안전성 보완 및 문서 정합성

- 발견: 경계 미리보기 뒤 설정/인접 후보/고정점 등을 바꿔도 기존 token을 적용할 수 있었다. 사용자 의도와 이전 계산 결과가 달라질 위험이다.
- `web/v2.js`: 미리보기 입력의 image/candidate/neighbor/revision/settings/pins/overrides 서명을 저장하고 적용 직전 비교. 달라졌으면 mutation API 호출 없이 재미리보기 안내. 취소/후보 변경 시 서명도 제거. 설정 변경은 자동 재계산하지 않으며 이전 시각화는 남을 수 있다.
- `tests/ui_regression.cjs`: 정상 서명 통과, 8개 설정·대상 필드 변경, 고정점/부분설정 변경, 불일치 시 실제 apply 핸들러의 네트워크 요청 0건, 취소 초기화 확인. 실제 브라우저에서 이 새 guard를 재시험한 것은 아니다.
- 전체 Python275/275, failures/errors/skipped0, 46.44초. `test-output/test-output/final-candidate-stale-preview-tests/all-tests.json` (실행 output 인자에 test-output을 중복 입력하여 중첩 경로임). JS8 suite 전부 통과. 설치 메시지는 설치 mock 회귀의 출력이며 새 패키지/모델을 다운로드하지 않았다.
- 배포MD의 회전·계측GUI 미완료 표현을 07:17 실제 증거에 맞게 수정. 전체 버튼/모든 영상 검증과 전문가 정확도는 여전히 미완료. 경계 알고리즘 계산은 RC1b와 동일하다.
- RC2 누적 교체본은 이전 ZIP을 보존하고 새 이름으로 생성한다. 기존 v2.3.0 필요, 모델/영상/프로젝트 미포함. 새 guard 외 기존 실측 수치는 이전 실행 결과이고 재실험으로 꾸미지 않는다.
- 다음: 종료시각 재확인, 최종 산출물/남은 한계 정리. 08:00 KST 이후 새 실험 없이 tem-8 PAUSED.


### 07:11~07:18 회전·계측 실제 GUI 종단 검증

- 별도 `test-output/final-candidate-20261002/gui-19-metrology` 프로젝트만 사용. 모델 재실행이 아니라 저장된 19 SAM 후보에 대한 회전·계측 시험.
- 실제 브라우저에서 `19_crop_1cell_+07deg.png` 선택 → 4 회전·계측 → 회전 제안 → 확인·확정 → 근거 시각화 → 중앙 60% / 다중 교차 제외 → 두께 실행 → CD 실행 → 이력 ZIP 및 좌표 ZIP 저장.
- 자동 위쪽 경계 회전각 -6.7730°, 직선 잔차 0.38564px. 사용 기준점·피팅선 및 원본/회전 좌표 계측선을 실제 화면에서 확인. GT 생성 불필요.
- 두께 유효 14 / 전체 50, 평균 165.475438 / 모집단 표준편차 3.567412. CD 유효 8 / 전체 63, 평균 278.446346 / 모집단 표준편차 1.826025. 단위 표시는 nm이나 이 영상의 100nm/81px는 시험용 합성 스케일이다. 물리적 TEM 계측 정확도로 해석하지 말 것. 미검수 SAM의 잠정 계측 경고가 유지됨.
- 이전 저장 결과는 만료로 표시되었고 재실행 후 두 방향 모두 현재 입력과 일치로 갱신됨. 실행별 JSON 2개 및 CSV에 동일 수치 저장, ZIP CRC 오류 없음.
- 브라우저 download 이벤트 대기는 30초 후 시간 초과했지만 실제 다운로드는 완료되어 있었다. 앱 오류로 판정하지 않음. Downloads의 파일 시각/내용을 확인해 증거 사본 보존.
- 증거: 해당 시험 폴더 `rotation-evidence.png`, `thickness-evidence.png`, `gui-statistics.zip` (JSON 2 + summary.csv + measurements.csv + README), `gui-results.zip` (회전 영상/라벨/valid/변환 JSON/두 방향 계측 JSON).
- 이번 시험은 런타임 코드 변경 없음. RC1b 코드에 대한 추가 검증이다. 다음 실행: 남은 미완료 항목과 최종 문서/패키지 정합성 점검, 08시 이후 신규 실험 없이 종료 정리.


### 06:51~06:55 KST — 교체 ZIP RC1b 구성/검증

- `docs/FINAL_CANDIDATE_RELEASE_KO.md`: 적용/백업/복구/조작순서/성과와한계/미완료명시. 누적runtime17파일(직전top3패치14 + boundary.py/boundary_iterative.py/v2.js), 문서·선별회귀·결과JSON·합성비교PNG 포함. 실제이미지/프로젝트/모델/가상환경없음. 독립설치본아닌기존v2.3.0용교체본.
- `tools/build_final_candidate_patch.py`는새ZIP만생성, 모든runtime파일SHA256+zipCRC+PythonAST검증. 초기패키징에서인코딩명utf8-sig오타로검증중단; utf-8-sig로수정하고**새이름RC1b**로전체재검증통과. 초기RC1파일은실패증거로보존하며배포하지않는다.
- 제공대상: `../output/final-candidate-patch/TEM_v2.3.0_iterative_boundary_RC1b_20261002.zip`,406672bytes, SHA256 `5ff8bc258114594ea3e90b4440aa5b80a88cef5d0cc622503ee136f4288ddb7a`. sidecar `.zip.sha256` 생성. 자동GitHub업로드/Desktopsync없음.
- ZIP의실험기록은패키징직전스냅샷이며이패키징절은로컬후속기록이다. 현재코드최신검증은Python275/JS8. 종료전추가수정시새RC이름으로다시검증/패키징할것(기존ZIP덮어쓰기금지).
- 다음: 8시이전남은GUI회전계측종단검증가능범위확인, 종료시새실험금지/최종MD정리/tem-8 PAUSED. 대안RandomWalker/ChanVese는제안단계이며패키지에구현했다고주장하지않음.


### 06:31~06:37 KST — 반복 코어 UI/API 연결 및 실제GUI 적용/Undo

- index.html에 방식(single기본/iterative실험),반복2~40,단계.25~2,초기평활화off/1,모서리freeze/guarded선택. v2.js settings전달/종료사유/코어변경vs최종변경 구분. API는 iteration_report와최초contour 반환. 초기노랑/마지막단계흰·주황·청록 구분, 프로파일은누적아님 명시. cache boundary-4.
- 실제 API 테스트는 코어mock없이 preview/report/최초경계/적용/Undo. 전체 Python **275/275**, JS **8 suite**통과. 증거 `final-candidate-iterative-ui-tests/all-tests.json`.
- computer-use 지침 사용. prepare_iterative_gui.py로 원본19프로젝트 별도복사, 기존SAM후보를8px침식한#12를L1에배정, 명시적테스트배경지정. 원본/GT프로젝트불변. localhost8899 실제화면에서 반복/guarded선택→미리보기→적용→Undo.
- 실제화면:12회승인/최대반복/띠밖변경0/최종5236px변경. #12 면적24627→#13 boundary 면적29845, Undo후#12/24627복귀. 노랑최초경계와마지막단계경계 표시확인. 탐색폭끝도달경고도유지. 적용으로정답GT가되었다고주장하지않음.
- `gui-iterative/preview.png` 저장·시각확인. 테스트서버PID16292와임시탭35종료. `docs/ITERATIVE_NORMAL_KO.md` 실제조작순서갱신.
- 남은범위: 탐색띠면적 직접시각화,반복고정점/부분구간,일괄파이프라인연결,전체이동궤적안전성 미완료. 이 화면추가가다른레이어자동보정/일괄에도적용됐다는뜻아님. 8시전최종교체ZIP/사용법/검증제한정리필수.


### 06:11~ 최초 고정band 회귀 확대 + 실제 반복 비교

- `test_boundary_iterative.py` 추가3건: 매 단계 search_domain이 최초 band와 완전히 동일함, band밖14px의 강한 경계를 탐색폭3px로 선택하지 않음, 안전거부 제안이 실제 적용된 offset처럼 반환되지 않음. 마지막 경우 `boundary_iterative.py`의 거부 단계 loops/refined/offset/uncertain을 원상 유지 상태로 정리했다(최종mask는 이미 보존되던 상태).
- 전체 Python **274/274 통과**, `test-output/final-candidate-fixed-band-tests/all-tests.json`. 알고리즘이 안전한 연속궤적을 완전히 보장한다는 뜻은 아님.
- 실제자료 비교 `tools/audit_real_boundary_bias.py --name real-iterative-v1 --iterations 12 --corner-mode guarded` 실행. 초기평활화off, 원본영역제외 유지, 이전SAM을 침식/팽창8px하여입력. 최초3개후보/각소스, 기존22조건과 동일. 실행중 단계history는 결과JSON에 누적한다. 이 실행은 거부 메타데이터 수정 직전 import되었으나 실제 mask 계산은 동일하다.
- 다음 필수: 실제22 결과요약을 아래 덧붙인 후 UI 연결/최초·최종경계 시각화/적용취소 검증. UI에 없는 코어 옵션을 사용가능한 완성기능이라고 보고하지 말 것.
- 실제22 완료: 예외0, 입력왜곡마스크 대비 ASSD개선17/유지4/악화1, 최초band밖변경0. 악화는 공개후보8 팽창8: 8.5391→9.1586px. 단회기본freeze 결과와 직접 비교하면 반복guarded가13개 더좋음/6개 더나쁨/3개동일. 따라서 입력대비17개개선을 기존방식대비17개개선이라고 표현하지 말 것. corner모드와 반복횟수 효과도 혼합되어 있다.
- 실제19 첫후보 침식8: IoU .8224→.9593, ASSD7.7792→1.7624px. 00-overlay.png 직접확인: 외곽쪽확장은 개선되지만 기존SAM 밖으로 더 나간 부분도 있다. 기준은기존SAM pseudo-GT, 실제물질정답아님. 첨부45도 층분리는 해결됐다고 볼 수 없다.


### 06:07~ 초기 마스크 평활화 비교 (사용자 직접 요청)

- `initial_smoothing_sigma=0/1` 비교 옵션을 반복 코어에 추가(기본off). Gaussian mask threshold .5, 초기1.5px 띠/최초 전체탐색띠/valid의 교집합 안에서만 수정. 연결성분·구멍 개수 변경 시 초기평활화 취소. 최초 탐색띠를 평활화 후 mask로 재설정하지 않는다.
- `tools/audit_initial_smoothing.py`: 노이즈가 있는 축소타원/사각형/실제 굴곡을 가진 합성띠/얇은 굴곡띠4개 + 실제19/첨부 저장SAM2개, 각off/on=12조건. 노이즈 합성4개는 작은 성분·구멍으로 topology가 바뀌어 초기평활화 모두취소. 첨부도취소, 실패를 숨기기 위해 안전장치 제거하지 않음.
- 실제19는 초기3px만 변경 허용. 기존SAM과의 ASSD 2.170→2.181px로 소폭 증가(전문가GT가 아니므로 실제 정확도 악화라고 단정불가). 첨부영상은 양쪽모드 최종변경0. 초기평활화가 잘못 분할된 물질을 바로잡지 못함.
- 별도 `--clean-synthetic` 8조건: 시험입력 생성 때만 가장큰성분/구멍채움으로 단일 topology를 구성, 알고리즘의 안전검사는 그대로 유지. 이 입력 전처리는 사용자실제 mask에 적용하지 않았다. `real_waviness`라는 case명도 **합성 파형 GT**이며 실제TEM 아님.
- 평활화off→sigma1 최종 ASSD: 타원2.435→1.007px, 굴곡띠2.437→0.449px, 얇은굴곡띠0.494→0.383px. 사각형2.271→2.271px(평활화 취소). 고정column 세로 점유길이 MAE: 타원5.73→1.36px,굴곡띠5.36→0.45px,얇은띠0.73→0.55px. 이는 법선두께/nm오차가 아니다.
- 비교 PNG 직접 확인, 입력빨강/GT초록/결과청록. 총20조건 고정band밖변경0, topology보존. `initial-smoothing-v1`/`initial-smoothing-clean` JSON·mask·comparison.png 저장. 초기 평활화 도움이 될 수 있으나 기본강제 근거는 부족. UI아직 미연결.
- 추가 회귀2건 포함 반복전용6테스트 통과. 전체 Python **271/271 통과**, failures/errors/skipped0, `test-output/final-candidate-presmoothing-tests/all-tests.json`. 신규패키지/다운로드/원본변경 없음.


### 05:45~05:50 KST — 반복 법선 + 최초 고정 탐색띠 코어 구현

- `boundary_iterative.py` 추가, `refine_all` settings.iterations>1에서 호출. 현재 mask로 법선을 매회 재계산, 최초 mask EDT-0.5 고정 픽셀띠 밖 후보 제외, DP 목표 방향으로 최대step_px(기본1px)만 이동. 유효 corridor/기존 자기교차·위상 검사 유지. 무변화/반복mask/횟수 제한 종료. 부분pin/override는 현재 명시 거부.
- 중요한 계약: 최초 점마다 고정 법선 선분을 유지하는 방식이 아닌 **최초 mask 기준 공간 픽셀 탐색띠**다. 픽셀 격자 양자화/여러loop 연속궤적/부분설정 대응은 한계. 반환 loops는 최종 단계 값이지 누적이 아니다. UI에 아직 연결하지 않았고 기존 단회 기본값을 바꾸지 않음. 자세한 내용 `docs/ITERATIVE_NORMAL_KO.md`.
- `test_boundary_iterative.py` 4개 통과: 단계1px 제한/고정band/위상, 제외 영역 보존, 평탄영상 정확noop, 불법파라미터·pin거부. 전체 Python **269/269 통과**, `final-candidate-iterative-v1-tests/all-tests.json`.
- 합성16 동일 seed/입력, `--iterations 20 --corner-mode guarded`: 입력대비16개 모두ASSD개선, 평균 **8.1734→0.3475px**. 이전 단회freeze 2.2993, 단회guarded 1.0995px와 비교. 반복과corner모드 효과를 분리해 해석할 것.
- 침식15px 사각형 IoU .569→.985, 오목L형 .426→.976. 흐린타원 .580→.964. 비교 PNG 직접 확인: 모서리 일부 둥글어짐과 흐린경계 떨림은 남음. 합성 성공이 실제TEM 성공을 뜻하지 않는다.
- 재현 `tools/audit_shrunken_boundary.py --name iterative-v1 --iterations 20 --corner-mode guarded`. 결과 `test-output/final-candidate-20261002/iterative-v1`. 최초 실행 JSON에는 단계history가 없고 최종지표만 있음. 이후 실행부터 iteration_report를 저장하도록 도구 보완했으며 이전 결과를 덮어쓰지 않았다.
- 다음 최우선: band밖 강한edge 회귀 확대, 실제22조건 반복 비교 및 단계history, UI 최초/최종 경계 구분·반복정보 연결, 별도프로젝트 preview/apply/Undo 실제GUI. 아직 제품기능 전체 완료로 보고하지 말 것.


### 05:25~05:29 KST — 첨부45도 실제 SAM 재실행 9조건

- 사용자에게 원본을 제공했고 사용자 crop은 아직 받지 않았다. 기존 600×596 원본으로 `tools/audit_attached_roi_retry.py` 추가 실행. 기존 vit_b 체크포인트/CPU4 threads, 신규 설치·다운로드 없음. 원본/프로젝트 불변.
- 눈으로 지정한 좁은 층 근처 양성3/음성6점(전문가 GT 아님), 동일 점에서 전체영상/축정렬 ROI/기존 양성점 사전정렬+16px margin ROI × SAM 후보0/1/2. 점/ROI/점위반/예측score/면적/연결성분/시간을 JSON, mask 및 overlay9장, comparison.png에 저장.
- 전체영상 최고score .939인데 음성6점 모두 위반, 면적251039px. 축정렬ROI 최고score .968인데 역시 음성6점 위반, 면적44447px. 모델 예측score를 층 분리 정확도로 간주하면 안 됨.
- 사전정렬ROI는 3후보 모두 입력점 위반0, 면적11368~13021px, 연결성분8~31. 비교 이미지 직접 확인: 대각선 좁은 띠로 누출이 줄었지만 직선적인 잘린 끝과 작은 구멍/성분이 남는다. 좁은 box와 사전정렬의 강한 제약 효과이며, 실제 물질 경계 복구/전체층 완성/GT 정확도 성공을 증명하지 않는다. 노란 안내선·화살표 영향도 남는다.
- 첫 embedding 포함 각 방식 약14.8~15.6초, 같은 영상의 추가 후보 약0.13~0.22초(전체 모델 load 시간 제외). 근본 SAM 개선이나 자동 material class 분류를 구현한 것은 아니다. 기존 사전정렬 기능을 실제 실행해 비교한 것이다. 사용자 crop 수신 후 같은 프로토콜로 재검토 가능.
- 결과 `test-output/final-candidate-20261002/attached-roi-retry/`. 재현: 기존 venv Python `tools/audit_attached_roi_retry.py` (기존 결과 보호를 위해 동일 출력 경로 재실행 거부).
- 05:05 GUI는 별도 gui-19-metrology 복사본의 회전탭 열기까지 수행 후 사용자 상태 질문에 대응하며 종료. 기존 저장결과의 만료 표시만 확인했고 새 계측/내보내기 검증은 완료하지 않았다. 서버44992 및 임시탭34 종료. 이 단계는 완료 목록에 넣지 않는다.


### 04:45~04:48 KST — 회전 실패 검수 사유 가시화

- 직전 실제19 회전 실험의 fit 수치를 재확인. +45도 입력의 잘못된 top 경계는 잔차24.27px/방향성5.75, -45도는25.38px/5.73. 기존 서비스의 검수 기준(잔차>3px 또는 방향성<10)이 이미 이 실패를 표시한다. 이전 보고의 27.34도 오차를 '검수 경고 없이 자동 확정됨'으로 해석하면 안 된다. 확정은 별도 사용자 동작이다.
- 다만 `needs_review`에만 품질 사유를 반영하고 warnings에는 구체 설명을 넣지 않아, 일괄 결과/방식 비교/시각화 설명에서 왜 검수해야 하는지 약했다. `services/measurement.py`에 실제 잔차·허용값/방향성과 '동일 물리적 경계 ROI를 좁히거나 직접 기준점 지정' 경고를 추가했다. 기존 판정 기준/회전각/확정 절차를 변경하지 않았다.
- `tests/test_rotation_comparison.py`에 나쁜 fit의 API 응답이 수치·대처방법·needs_review·미확정을 보존하는 회귀시험 추가. 이 테스트의 fit은 명시 mock이며 실제19 API 정확도 시험으로 집계하지 않는다.
- 전체 Python **265/265 통과**, failures/errors/skipped 모두0. 증거 `test-output/final-candidate-rotation-warning-tests/all-tests.json`/log. `tools/check_gap_bridge.py --all --output final-candidate-rotation-warning-tests` 재현(재실행은 새 이름 권장). 설치 로그 문구는 mock 설치 테스트 출력이며 실제 다운로드 없음.
- JS `tests/ui_rotation_compare.cjs` 통과. 기존 UI들이 warnings를 표시하는 연결을 소스로 확인했으나 이번 회차 실제 브라우저 수동 검증은 하지 않았다. 다음 회차 실제19 회전/계측 GUI와 결과 저장을 우선한다. 경고를 개선했을 뿐, 자동 기준 경계 추적 문제 자체를 해결했다고 주장하지 않는다.


### 04:25~ 19.jpg 실제 SAM 후보 회전·계측 일관성

- 추가 재현 도구: `tools/audit_19_rotation_measurement.py`. 기존 venv Python으로 실행. 결과 `test-output/final-candidate-20261002/19-rotation-measurement/results.json`, 14개 회전 후 계측선 PNG.
- 원본 `crop19-v220/project`의 `19_crop_1cell_+00deg.png`, 후보 1을 읽기 전용 사용. 추가 회전 0, ±7, ±20, ±45도 × 기준점 유지/상부 경계 재추출 2방법. GT 확정 없이 mask 기반 회전·계측 함수를 실행했다. 실제 웹/API 버튼 테스트는 이번 실험에 포함하지 않았다.
- 같은 물리적 기준점을 알려진 회전행렬로 운반한 경우: 최대 각도 일관성 오차 5.68e-14도, 중앙 11개 수직 측정선 평균의 최대 차이 0.4264 px. 기준 평균 129.3781 px. 각도의 거의 0 오차는 동일점의 수학적 회전 성질이며 자동 기준 검출 성공률이 아니다.
- 매 영상에서 단순 `top` + 영상 중앙 20~80% ROI로 다시 경계를 추출하면: 최대 각도 오차 **27.3352도**, 평균 길이 차이 **24.8167 px**. +45도 결과를 시각 확인했으며 실제로 수평이 맞지 않았다. 큰 회전에서 영상 좌표상의 위쪽 외곽이 동일 물리적 경계가 아니고 측면까지 포함되는 실패다.
- 따라서 '같은 top 설정이면 여러 이미지에서 항상 동일 경계'라고 보장할 수 없다. 레시피의 기준 경계 구간도 영상/객체 정합으로 운반하거나, 사용자가 기준 구간을 확인해야 한다. 자동 기준 선택 개선과 UI 검증을 후속 과제로 유지한다. 이번에는 근거 없이 회전 알고리즘 기본값을 바꾸지 않았다.
- 길이는 `nm_per_px=1`로 계산한 숫자를 **px 일관성**으로만 보고했다. 실제 스케일 검증/전문가 TEM GT/진짜 두께 정확도 평가가 아니다. 알려진 affine 운반은 평가용 oracle이며 자동 정합 기능 구현이 아니다. 원본·기존 ZIP 변경 없음.


### 04:05~ KST — 오래된 프로파일/부분구간 초기화 + 실제 GUI 검증

- `web/v2.js`에 clearBoundaryReview 통합. 취소/적용/Undo/Redo/후보변경/이미지변경/refresh 시 revision변경에서 이전 draft, profileSelection, localEndpoint, 그래프/문구를 초기화. 미리보기 재실행만 명시 pins/overrides 유지. 작은 contour의 offset_grid=[0] 그래프에서 hi==lo 0나누기도 방어.
- index.html v2.js 캐시 키 boundary-3. `ui_regression.cjs`에서 취소 후 원본캔버스 픽셀 지움, profile/구간/pins 초기화, 재실행 제약 보존 검증. **JS8 suite 통과**. Python 변경 없음(직전264 통과와 구분).
- computer-use 지침에 따라 별도 `gui-profile-reset` 프로젝트를 실제 서버8899로 실행. 첨부영상 후보#2 미리보기 완료 → 실제 영상 경계 클릭 → 경계3/점86 프로파일 → 부분구간 시작점 + 고정점1개 → 취소 → 고정점 버튼 재클릭. 그래프/프로파일 문구 빈칸, 고정점0/부분설정0, '프로파일 지점을 먼저 선택하세요' 안내 확인.
- 증거 `gui-profile-reset/before-cancel.png`, `after-cancel.png`. 이 실험의 경계 제안은 변경0/위상 취소였으므로 정확도 성공으로 집계하지 않음. 검증 서버 PID43844/임시탭 종료. 사용자 원본 프로젝트 불변.
- 다음 우선순위: 실제19 GUI top3 및 회전·계측/결과 저장, API에서 미확정/오래된 상태 적용 거부 추가점검. 반복 법선 고정 초기 탐색띠 미완료. 8시 종료 패키징 준비.

### 03:45~ KST — 자기접촉/공선중첩 검사 보강

- `boundary.crossing()`의 기존 엄격한 X교차 검사는 비인접 꼭짓점이 선분에 닿는 T접촉/공선중첩을 놓쳤다. 비인접 선분의 접촉 및 중첩까지 차단, 연속 중복점/퇴화 선분도 거부. 정상 닫힘의 처음=끝 중복점은 정규화. bounding-box로 불가능한 선분 쌍은 먼저 제외한다.
- 추가 `tests/test_boundary_intersections.py` 5개: 정상/명시적 닫힘, X교차, T접촉, 공선중첩, 퇴화. 관련 boundary16 tests 통과.
- 합성16 `strict-intersections`은 이전 기본값 결과와 동일(평균 ASSD2.2993px, 개선14/유지2). 실제22 `real-strict-intersections` 오류0/개선11/유지11. 안전 검사 강화로 기존 성과를 부풀리지 않음.
- 미완료 안전 범위: 서로 다른 loop 간 연속 좌표 교차/전체 이동 궤적의 교차는 이 함수 하나로 보장하지 않음. 최종 mask 연결 구조 검사는 별도 유지.
- 코드 감사 추가 발견: `web/v2.js` 미리보기 취소/후보 변경 때 `profileSelection`, `localEndpoint`, profile 그림/문구를 일관되게 지우지 않는 경로가 있다. 다음 회차 stale 프로파일/부분구간 시작점 재사용과 실제 GUI 검증 우선. API apply는 revision mismatch를 이미 차단한다.
- 이번 회차 GUI 미실행. 운영 안전 로직 변경은 boundary.py 한 파일이며 UI 코드는 변경하지 않음.
- 전체 Python **264건 통과**, `test-output/final-candidate-intersections-tests/all-tests.json`/log. 재현: 기존 venv Python `tools/check_gap_bridge.py --all --output final-candidate-intersections-tests` (새 재실행은 별도 output 이름 권장).

### 03:25~ KST — 실제 19 증강 top3/API 및 형태 stress 확대

- `tools/audit_real_mask_matching.py`: 원본 증강 프로젝트를 `real-matching/project`에 복사. 기준은 이전 19 SAM mask이며 검수 플래그는 시험 구성용(전문가 검수 아님). 대상 7영상의 저장된 SAM 결과에 합성 원/세로띠/정사각형 오답 후보 각3개를 추가. 검색→top3→1개 배정→픽셀동일→저장 재로드→오래된 결과 재적용 거부→Undo→Redo를 실제 FastAPI TestClient로 검증. **7/7 계약 검증 통과**, GUI를 대신했다고 주장하지 않음.
- top1은 7개 모두 기존 실제 SAM 후보. 형태 score: baseline .9975, 밝기/노이즈 약.98, 이동.97, 확대.98, 비등방 늘림.72, 12도회전.8766. 위치이동/회전에서 선택된 후보는 이전 known_affine 프롬프트로 생성된 결과가 포함된다. 이번 시험은 자동 영상정합 성공을 증명하지 않음.
- `real-matching/results.json`, 영상별 top1 overlay 저장. 검색이 물질 의미를 이해하는 것이 아니라 mask 형상을 비교한다는 한계 유지. 같은 물질 여부의 전문가 GT 없음.
- `tools/audit_boundary_stress.py`: nominal thin6/thin12(정수 격자 실제 내부 두께5/11px),45도 사각형,3재료 junction의 한 재료 mask × 원래/침식2/침식4/팽창4 × freeze/guarded =32조건. 얇은5px층 침식4는 빈mask여서 2조건은 `empty_after_erosion`으로 기록, 성공으로 세지 않음. 나머지30 실행 오류0.
- 각 모드 실행15건 중 ASSD 개선11/정확한 원래 입력 유지4/입력 대비 악화0. 다만 모드 간 비교는 균일하지 않음: 45도 사각형 팽창4 IoU freeze .980 vs guarded .907. **guarded 기본 적용은 계속 보류**.
- 증거 `stress-v1/results.json`, `comparison.png` 직접 시각 검토. 초기 GT는 도형 정의로 생성하고 평가/입력 왜곡에만 사용. junction은 한 재료의 독립mask 보정 시험이며,3개 클래스 공유경계의 동시 무틈 보장을 시험한 것이 아니다.
- 이번 회차 변경은 검증 도구2개/이 문서뿐. 운영 로직 변경 없음. 259 Python/8 JS 직전 회귀 통과 상태와 구분.
- 다음 우선순위: 실제 GUI top3/회전계측, 오래된 프로파일과 적용 상태 검증; 단회법선의 endpoint safety/교차 검증 감사. 8시까지 검증본 ZIP/문서 묶음 준비. 반복 법선 고정 탐색띠는 여전히 미완료.

### 03:05~ KST — 모서리 이동 + 교차 시 부분 이동 실험 (기본값 미채택)

- `corner_mode='guarded'`를 명시해야 하는 실험 옵션 추가. 기본값은 기존 `freeze` 유지, UI에는 아직 노출하지 않는다.
- 모서리를 법선 Gradient/DP 후보에 포함하지만 coarse/detailed 교차 검사를 유지한다. 교차가 생기면 제안 이동의 1/2,1/4,1/8,0을 검사해 줄인다. 부분 이동은 전체 uncertain과 목표 도달 미확정 경고. pins가 있으면 이 축소는 하지 않음. topology 검사 유지.
- 실험 옵션에서는 최초 법선 위 유효 탐색 샘플이 연속인 영역만 허용하여 제외 띠를 건너뛴 후보를 막는다. **단회 알고리즘이며 반복 법선 재계산/최초 고정 탐색띠의 구현 완료가 아님**. 연속적인 전체 이동 궤적의 무교차 증명도 아님.
- 합성16 `guarded-corners`: 평균 ASSD2.299→1.099px, 16/16 개선. 축소15 사각형 IoU .569→.986(기존 .860), 축소15 L형 .426→.688(기존 무이동). 팽창 사각형 .790→.886으로 부분 개선. 비교 이미지 직접 확인. 중심 chord32개 평균오차4.406→1.875px(국소 두께 계측 아님).
- 실제22 `real-guarded-corridor`: 첨부 #1 팽창8 ASSD6.362→6.423, 공개 #8 팽창8 8.539→9.307로 악화. **합성 개선만으로 기본값 채택하지 않음**. 기존 전문가 GT가 아닌 SAM과의 일관성 기준.
- 테스트 추가 `test_boundary_guarded.py`: 기본값 동일, 이동범위/위상/교차, 제외 띠, 잘못된 옵션 거부. 전체 회귀 결과는 아래 후속 기록.
- 회귀 **259건 통과**, `test-output/final-candidate-guarded-tests/all-tests.json`. 실제22건 최종: 오류0/개선15/무변경5/악화2. 이번 회차 실제 GUI 미실행, 기존 GUI 기본 동작은 freeze 유지. 다음 패키징에서 실험 옵션이라는 구분을 반드시 유지할 것.
- 조사: [scikit-image active_contour 공식 API](https://scikit-image.org/docs/stable/api/skimage.segmentation#skimage.segmentation.active_contour), [공식 예제](https://scikit-image.org/docs/stable/auto_examples/edges/plot_active_contours.html). 길이/매끄러움과 영상 edge 에너지를 함께 쓰며 max_px_move는 반복당 이동 제한이다. 최초 경계 기준 누적 제한/위상 보존을 보장하는 인자로 오인하면 안 됨. 새 패키지를 설치하거나 가져온 코드를 복사하지 않았다.
- 다음 실행에서는 확대/축소에 더해 얇은 층·회전·접합점/흐린 경계 평가 범위를 늘리고, 실제 top3 매칭과 회전계측/API/GUI를 우선 진행. guarded 모드의 자동 기본 적용은 보류.

### 02:45~02:51 KST — 픽셀 중심 raster / 부분 취소 보존

- 원인: PIL polygon 정수 채움 규약 + 2px 재표본 contour를 그대로 raster하여 원본 경계를 재구성하면, 원래 없던 픽셀 변화/작은 구멍 변화가 생김.
- 변경 `boundary.py`: 정수 픽셀 중심에서 polygon 내부 여부를 평가(matplotlib Path, 64행 단위)한다. 출력에는 resample된 경계 자체 대신 **원래 상세 contour에 보간된 이동 벡터**를 적용. 이동0인 loop는 원래 상세 contour 그대로 유지. 제외 픽셀 원본 보존. 상세 contour 교차도 추가 검사, topology 검사는 유지.
- 40×50 랜덤 mask 3밀도(.1/.5/.9)에서 contour→raster의 모든 픽셀이 정확히 일치. 두 객체 중 한 객체 보정만 취소해도 해당 객체 원본 픽셀 보존/다른 객체 실제 이동 테스트 통과.
- Python **255건 통과**, `test-output/final-candidate-pixel-center-tests/all-tests.json`. 이번 회차 UI는 재실행하지 않음(직전 경고 UI 검증은 별도 기록).
- 합성16건 `pixel-center/results.json`, 비교 그림 직접 확인. 평균 ASSD 2.510→2.299 px (같은 입력 초기8.173). 개선14/무변경2. 선명 타원 -15px IoU .580→.994. 흐린 타원은 일부 소폭 변동이 있으며 모서리 사각형/L형 실패는 여전히 남아 있음.
- 실제22건 `real-pixel-center/results.json`: 오류0/기준 SAM 대비 경계거리 개선11/무변경11/악화0. 직전 악화된 공개 #8 팽창8은 IoU .61009→.61104, ASSD8.539→8.500으로 소폭 개선일 뿐 실질 해결로 과장하지 않음. 취소 건수가 여전히 많음.
- 새 `tools/audit_synthetic_chords.py`: 기존 합성 결과의 영상 중심 수평/수직 단일 연결 구간 길이32개 평가. 초기 평균절대오차21.156px, 이전보정4.688→현재4.406px. `preserve-noop/chord-errors.json`, `pixel-center/chord-errors.json`. **국소 법선 두께/실제 nm/app 계측 파이프라인 검증이 아닌, 합성 축 방향 chord 진단**.
- 다음 우선순위: 모서리 freeze와 교차 취소를 줄이는 안전한 독립 실험(고정 초기 탐색띠/반복법선 미완료), 실제 top3 매칭 및 회전·계측 GUI. 상세 contour가 매우 길 때의 교차 검사 비용도 확인할 것.

### 02:25~ KST — 작은 contour 예외 처리 및 실제 GUI

- `boundary.py`: 둘레 4px 미만의 contour는 법선 추정 대신 원본 보존/보정 제외로 기록. UI loop index 유지, 주변 원본 픽셀 보존, 기존 연결 구조 검사 유지. 작은 물질/구멍을 임의 삭제하지 않음.
- 고립 1px와 1px 구멍이 있는 마스크에서 해당 픽셀 보존과 큰 경계의 실제 이동을 함께 확인하는 2개 테스트 추가. Python **253건 통과**, JS **8개 suite 통과**.
- 실제 저장 영상 같은 22건 재검증 `real-small-contour/results.json`: 예외 5→0, 기준 SAM 대비 ASSD 개선 10, 무변경 11, 악화 1. 공개 candidate 8 팽창8에서 IoU .6101→.5999, ASSD 8.539→8.774 px. 오류 해결이지 정확도 전면 해결이 아님.
- `gui-small-contour`에 첨부 영상 프로젝트를 복사, 포트8899로 실제 실행. 원본 프로젝트 불변. 명시적 배경 없는 경계 미리보기는 요구 조건 오류를 올바르게 표시. 검증용 배경 브러시 한 점을 만든 뒤 미리보기 완료, 작은 contour 경고 확인. 변경0, 연결구조 취소이므로 보정 성공이라고 하지 않음.
- 실제 GUI에서 같은 경고가 수백 번 반복되어 패널을 채우는 문제 발견. `web/v2.js`에 유형별 해당 경계 수 요약 + 전체 경계 수 + 아직 적용 안 됨 표시 추가. `ui_regression.cjs`에 중복/빈 목록 테스트. `index.html` v2.js 캐시 버전 변경.
- GUI 재검증: 308개 경계/작은 경계45개/교차21개 등 유형별 요약이 실제 표시됨. 증거 `gui-small-contour/summary-preview.png`. 검증 후 테스트 서버 PID28996과 임시 탭 종료. 계산 완료는 보정 성공과 다름(변경0).
- 다음: 부분 취소/미이동 loop 보존, topology 원본 raster 불일치 분석, 모서리 안전 이동 독립 실험. 실제 UI 적용/Undo와 top3 실영상 검증 및 두께오차는 아직 필요.

### 02:05~02:15 KST — 취소 시 픽셀 보존 및 실제 자료 첫 시험

- 발견: 교차로 보정 취소해도 resample/polygon rasterization으로 원본 픽셀이 변했다. 전체 loop 이동량이 0이면 mask.copy()를 반환하도록 수정. 일부 loop만 취소되는 경우의 정확한 픽셀 보존은 아직 미해결.
- 첫 실험안(원본에 raster delta 적용)은 위상 검사를 모두 실패시켰다. **채택하지 않음**. 실패 증거 `preserve-cancel/results.json` 보존. 현재 코드는 전체 no-op 보존만 적용한다.
- 합성 재검증 `preserve-noop/results.json`: 기존 개선 14건 유지, 교차 취소 2건은 원본 그대로. 팽창 사각형 IoU .790→.790, 작은 L형 .426→.426. 평균 ASSD 8.173→2.510 px. 취소를 성공으로 집계하지 않음.
- 추가 회귀 `tests/test_boundary_preservation.py`: 평탄 영상, 강제 교차취소, 제외영역이 있는 무이동 결과의 원본 보존 3건.
- 전체 Python **251건 통과**, `test-output/final-candidate-noop-tests/all-tests.log` 및 JSON. 이번 회차 GUI/JS는 실행하지 않음.
- 실제 자료 목록: crop19 5 images/11 candidates, attached 1/2, augment 8/13, public audit 14/191. 원본 프로젝트는 읽기만 수행.
- 신규 `tools/audit_real_boundary_bias.py --name real-noop`: 각 프로젝트 처음 최대 3개 후보에 ±8 px 왜곡, 실제 원본 영상에서 보정. 기존 SAM은 전문가 GT가 아닌 일관성 비교 기준이다. GT를 알고리즘에 전달하지 않음. 결과/overlay는 `test-output/final-candidate-20261002/real-noop`.
- 발견: 첨부 candidate 2와 공개 candidate 8에서 `계면 구간이 너무 짧습니다. 최소 4 px 이상 선택하세요.` 예외. 작은 연결 성분/구멍 contour가 전체 refine를 중단시키는 경로 점검 필요.
- 19 축소 후보 1/2 및 증강 일부에서 자기교차 취소. 안전 검사 제거로 통과시키지 말 것.
- 다음 우선순위: 짧은 contour의 보존/명시 경고 처리 + 부분 취소 픽셀 보존 설계, 모서리/교차 개선의 독립 실험. 이후 실제 GUI/API/top3와 두께오차 평가. 반복 법선/최초 고정 탐색띠는 아직 구현 안 됨.

1. baseline 실패 rows의 flags/uncertain과 boundary.py corner/frozen/DP 제약을 분석. 모서리 강제고정 해제만으로 끝내지 말고 안전 검사와 함께 비교할 것.
2. 테스트는 같은 baseline을 덮어쓰지 말고 새 --name으로 수행. 고정한 시드/정답으로 전후 비교.
3. `test-output/public-review`, `augment-audit-20261001`, `attached-review-v220`, `crop19-v220`의 기존 자료와 project.json을 조사해 실제 영상 시험 목록 생성. 기준 SAM 결과는 pseudo-GT로 표시.
4. 새로운 반복 법선 알고리즘을 추가할 경우 최초 탐색띠 밖 Gradient를 후보에 넣지 않는 회귀 테스트 필수. 기존 경계가 맞는 경우/작은 경우/큰 경우를 모두 검증.
5. 8시 전에 검증된 개선만 패키징. 회사 정확도 미검증, 미완료 기능은 명시.
