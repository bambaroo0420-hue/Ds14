"""All persistent coordinates refer to the original image; annotation boxes are normalized."""
import io, re, csv, shutil, subprocess, tempfile
from pathlib import Path
import numpy as np
from scipy import ndimage as ndi
from PIL import Image
from .core import gray, denoise, warp_mask, transform_points

DEFAULT_FILTER={'enabled':False,'method':'gaussian','sigma':1.2,'sigma_space':2.,'sigma_color':.08}
DEFAULT_LAYOUT={'analysis':None,'scale':None,'sample':None,'magnification':None,'exclude':[]}

def rect_pixels(rect,shape):
 h,w=shape[:2];a=np.asarray(rect,float)
 if a.shape!=(4,) or not np.isfinite(a).all() or not (0<=a[0]<a[2]<=1 and 0<=a[1]<a[3]<=1):raise ValueError('영역은 이미지 안의 사각형이어야 합니다.')
 return [int(np.floor(a[0]*w)),int(np.floor(a[1]*h)),min(w,int(np.ceil(a[2]*w))),min(h,int(np.ceil(a[3]*h)))]

def valid_region(shape,layout):
 h,w=shape[:2];valid=np.ones((h,w),bool)
 if layout.get('analysis'):
  x0,y0,x1,y1=rect_pixels(layout['analysis'],shape);valid[:]=False;valid[y0:y1,x0:x1]=True
 for rect in [layout.get(k) for k in ('scale','sample','magnification')]+layout.get('exclude',[]):
  if rect:
   x0,y0,x1,y1=rect_pixels(rect,shape);valid[y0:y1,x0:x1]=False
 if valid.sum()<100:raise ValueError('분석 가능한 영역이 너무 작습니다.')
 return valid

def sanitized(rgb,valid):
 if valid.all():return rgb.copy()
 # Nearest valid-pixel fill is only for model input; invalid pixels NEVER become masks or match samples.
 inds=ndi.distance_transform_edt(~valid,return_distances=False,return_indices=True)
 out=rgb.copy();out[~valid]=rgb[inds[0][~valid],inds[1][~valid]]
 return out

def filter_image(rgb,cfg):
 cfg=cfg or {}
 if not cfg.get('enabled',False):return rgb.copy()
 f=denoise(rgb,cfg.get('method','gaussian'),float(cfg.get('sigma',1.2)),float(cfg.get('sigma_space',2)),float(cfg.get('sigma_color',.08)))
 return np.repeat(np.clip(f*255,0,255).astype(np.uint8)[...,None],3,axis=2)

def invert_affine(M):
 M=np.asarray(M,float);R=np.linalg.inv(M[:,:2]);return np.c_[R,-R@M[:,2]]

def rotation_map(shape,angle):
 h,w=shape[:2];theta=np.deg2rad(-float(angle));R=np.array([[np.cos(theta),-np.sin(theta)],[np.sin(theta),np.cos(theta)]])
 corners=np.array([[0,0],[w-1,0],[0,h-1],[w-1,h-1]])@R.T
 lo=corners.min(axis=0);hi=corners.max(axis=0);M=np.c_[R,-lo]
 return M,(int(np.ceil(hi[1]-lo[1]))+1,int(np.ceil(hi[0]-lo[0]))+1)

def warp_rgb(rgb,M,shape):
 inv=invert_affine(M);swap=np.array([[0,1],[1,0]])
 return np.stack([ndi.affine_transform(rgb[...,k],swap@inv[:,:2]@swap,offset=swap@inv[:,2],output_shape=shape,order=1,mode='constant',cval=127) for k in range(3)],axis=-1).astype(np.uint8)

def prepare(s,local_box=None):
 valid=valid_region(s['rgb'].shape,s['layout']);rgb=sanitized(s['rgb'],valid)
 # SAM denoising is performed once from the original, independent from edge filtering.
 rgb=filter_image(rgb,s['sam_filter']);ys,xs=np.nonzero(valid);box=[xs.min(),ys.min(),xs.max()+1,ys.max()+1]
 if local_box is not None:
  a=np.asarray(local_box,float)
  box=[max(box[0],int(np.floor(a[0]))),max(box[1],int(np.floor(a[1]))),min(box[2],int(np.ceil(a[2]))+1),min(box[3],int(np.ceil(a[3]))+1)]
 x0,y0,x1,y1=map(int,box)
 if x1-x0<8 or y1-y0<8:raise ValueError('분할 ROI가 너무 작거나 분석 영역 밖입니다.')
 crop=rgb[y0:y1,x0:x1];vc=valid[y0:y1,x0:x1];T=np.array([[1.,0.,-x0],[0.,1.,-y0]])
 angle=s['alignment']['angle'] if s['alignment']['enabled'] else 0.
 if abs(angle)>.001:
  R,shape=rotation_map(crop.shape,angle);crop=warp_rgb(crop,R,shape);vc=warp_mask(vc,R,shape);T=np.c_[R[:,:2]@T[:,:2],R[:,:2]@T[:,2]+R[:,2]]
 return crop,vc,T,valid

def gradient_angle(rgb,valid):
 a=ndi.gaussian_filter(gray(sanitized(rgb,valid)),2);gy,gx=np.gradient(a);v=ndi.binary_erosion(valid,iterations=4)
 if v.sum()<50:raise ValueError('방향 추정 영역 부족')
 G=np.array([[np.mean(gx[v]**2),np.mean(gx[v]*gy[v])],[np.mean(gx[v]*gy[v]),np.mean(gy[v]**2)]])
 eig,V=np.linalg.eigh(G);normal=V[:,-1];t=np.array([-normal[1],normal[0]]);angle=float(np.rad2deg(np.arctan2(t[1],t[0])));angle=(angle+90)%180-90
 coherence=float((eig[1]-eig[0])/max(eig.sum(),1e-12));return {'angle':angle,'coherence':coherence,'warning':'여러 방향·측벽·결정 질감의 영향을 받는 제안 각도입니다. 표시를 확인한 뒤 적용하세요.'}

def read_text(rgb,executable='tesseract'):
 exe=shutil.which(executable) if not Path(executable).is_file() else executable
 if not exe:raise RuntimeError('Tesseract 실행 파일이 없습니다. OCR 없이 영역 제외와 수동 입력은 가능합니다.')
 with tempfile.TemporaryDirectory(prefix='tem_ocr_') as d:
  p=Path(d)/'roi.png';im=Image.fromarray(rgb);im=im.resize((im.width*3,im.height*3),Image.Resampling.BICUBIC);im.save(p)
  r=subprocess.run([exe,str(p),'stdout','--psm','6','-l','eng','tsv'],capture_output=True,text=True,timeout=25,check=False)
  if r.returncode:raise RuntimeError(r.stderr.strip()[-500:] or 'OCR 실행 실패')
  rows=list(csv.DictReader(io.StringIO(r.stdout),delimiter='\t'));words=[];conf=[]
  for row in rows:
   text=(row.get('text') or '').strip()
   if text:
    words.append(text)
    try:conf.append(float(row['conf']))
    except (KeyError,ValueError):pass
  return {'text':' '.join(words),'confidence':float(np.mean(conf)) if conf else 0.}

def bar_candidates(rgb,origin=(0,0)):
 a=gray(rgb);out=[];h,w=a.shape
 for bright in (False,True):
  binary=a>.78 if bright else a<.22
  labels,n=ndi.label(binary)
  for label,sl in enumerate(ndi.find_objects(labels),1):
   if sl is None:continue
   hh=sl[0].stop-sl[0].start;ww=sl[1].stop-sl[1].start
   if ww<max(18,w*.12) or ww/max(hh,1)<7 or hh>max(15,h*.2):continue
   reg=labels[sl]==label
   if reg.mean()<.65:continue
   y=origin[1]+(sl[0].start+sl[0].stop-1)/2
   x0=origin[0]+sl[1].start;x1=origin[0]+sl[1].stop # pixel support width
   out.append({'points':[[float(x0),float(y)],[float(x1),float(y)]],'width_px':float(ww),'bright':bright})
 return sorted(out,key=lambda z:z['width_px'],reverse=True)[:5]

def annotations(s,executable='tesseract'):
 result={'values':{},'warnings':[],'confirmed':False}
 for kind in ('scale','sample','magnification'):
  rect=s['layout'].get(kind)
  if not rect:continue
  x0,y0,x1,y1=rect_pixels(rect,s['rgb'].shape);crop=s['rgb'][y0:y1,x0:x1]
  try:result['values'][kind]=read_text(crop,executable)
  except Exception as e:result['warnings'].append(kind+': '+str(e));result['values'][kind]={'text':'','confidence':0.}
  if kind=='scale':
   bars=bar_candidates(crop,(x0,y0));result['bars']=bars
   txt=result['values'][kind]['text'];m=re.search(r'(\d+(?:[.,]\d+)?)\s*(nm|[uμµ]m)',txt,re.I)
   if m:
    length=float(m.group(1).replace(',','.'))*(1000 if m.group(2).lower()!='nm' else 1)
    result['length_nm']=length
    if length>0 and len(bars)==1:result['suggested_nm_per_px']=length/bars[0]['width_px']
   if len(bars)!=1:result['warnings'].append('스케일바 후보가 하나로 정해지지 않았습니다. 양끝을 직접 지정하세요.')
 return result
