import base64,copy,hashlib,io,json,math,time,zipfile
from pathlib import Path
import numpy as np
from scipy import ndimage as ndi
from PIL import Image,ImageDraw
from .core import read_image,transform_points,warp_mask,mask_box,interior_point,mask_geometry,gray
from .sam_backend import SamBackend
from .synthetic import make_sample
from .imaging import DEFAULT_FILTER,DEFAULT_LAYOUT,valid_region,sanitized,prepare,invert_affine,annotations,gradient_angle,filter_image
from .boundary import DEFAULTS,refine_all

def png_bytes(a):
    b=io.BytesIO();Image.fromarray(a).save(b,format='PNG');return b.getvalue()
def role():return dict(points=[],labels=[],box=None,mask=None,candidates=[],score=None)
def compact_boundary(b):
    if b is None:return None
    return {k:v for k,v in b.items() if k not in ('mask','loops')}|{'loops':[{k:v for k,v in e.items() if k!='response'} for e in b['loops']]}

class Engine:
    def __init__(self):self.images={};self.backend=SamBackend();self.reference=None;self.events=[];self.cancel=False
    def add(self,name,rgb):
        if len(self.images)>=30:raise ValueError('최대 30장입니다.')
        i=hashlib.sha256(rgb.tobytes()+name.encode()).hexdigest()[:12]
        if i in self.images:return i
        self.images[i]=dict(id=i,name=Path(name).name,rgb=rgb,nm_per_px=None,calibration='unset',source='user_image',roles={r:role() for r in ('anchor','target')},status='이미지 로드됨',roi=None,match=None,clicks=0,sam_filter=DEFAULT_FILTER.copy(),edge_filter=DEFAULT_FILTER|{'enabled':True},edge_same=False,layout=copy.deepcopy(DEFAULT_LAYOUT),alignment=dict(enabled=False,angle=0.,source='off'),metadata=None,boundary=None,boundary_settings=DEFAULTS.copy(),overrides=[],pins=[])
        return i
    def summary(self,s):
        out={k:copy.deepcopy(v) for k,v in s.items() if k not in ('rgb','roles','boundary','_match_masks')}
        out.update(width=s['rgb'].shape[1],height=s['rgb'].shape[0],boundary=compact_boundary(s['boundary']))
        out['roles']={k:{a:b for a,b in r.items() if a not in ('mask','candidates')}|{'has_mask':r['mask'] is not None,'candidates':[{'score':x['score'],'rank':x.get('rank'),'spill':x.get('spill')} for x in r['candidates']]} for k,r in s['roles'].items()}
        return out
    def state(self):return dict(model=self.backend.info,reference=None if self.reference is None else dict(id=self.reference['id'],name=self.reference['name']),images=[self.summary(s) for s in self.images.values()])
    def dirty(self,s,invalidate=False):
        s['boundary']=None;s['status']='수정됨 · 검토 필요'
        if invalidate:
            s['match']=None;s.pop('_match_masks',None)
            for r in s['roles'].values():r['mask']=None;r['candidates']=[];r['score']=None
            s['overrides']=[];s['pins']=[]
    def predict(self,s,points,labels,box=None,local_box=None):
        rgb,v,T,original_valid=prepare(s,local_box);pts=np.array(transform_points(points,T)).reshape(-1,2)
        for p in points:
            x,y=map(int,p)
            if not(0<=x<original_valid.shape[1] and 0<=y<original_valid.shape[0]) or not original_valid[y,x]:raise ValueError('프롬프트가 제외 영역 또는 이미지 밖입니다. 점을 수정하세요.')
        if len(pts) and ((pts<0).any() or (pts[:,0]>=rgb.shape[1]).any() or (pts[:,1]>=rgb.shape[0]).any()):raise ValueError('프롬프트가 SAM 관심영역 밖입니다.')
        bb=None
        if box is not None:
            x0,y0,x1,y1=box;q=np.array(transform_points([[x0,y0],[x1,y0],[x1,y1],[x0,y1]],T));bb=[max(0,float(q[:,0].min())),max(0,float(q[:,1].min())),min(rgb.shape[1]-1,float(q[:,0].max())),min(rgb.shape[0]-1,float(q[:,1].max()))]
        key=s['id']+hashlib.sha256(json.dumps([s['layout'],s['sam_filter'],s['alignment'],local_box],sort_keys=True).encode()).hexdigest()[:16]
        result=self.backend.predict(rgb,key,pts.tolist(),labels,bb)
        out=[]
        for a in result:
            m=warp_mask(a['mask']&v,invert_affine(T),s['rgb'].shape[:2])&original_valid
            if m.any():out.append(dict(mask=m,score=float(a['score'])))
        if not out:raise ValueError('유효 영역 안에 SAM 마스크가 없습니다.')
        return out
    def refine(self,s,settings=None):
        m=s['roles']['target']['mask']
        if m is None:raise ValueError('대상층을 먼저 분할하세요.')
        cfg=DEFAULTS|dict(settings or s['boundary_settings']);f=s['sam_filter'] if s['edge_same'] else s['edge_filter']
        result=refine_all(s['rgb'],m,valid_region(m.shape,s['layout']),cfg,f,s['overrides'],s['pins'])
        s['boundary']=result;s['boundary_settings']=cfg;s['status']='전체 경계 보정됨 · 불확실 지점 검토 필요'
        return [e['quality'] for e in result['loops']]
    def action(self,op,d,progress=lambda x:None):
        if op=='load_model':return self.backend.load(d['model'],d['checkpoint'],d.get('device','auto'))
        if op=='upload':return [self.add(f['name'],read_image(base64.b64decode(f['data'],validate=True))) for f in d['files']]
        if op=='synthetic':
            out=[]
            for k in range(7):
                z=make_sample(k);i=self.add(f'SYNTHETIC_{k+1:02d}.png',z['rgb']);s=self.images[i];s.update(nm_per_px=z['nm_per_px'],calibration='synthetic known',source=z['source'],status='합성 정답 마스크 · SAM 추론 아님')
                for name in ('anchor','target'):s['roles'][name].update(mask=z[name],points=[interior_point(z[name])],labels=[1])
                out.append(i)
            return out
        if op=='restore':return self.restore(base64.b64decode(d['data'],validate=True))
        if op=='delete':
            ids=set(d['ids'])
            for i in ids:self.images.pop(i,None)
            if self.reference is not None and self.reference['id'] in ids:self.reference=None
            return {'deleted':len(ids),'note':'세션에서만 삭제; 디스크 원본 유지'}
        if op=='batch':
            if self.reference is None:raise ValueError('참조 저장 필요')
            self.cancel=False;out=[]
            for i in d['ids']:
                if self.cancel:break
                if i==self.reference['id']:continue
                s=self.images[i];progress('기준층 탐색: '+s['name'])
                try:
                    rows=self.search(s,d);margin=rows[0]['score']-rows[1]['score'] if len(rows)>1 else rows[0]['score']
                    if rows[0]['score']<float(d.get('threshold',.65)) or margin<float(d.get('margin',.05)):
                        s['roles']['target']=role();self.dirty(s);s['status']='기준층 대응 불확실 · 후보를 직접 선택하세요';out.append({'id':i,'status':s['status']});continue
                    out.append(self.apply_match(s,0,progress))
                except Exception as e:s['roles']['target']=role();self.dirty(s);s['status']='자동 적용 중단: '+str(e);out.append({'id':i,'error':str(e)})
            return out
        s=self.images[d['id']];name=d.get('role','target');r=s['roles'][name]
        if op=='reference':
            if s['roles']['target']['mask'] is None:raise ValueError('대상층 마스크를 먼저 선택하세요.')
            if s['roles']['anchor']['mask'] is None:s['roles']['anchor']=copy.deepcopy(s['roles']['target'])
            self.reference=copy.deepcopy(s);self.reference.pop('_match_masks',None)
            for rr in self.reference['roles'].values():rr['candidates']=[]
            return {'saved':s['name'],'note':'계면 지정/계측 없이 참조 저장 완료'}
        if op=='sam_filter':
            cfg=DEFAULT_FILTER|d['settings'];filter_image(s['rgb'][:16,:16],cfg);s['sam_filter']=cfg;self.dirty(s,True)
        elif op=='edge_filter':
            cfg=DEFAULT_FILTER|d['settings'];filter_image(s['rgb'][:16,:16],cfg);s['edge_filter']=cfg;s['edge_same']=bool(d.get('same',False));self.dirty(s)
        elif op=='layout':
            layout=copy.deepcopy(DEFAULT_LAYOUT)|d['layout'];valid_region(s['rgb'].shape[:2],layout)
            targets=list(self.images.values()) if d.get('all') else [s]
            for a in targets:valid_region(a['rgb'].shape[:2],layout)
            for a in targets:a['layout']=copy.deepcopy(layout);a['metadata']=None;self.dirty(a,True)
        elif op=='metadata':
            if s['metadata'] is None:s['metadata']=dict(values={},warnings=[],confirmed=False)
            for key in ('sample','magnification'):s['metadata']['values'][key]=dict(text=str(d.get(key,'')),source='manual')
        elif op=='ocr':s['metadata']=annotations(s,d.get('executable','tesseract'));return s['metadata']
        elif op=='calibrate':
            value=d.get('nm_per_px');value=None if value in ('',None) else float(value)
            if value is not None and (not math.isfinite(value) or value<=0):raise ValueError('nm/pixel은 양수여야 합니다.')
            s['nm_per_px']=value;s['calibration']='manual confirmed' if value else 'unset'
        elif op=='alignment':
            angle=float(d.get('angle',0))
            if not math.isfinite(angle) or abs(angle)>90:raise ValueError('각도 -90~90°')
            s['alignment']=dict(enabled=bool(d.get('enabled')),angle=angle,source=d.get('source','manual'));self.dirty(s,True)
        elif op=='suggest_angle':return gradient_angle(s['rgb'],valid_region(s['rgb'].shape[:2],s['layout']))
        elif op=='prompts':
            pts=np.asarray(d.get('points',[]),float).reshape(-1,2);labels=d.get('labels',[]);h,w=s['rgb'].shape[:2]
            if len(pts)!=len(labels) or any(v not in (0,1) for v in labels) or not np.isfinite(pts).all() or (len(pts) and ((pts<0).any() or (pts[:,0]>=w).any() or (pts[:,1]>=h).any())):raise ValueError('점 입력 오류')
            box=d.get('box')
            if box is not None:
                if len(box)!=4 or not np.isfinite(box).all() or not(0<=box[0]<box[2]<w and 0<=box[1]<box[3]<h):raise ValueError('박스는 이미지 내부의 좌상/우하 범위여야 합니다.')
            r.update(points=pts.tolist(),labels=labels,box=box,mask=None,candidates=[],score=None);self.dirty(s);s['clicks']+=int(d.get('new_clicks',0))
        elif op=='segment':
            candidates=self.predict(s,r['points'],r['labels'],r['box']);r['candidates']=candidates;a=max(candidates,key=lambda a:a['score']);r.update(mask=a['mask'],score=a['score']);self.dirty(s);s['overrides']=[];s['pins']=[]
        elif op=='choose_mask':
            a=r['candidates'][int(d['index'])];r.update(mask=a['mask'].copy(),score=a['score']);self.dirty(s);s['overrides']=[];s['pins']=[]
        elif op=='copy_anchor':
            if s['roles']['target']['mask'] is None:raise ValueError('대상층 마스크 없음')
            s['roles']['anchor']=copy.deepcopy(s['roles']['target'])
        elif op=='import_mask':
            im=Image.open(io.BytesIO(base64.b64decode(d['data'],validate=True))).convert('L')
            if im.size!=(s['rgb'].shape[1],s['rgb'].shape[0]):raise ValueError('원본과 같은 크기의 마스크가 필요합니다.')
            m=(np.array(im)>127)&valid_region(s['rgb'].shape[:2],s['layout'])
            if not m.any():raise ValueError('빈 마스크')
            r.update(mask=m,candidates=[],score=None,points=[interior_point(m)],labels=[1],box=None);self.dirty(s);s['overrides']=[];s['pins']=[]
        elif op=='refine_all':return self.refine(s,d.get('settings'))
        elif op=='override':
            if s['boundary'] is None:raise ValueError('전체 보정을 먼저 실행하세요.')
            s['overrides'].append(d['override'])
            try:return self.refine(s,d.get('settings'))
            except Exception:s['overrides'].pop();raise
        elif op=='pin':
            if s['boundary'] is None:raise ValueError('전체 보정을 먼저 실행하세요.')
            s['pins'].append(d['pin'])
            try:return self.refine(s,d.get('settings'))
            except Exception:s['pins'].pop();raise
        elif op=='clear_local':s['overrides']=[];s['pins']=[];return self.refine(s)
        elif op=='search':return self.search(s,d)
        elif op=='apply_match':return self.apply_match(s,int(d['index']),progress)
        elif op=='manual_transfer':
            if self.reference is None or s['roles']['anchor']['mask'] is None:raise ValueError('참조와 현재 기준층 마스크가 필요합니다.')
            candidates=[dict(mask=s['roles']['anchor']['mask'],score=0)];rows=self.rank(s,candidates);s['_match_masks']=candidates;s['match']=dict(candidates=rows,manual_anchor=True);return self.apply_match(s,0,progress)
        elif op=='approve':
            if s['boundary'] is None:raise ValueError('전체 경계를 보정한 뒤 검토 완료하세요.')
            s['status']='사용자 검토 완료'
        else:raise ValueError('알 수 없는 요청: '+op)
        self.events.append(dict(op=op,image_id=s['id'],time=time.strftime('%Y-%m-%dT%H:%M:%S')));return True
    def rank(self,s,candidates):
        ref=self.reference
        if ref is None:raise ValueError('참조 저장 필요')
        rm=ref['roles']['anchor']['mask'];c0,a0,e0=mask_geometry(rm);ratio=ref['nm_per_px']/s['nm_per_px'] if ref['nm_per_px'] and s['nm_per_px'] else 1.
        rv=valid_region(rm.shape,ref['layout']);nv=valid_region(s['rgb'].shape[:2],s['layout']);rg=gray(ref['rgb']);ng=gray(s['rgb']);box=mask_box(rm,35)
        yy,xx=np.meshgrid(np.linspace(box[1],box[3],50),np.linspace(box[0],box[2],50),indexing='ij');q=np.c_[xx.ravel(),yy.ravel()];rvalid=ndi.map_coordinates(rv.astype(float),[q[:,1],q[:,0]],order=0)>.5;rows=[]
        for index,item in enumerate(candidates):
            m=item['mask']
            try:c1,a1,e1=mask_geometry(m)
            except ValueError:continue
            best=None
            for theta in [a1-a0,a1-a0+np.pi]:
                R=np.array([[np.cos(theta),-np.sin(theta)],[np.sin(theta),np.cos(theta)]])*ratio;M=np.c_[R,c1-R@c0];warped=warp_mask(rm,M,m.shape)&nv;iou=float((warped&m).sum()/max(1,(warped|m).sum()))
                z=np.array(transform_points(q,M));v=rvalid&(z[:,0]>=0)&(z[:,0]<m.shape[1]-1)&(z[:,1]>=0)&(z[:,1]<m.shape[0]-1);v&=ndi.map_coordinates(nv.astype(float),[z[:,1],z[:,0]],order=0,mode='constant',cval=0)>.5
                ncc=-1.
                if v.sum()>100 and v.sum()/max(rvalid.sum(),1)>.6:
                    x=ndi.map_coordinates(rg,[q[v,1],q[v,0]],order=1);y=ndi.map_coordinates(ng,[z[v,1],z[v,0]],order=1);x-=x.mean();y-=y.mean();den=np.linalg.norm(x)*np.linalg.norm(y);ncc=float(x@y/den) if den>1e-8 else -1.
                shape=float(np.exp(-abs(np.log((e1[1]/e1[0])/(e0[1]/e0[0])))));score=.5*iou+.35*max(0,ncc)+.15*shape
                row=dict(index=index,score=score,iou=iou,context_ncc=ncc,matrix=M.tolist(),sam_score=float(item.get('score',0)),scale_known=bool(ref['nm_per_px'] and s['nm_per_px']),angle_reliable=bool(e0[1]/e0[0]>2 and e1[1]/e1[0]>2))
                if best is None or score>best['score']:best=row
            rows.append(best)
        return sorted(rows,key=lambda x:x['score'],reverse=True)
    def search(self,s,d):
        if self.reference is None:raise ValueError('참조 저장 필요')
        # Only layout/preprocessing settings transfer. Physical calibration stays image-specific.
        s['layout']=copy.deepcopy(self.reference['layout']);s['sam_filter']=self.reference['sam_filter'].copy();self.dirty(s,True)
        rgb,v,T,ov=prepare(s);candidates=[]
        for a in self.backend.automatic(rgb,int(d.get('grid',12))):
            m=warp_mask(a['mask']&v,invert_affine(T),ov.shape)&ov
            if m.sum()>=20:candidates.append(dict(mask=m,score=float(a['score'])))
        rows=self.rank(s,candidates)
        if not rows:raise ValueError('기준층 후보가 없습니다. 현재 이미지에서 기준층을 직접 선택하세요.')
        s['_match_masks']=candidates;s['match']=dict(candidates=rows[:12],manual_anchor=False);s['status']='기준층 후보 검토 필요';return rows[:12]
    def apply_match(self,s,index,progress=lambda x:None):
        if self.reference is None or not s.get('match'):raise ValueError('기준층 후보 탐색 필요')
        ref=self.reference;row=s['match']['candidates'][index];M=np.array(row['matrix']);work=copy.deepcopy({k:v for k,v in s.items() if k!='_match_masks'});work['_match_masks']=s['_match_masks'];anchor=s['_match_masks'][row['index']]['mask'];flags=[]
        work['layout']=copy.deepcopy(ref['layout']);work['sam_filter']=ref['sam_filter'].copy();work['edge_filter']=ref['edge_filter'].copy();work['edge_same']=ref['edge_same'];work['boundary_settings']=ref['boundary_settings'].copy()
        if ref['alignment']['enabled']:
            if not row['angle_reliable'] and work['alignment'].get('source')!='manual':raise ValueError('회전 방향이 불확실합니다. 현재 이미지 수평각을 수동 설정 후 기준층을 다시 선택하세요.')
            angle=(ref['alignment']['angle']+np.degrees(np.arctan2(M[1,0],M[0,0]))+90)%180-90;work['alignment']=dict(enabled=True,angle=float(angle) if row['angle_reliable'] else work['alignment']['angle'],source='per-image matched anchor' if row['angle_reliable'] else 'manual')
        if not row['scale_known']:flags.append('이미지별 스케일 미확정: 동일 픽셀 배율 가정')
        work['roles']['anchor']=role()|dict(mask=anchor.copy(),points=[interior_point(anchor)],labels=[1])
        expected=warp_mask(ref['roles']['target']['mask'],M,s['rgb'].shape[:2]);valid=valid_region(expected.shape,work['layout']);expected&=valid
        if expected.sum()<20:raise ValueError('대상층 예상 위치가 유효 영역 밖입니다.')
        rt=ref['roles']['target'];points=transform_points(rt['points'],M);labels=rt['labels'].copy()
        if not points:points=[interior_point(expected)];labels=[1]
        # Add sparse safe interior positives and distant exterior negatives; the shape is a soft prior.
        dist=ndi.distance_transform_edt(expected);safe=dist>max(2,dist.max()*.4);ys,xs=np.nonzero(safe)
        if len(xs):
            for frac in (.15,.5,.85):
                ix=np.argsort(xs)[int((len(xs)-1)*frac)];points.append([float(xs[ix]),float(ys[ix])]);labels.append(1)
        pad=max(12,int(min(np.ptp(np.nonzero(expected)[0])+1,np.ptp(np.nonzero(expected)[1])+1)*.6));ring=(ndi.distance_transform_edt(~expected)>=pad)&(ndi.distance_transform_edt(~expected)<=pad+3)&valid
        ry,rx=np.nonzero(ring)
        if len(rx):
            for ix in set([int(np.argmin(rx)),int(np.argmax(rx)),int(np.argmin(ry)),int(np.argmax(ry))]):points.append([float(rx[ix]),float(ry[ix])]);labels.append(0)
        box=mask_box(expected,pad);local=mask_box(expected,pad+32)
        for p in points:
            local=[min(local[0],max(0,int(p[0])-8)),min(local[1],max(0,int(p[1])-8)),max(local[2],min(expected.shape[1]-1,int(p[0])+8)),max(local[3],min(expected.shape[0]-1,int(p[1])+8))]
        # Never reuse the AMG anchor as the target, including anchor == target in the reference.
        progress('대상층 별도 SAM 분할: '+s['name']);masks=self.predict(work,points,labels,box,local)
        loose=ndi.distance_transform_edt(~expected)<=max(8,pad)
        for a in masks:
            m=a['mask'];compliance=float(np.mean([bool(m[int(p[1]),int(p[0])])==bool(v) for p,v in zip(points,labels)]));iou=float((m&expected).sum()/max(1,(m|expected).sum()));spill=float((m&~loose).sum()/max(1,m.sum()));a.update(compliance=compliance,spill=spill,rank=.5*iou+.25*compliance+.15*float(a['score'])+.1*(1-spill))
        masks.sort(key=lambda a:a['rank'],reverse=True);choice=masks[0];work['roles']['target']=dict(points=points,labels=labels,box=box,mask=choice['mask'],score=choice['score'],candidates=masks)
        # Near-identical SAM alternatives are not independent ambiguity evidence.
        distinct=[a for a in masks[1:] if (a['mask']^choice['mask']).sum()/max(1,(a['mask']|choice['mask']).sum())>.08]
        ambiguous=bool(distinct and choice['rank']-distinct[0]['rank']<.03)
        work['boundary']=None;work['overrides']=[];work['pins']=[];work['match']['selected']=index
        if choice['compliance']<.999 or choice['spill']>.25 or choice['rank']<.5 or ambiguous:
            work['roles']['target']['mask']=None;work['status']='대상층 자동 선택 보류 · 후보/양성·음성점 검토 필요';flags.append('넓은 영역·프롬프트 불일치 또는 후보 모호성')
        else:
            self.refine(work);work['status']='자동 적용 후보 · 사용자 검토 필요'
        work['match']['flags']=flags;self.images[s['id']]=work;return dict(id=s['id'],status=work['status'],flags=flags)
    def overlay(self,s):
        im=Image.fromarray(s['rgb']).convert('RGBA');m=s['roles']['target']['mask']
        if m is not None:
            layer=np.zeros((*m.shape,4),np.uint8);layer[m]=[30,160,255,55];im=Image.alpha_composite(im,Image.fromarray(layer))
        draw=ImageDraw.Draw(im)
        for e in (s['boundary'] or {}).get('loops',[]):
            for key,color in [('initial','cyan'),('refined','yellow')]:
                p=[tuple(x) for x in e[key]];draw.line(p+p[:1],fill=color,width=1)
            for p,u in zip(e['refined'],e['uncertain']):
                if u:draw.ellipse((p[0]-1,p[1]-1,p[0]+1,p[1]+1),fill='red')
        return png_bytes(np.array(im.convert('RGB')))
    def export(self):
        out=io.BytesIO();manifest=dict(format='tem-boundary-2',images=[],reference=None,model=self.backend.info)
        with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
            def save(s,prefix):
                sm=self.summary(s);sm['match']=None;z.writestr(prefix+'/image.png',png_bytes(s['rgb']))
                for name,r in s['roles'].items():
                    if r['mask'] is not None:z.writestr(prefix+'/'+name+'.png',png_bytes(r['mask'].astype(np.uint8)*255))
                if s['boundary'] is not None:z.writestr(prefix+'/corrected.png',png_bytes(s['boundary']['mask'].astype(np.uint8)*255))
                z.writestr(prefix+'/overlay.png',self.overlay(s));return sm
            for i,s in self.images.items():manifest['images'].append(save(s,'images/'+i))
            if self.reference is not None:manifest['reference']=save(self.reference,'reference')
            z.writestr('project.json',json.dumps(manifest,ensure_ascii=False,indent=2));z.writestr('NOTICE.txt','Original-image pixel coordinates. Yellow: refined; cyan: initial; red: uncertain. No thickness/RMS measurement. SAM and matching scores are not calibrated accuracy.\n')
        return out.getvalue()
    def restore(self,blob):
        if len(blob)>200_000_000:raise ValueError('프로젝트 크기 제한 초과')
        with zipfile.ZipFile(io.BytesIO(blob)) as z:
            if sum(a.file_size for a in z.infolist())>800_000_000:raise ValueError('압축 해제 크기 제한 초과')
            manifest=json.loads(z.read('project.json'))
            if manifest.get('format')!='tem-boundary-2':raise ValueError('v2 프로젝트만 복원 가능합니다. v1 원본/마스크는 이미지·마스크 불러오기를 사용하세요.')
            if len(manifest['images'])>30:raise ValueError('최대 30장')
            def decode(sm,prefix):
                s=copy.deepcopy(sm);s['rgb']=read_image(z.read(prefix+'/image.png'));s.pop('width',None);s.pop('height',None)
                for name,r in s['roles'].items():
                    path=prefix+'/'+name+'.png';r['mask']=np.array(Image.open(io.BytesIO(z.read(path))).convert('L'))>127 if path in z.namelist() else None;r['candidates']=[];r.pop('has_mask',None)
                    if r['mask'] is not None and r['mask'].shape!=s['rgb'].shape[:2]:raise ValueError('마스크 크기 불일치')
                if s['boundary'] is not None:s['boundary']['mask']=np.array(Image.open(io.BytesIO(z.read(prefix+'/corrected.png'))).convert('L'))>127
                s['match']=None;return s
            new={a['id']:decode(a,'images/'+a['id']) for a in manifest['images']};ref=decode(manifest['reference'],'reference') if manifest.get('reference') else None
        self.images=new;self.reference=ref;return {'images':len(new),'note':'모델은 별도 로드, 프로파일은 보정 재실행 후 표시'}
