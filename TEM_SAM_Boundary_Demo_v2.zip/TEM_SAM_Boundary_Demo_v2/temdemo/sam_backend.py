"""Lazy imports: GUI, geometry and synthetic checks run without torch/SAM."""
from pathlib import Path
import gc
import numpy as np
from PIL import Image

class SamBackend:
    def __init__(self):
        self.predictor=None;self.model=None;self.image_key=None;self.info={'loaded':False}

    def load(self,model_type,checkpoint,device='auto'):
        if model_type not in ('vit_b','vit_l','vit_h'):raise ValueError('SAM1 vit_b/vit_l/vit_h만 지원합니다.')
        path=Path(checkpoint).expanduser().resolve()
        if not path.is_file():raise ValueError('실행 PC에서 체크포인트 경로를 찾을 수 없습니다.')
        try:
            import torch
            from segment_anything import sam_model_registry,SamPredictor
        except ImportError as e:
            raise RuntimeError('PyTorch / torchvision / 공식 segment_anything 설치가 필요합니다. README_KR.md를 확인하세요.') from e
        if device=='auto':device='cuda' if torch.cuda.is_available() else 'cpu'
        if device not in ('cpu','cuda'):raise ValueError('device는 auto/cpu/cuda')
        if device=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA를 사용할 수 없습니다. CPU 또는 PyTorch 설치 상태를 확인하세요.')
        self.predictor=None;self.model=None;self.image_key=None;self.info={'loaded':False};gc.collect()
        if torch.cuda.is_available():torch.cuda.empty_cache()
        model=sam_model_registry[model_type](checkpoint=str(path));model.to(device=device);model.eval()
        self.model=model;self.predictor=SamPredictor(model)
        self.info={'loaded':True,'model_type':model_type,'checkpoint':str(path),'device':device}
        return self.info

    def require(self):
        if self.predictor is None:raise RuntimeError('먼저 SAM 모델을 로드하세요. 합성 예제는 SAM 출력이 아닙니다.')

    def predict(self,rgb,key,points,labels,box=None):
        self.require()
        if not len(points) and box is None:raise ValueError('양성점 또는 박스를 먼저 지정하세요.')
        import torch
        with torch.inference_mode():
            if key!=self.image_key:self.predictor.set_image(rgb);self.image_key=key
            masks,scores,_=self.predictor.predict(point_coords=np.asarray(points,np.float32) if points else None,
                point_labels=np.asarray(labels,np.int32) if points else None,
                box=np.asarray(box,np.float32) if box else None,multimask_output=True)
        return [{'mask':m.astype(bool),'score':float(s)} for m,s in zip(masks,scores)]

    def automatic(self,rgb,points_per_side=12):
        self.require()
        import torch
        from segment_anything import SamAutomaticMaskGenerator
        h,w=rgb.shape[:2];factor=min(1.,1024/max(h,w));small=np.array(Image.fromarray(rgb).resize((round(w*factor),round(h*factor)),Image.Resampling.BILINEAR))
        if not 4<=points_per_side<=32:raise ValueError('자동 후보 grid 4~32')
        generator=SamAutomaticMaskGenerator(self.model,points_per_side=points_per_side,points_per_batch=8,
            pred_iou_thresh=.75,stability_score_thresh=.85,crop_n_layers=0,min_mask_region_area=0)
        self.image_key=None # AMG shares the model, but predictor embedding must be refreshed safely.
        with torch.inference_mode():annotations=generator.generate(small)
        annotations.sort(key=lambda x:x['predicted_iou']*x['stability_score'],reverse=True)
        output=[]
        for a in annotations[:60]:
            m=np.array(Image.fromarray(a['segmentation']).resize((w,h),Image.Resampling.NEAREST),bool)
            area=m.sum()
            if area<30 or area>.95*h*w:continue
            # Collapse duplicate masks, preserving genuinely different repeated cells.
            if any(np.sum(m & b['mask'])/max(1,np.sum(m | b['mask']))>.88 for b in output):continue
            output.append({'mask':m,'score':float(a['predicted_iou'])})
        if not output:raise RuntimeError('SAM 자동 후보가 없습니다. grid 조정 또는 현재 기준층 수동 지정 경로를 사용하세요.')
        return output
