"""Synthetic geometries with known pixel boundaries; NOT model predictions."""
import numpy as np
from scipy import ndimage as ndi

def make_sample(index=0):
    rng=np.random.default_rng(120+index);h,w=360,560;y,x=np.mgrid[:h,:w]
    angle=np.deg2rad([0,3,-4,6,-2,4,-6][index%7]);cx=280+[0,18,-15,8,-20,12,4][index%7];cy=170+[0,12,-10,18,7,-8,14][index%7]
    u=(x-cx)*np.cos(angle)+(y-cy)*np.sin(angle);v=-(x-cx)*np.sin(angle)+(y-cy)*np.cos(angle)
    wav=1.8*np.sin(u/55);thickness=26+index
    # Cell sides anchor translation along the layer; not infinite indistinguishable bands.
    cell=np.abs(u)<215;anchor=cell&(v>-60)&(v<-25);target=cell&(v>wav)&(v<wav+thickness)
    a=np.full((h,w),.60);a[cell&(v<-60)]=.43;a[anchor]=.82;a[cell&(v>=-25)&(v<wav)]=.55;a[target]=.24;a[cell&(v>=wav+thickness)&(v<80)]=.74
    a=ndi.gaussian_filter(a,.8)+rng.normal(0,.025+.002*index,a.shape)
    rgb=np.repeat((np.clip(a,0,1)*255).astype(np.uint8)[...,None],3,axis=2)
    def world(uu,vv):return np.c_[cx+uu*np.cos(angle)-vv*np.sin(angle),cy+uu*np.sin(angle)+vv*np.cos(angle)]
    us=np.linspace(-165,165,180);vv=1.8*np.sin(us/55)
    return {'rgb':rgb,'anchor':anchor,'target':target,'top':world(us,vv),'bottom':world(us,vv+thickness),
            'thickness_px':thickness,'nm_per_px':.2,'source':'SYNTHETIC_GROUND_TRUTH_NOT_SAM'}
