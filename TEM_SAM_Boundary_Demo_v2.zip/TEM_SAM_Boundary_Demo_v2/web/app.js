'use strict';
const $=id=>document.getElementById(id), canvas=$('canvas'), ctx=canvas.getContext('2d');
let state={images:[]}, current=null, img=null, maskImg=null, preview=null, mode='pan', pending=[], zoom=1, pan=[0,0], busy=false, drag=null, previewLabel='', selected=new Set();
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const s=()=>state.images.find(a=>a.id===current), role=()=>$('role').value;
function status(msg,error=false){$('status').textContent=msg;$('status').classList.toggle('error',error);}
function setbusy(value){busy=value;document.querySelectorAll('button').forEach(b=>b.disabled=value&&b.id!=='cancel');}
async function post(path,data){const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-TEM-Token':window.TEM_TOKEN},body:JSON.stringify(data)});if(!r.ok){let x=await r.json();throw Error(x.error||r.statusText);}return r;}
async function action(op,data={},refresh=true){if(busy)throw Error('작업이 끝난 뒤 다시 시도하세요.');setbusy(true);status('처리 중…');try{const r=await (await post('/api/action',{op,id:current,role:role(),...data})).json();let job;do{await new Promise(r=>setTimeout(r,150));job=await (await fetch('/api/job?id='+r.job)).json();if(job.message)status(job.message);}while(job.status==='running');if(job.status!=='done')throw Error(job.error||'작업 응답 없음');if(refresh)await reload();status(typeof job.result==='object'?JSON.stringify(job.result,null,2):'완료');return job.result;}catch(e){status(e.message,true);throw e;}finally{setbusy(false);}}
function safe(fn){return (...args)=>Promise.resolve().then(()=>fn(...args)).catch(e=>status(e.message,true));}
function bind(id,fn){$(id).onclick=safe(fn);}
async function reload(){state=await(await fetch('/api/state')).json();if(!state.images.some(a=>a.id===current))current=state.images[0]?.id||null;selected=new Set([...selected].filter(id=>state.images.some(a=>a.id===id)));renderControls();await loadImages();}
function readFilter(prefix){return {enabled:$(prefix+'enabled').checked,method:$(prefix+'method').value,sigma:+$(prefix+'sigma').value,sigma_space:+$(prefix+'space').value,sigma_color:+$(prefix+'color').value};}
function fillFilter(prefix,f){$(prefix+'enabled').checked=f.enabled;$(prefix+'method').value=f.method;$(prefix+'sigma').value=f.sigma;$(prefix+'space').value=f.sigma_space;$(prefix+'color').value=f.sigma_color;}
function settings(){return {inside:+$('inside').value,outside:+$('outside').value,polarity:$('polarity').value,smooth:+$('smooth').value,distance:+$('distance').value,jump:+$('jump').value,weak:.12};}
function renderControls(){
 $('profile').getContext('2d').clearRect(0,0,$('profile').width,$('profile').height);
 $('images').innerHTML=state.images.map(a=>`<div class="image-row ${a.id===current?'current':''}"><input type="checkbox" data-select="${a.id}" ${selected.has(a.id)?'checked':''}><button data-image="${a.id}" title="${esc(a.status)}">${esc(a.name)}</button></div>`).join('');
 document.querySelectorAll('[data-image]').forEach(b=>b.onclick=safe(async()=>{if(busy)return;current=b.dataset.image;pending=[];preview=null;renderControls();await loadImages();fit();}));
 document.querySelectorAll('[data-select]').forEach(c=>c.onchange=()=>c.checked?selected.add(c.dataset.select):selected.delete(c.dataset.select));
 $('modelstatus').textContent=state.model.loaded?`${state.model.model_type} · ${state.model.device}`:'SAM 모델 미로드';$('refstatus').textContent=state.reference?'참조: '+state.reference.name:'참조 없음';
 const a=s();$('empty').style.display=a?'none':'block';if(!a){$('candidates').innerHTML='';$('matches').innerHTML='';$('quality').textContent='';return;}
 fillFilter('sam',a.sam_filter);fillFilter('edge',a.edge_filter);$('edgesame').checked=a.edge_same;for(const k of ['inside','outside','polarity','smooth','distance','jump'])$(k).value=a.boundary_settings[k];
 $('nm').value=a.nm_per_px??'';$('alignenabled').checked=a.alignment.enabled;$('angle').value=a.alignment.angle;
 const meta=a.metadata;$('metadata').value=meta?JSON.stringify(meta,null,2):'';$('sampletext').value=meta?.values?.sample?.text||'';$('magtext').value=meta?.values?.magnification?.text||'';
 if(meta?.length_nm)$('scalenm').value=meta.length_nm;
 const r=a.roles[role()];$('candidates').innerHTML=r.candidates.map((c,i)=>`<button class="candidate" data-candidate="${i}">SAM 후보 ${i+1} · score ${c.score.toFixed(3)}${c.rank==null?'':` · rank ${c.rank.toFixed(3)}`}</button>`).join('');
 document.querySelectorAll('[data-candidate]').forEach(b=>{b.onclick=safe(()=>action('choose_mask',{index:+b.dataset.candidate}));b.onmouseenter=safe(()=>showCandidate('sam_candidate',+b.dataset.candidate));b.onmouseleave=safe(loadMask);});
 $('matches').innerHTML=(a.match?.candidates||[]).map((c,i)=>`<button class="candidate" data-match="${i}">기준 후보 ${i+1} · ${c.score.toFixed(3)} 적용</button>`).join('');
 document.querySelectorAll('[data-match]').forEach(b=>{b.onclick=safe(()=>action('apply_match',{index:+b.dataset.match}));b.onmouseenter=safe(()=>showCandidate('candidate',+b.dataset.match));b.onmouseleave=safe(loadMask);});
 const old=$('loop').value;$('loop').innerHTML=(a.boundary?.loops||[]).map((e,i)=>`<option value="${i}">경계 ${i+1} (${e.initial.length}지점)</option>`).join('');if(old!==''&&+old<(a.boundary?.loops.length||0))$('loop').value=old;
 $('quality').textContent=a.status+(a.boundary?'\n'+a.boundary.loops.map((e,i)=>`경계 ${i+1}: 미확정 ${(e.quality.uncertain_fraction*100).toFixed(1)}% · ${e.quality.flags.join(' / ')}`).join('\n'):'');$('quality').style.whiteSpace='pre-wrap';
}
function imageURL(url){return new Promise((resolve,reject)=>{const im=new Image();im.onload=()=>resolve(im);im.onerror=()=>reject(Error('이미지를 불러오지 못했습니다.'));im.src=url;});}
async function loadImages(){if(!s()){img=null;maskImg=null;draw();return;}const id=current;img=await imageURL('/image/'+id+'?t='+Date.now());if(id!==current)return;await loadMask();draw();}
async function loadMask(){maskImg=null;if(s()?.roles[role()].has_mask)maskImg=await imageURL(`/mask/${current}/${role()}?t=${Date.now()}`);draw();}
async function showCandidate(kind,index){if(busy)return;maskImg=await imageURL(`/mask/${current}/${role()}?${kind}=${index}`);draw();}
function viewAngle(){return s()&&$('alignedview').checked&&s().alignment.enabled?-s().alignment.angle*Math.PI/180:0;}
function rotated(p){const a=viewAngle(),w=s()?.width||0,h=s()?.height||0,x=p[0]-w/2,y=p[1]-h/2;return [Math.cos(a)*x-Math.sin(a)*y,Math.sin(a)*x+Math.cos(a)*y];}
function screen(p){let q=rotated(p);return [pan[0]+q[0]*zoom,pan[1]+q[1]*zoom];}
function original(p){const a=-viewAngle(),x=(p[0]-pan[0])/zoom,y=(p[1]-pan[1])/zoom;return [Math.cos(a)*x-Math.sin(a)*y+(s()?.width||0)/2,Math.sin(a)*x+Math.cos(a)*y+(s()?.height||0)/2];}
function fit(){if(!s())return;const w=s().width,h=s().height,a=viewAngle(),rw=Math.abs(Math.cos(a)*w)+Math.abs(Math.sin(a)*h),rh=Math.abs(Math.sin(a)*w)+Math.abs(Math.cos(a)*h);zoom=Math.min(canvas.width/rw,canvas.height/rh)*.95;pan=[canvas.width/2,canvas.height/2];draw();}
function line(points,color,width=1,closed=false){if(!points.length)return;ctx.strokeStyle=color;ctx.lineWidth=width;ctx.beginPath();points.forEach((p,i)=>{let q=screen(p);i?ctx.lineTo(...q):ctx.moveTo(...q);});if(closed)ctx.closePath();ctx.stroke();}
function dot(p,color,r=4){const q=screen(p);ctx.fillStyle=color;ctx.beginPath();ctx.arc(...q,r,0,Math.PI*2);ctx.fill();}
function draw(){ctx.clearRect(0,0,canvas.width,canvas.height);const a=s();if(!a||!img)return;ctx.save();ctx.translate(...pan);ctx.scale(zoom,zoom);ctx.rotate(viewAngle());ctx.translate(-a.width/2,-a.height/2);ctx.drawImage(preview||img,0,0);if($('showmask').checked&&maskImg)ctx.drawImage(maskImg,0,0);
 for(const [k,value] of Object.entries(a.layout)){for(const rect of(k==='exclude'?value:(value?[value]:[]))){const [x0,y0,x1,y1]=rect;ctx.fillStyle=k==='analysis'?'rgba(30,200,160,.06)':'rgba(255,70,70,.25)';ctx.strokeStyle=k==='analysis'?'#70edd0':'#ff7777';ctx.lineWidth=1/zoom;ctx.fillRect(x0*a.width,y0*a.height,(x1-x0)*a.width,(y1-y0)*a.height);ctx.strokeRect(x0*a.width,y0*a.height,(x1-x0)*a.width,(y1-y0)*a.height);}}
 ctx.restore();
 const r=a.roles[role()];r.points.forEach((p,i)=>dot(p,r.labels[i]?'#60ff9f':'#ff6b82',5));if(r.box){const[x,y,X,Y]=r.box;line([[x,y],[X,y],[X,Y],[x,Y]],'#75ffbf',1,true);}
 if($('showedges').checked)for(const e of(a.boundary?.loops||[])){line(e.initial,'#4bb5ff',1,true);line(e.refined,'#ffdc40',1.4,true);e.refined.forEach((p,i)=>{if(e.uncertain[i])dot(p,'#ff6d65',1.6);});if($('shownormals').checked){const cfg=a.boundary.settings;for(let i=0;i<e.initial.length;i+=12){const p=e.initial[i],n=e.normal[i];line([[p[0]-n[0]*cfg.inside,p[1]-n[1]*cfg.inside],[p[0]+n[0]*cfg.outside,p[1]+n[1]*cfg.outside]],'#96deca77',1);}}}
 for(const pin of a.pins)dot(pin.point,'#eea6ff',4);pending.forEach(p=>dot(p,'white',5));if(pending.length===2)line(pending,'white',1);$('caption').textContent=`${a.name} · ${a.width}×${a.height} · ${(zoom*100).toFixed(0)}% · 모드: ${mode}${preview?' · '+previewLabel+' 미리보기':''}`;
}
new ResizeObserver(()=>{const r=$('canvaswrap').getBoundingClientRect();canvas.width=Math.max(1,Math.floor(r.width));canvas.height=Math.max(1,Math.floor(r.height));if(pan[0]===0)fit();else draw();}).observe($('canvaswrap'));
function setMode(m){mode=m;pending=[];document.querySelectorAll('[data-mode]').forEach(b=>b.classList.toggle('active',b.dataset.mode===m));status(m==='positive'?'대상층 안을 클릭하세요.':m==='negative'?'제외할 다른 층을 클릭하세요.':m+' 모드');draw();}
document.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>setMode(b.dataset.mode));
canvas.onpointerdown=e=>{if(busy||!s())return;canvas.setPointerCapture(e.pointerId);drag={x:e.offsetX,y:e.offsetY,pan:[...pan],moved:false};};
canvas.onpointermove=e=>{if(drag&&mode==='pan'){const dx=e.offsetX-drag.x,dy=e.offsetY-drag.y;drag.moved ||=Math.hypot(dx,dy)>3;pan=[drag.pan[0]+dx,drag.pan[1]+dy];draw();}};
canvas.onpointerup=safe(async e=>{const was=drag;drag=null;if(!was||busy||!s()||mode==='pan')return;const p=original([e.offsetX,e.offsetY]);if(p[0]<0||p[1]<0||p[0]>=s().width||p[1]>=s().height)return;
 if(mode==='positive'||mode==='negative'){const r=s().roles[role()];await action('prompts',{points:[...r.points,p],labels:[...r.labels,mode==='positive'?1:0],box:r.box,new_clicks:1});return;}
 if(mode==='profile'){await plotProfile(p);return;}
 if(mode==='pin'){await action('pin',{pin:{loop:+$('loop').value,point:p}});return;}
 pending.push(p);draw();if(pending.length<2)return;const ends=pending;pending=[];const[x0,y0]=ends[0],[x1,y1]=ends[1],box=[Math.min(x0,x1),Math.min(y0,y1),Math.max(x0,x1),Math.max(y0,y1)];
 if(mode==='region'){const layout=structuredClone(s().layout),key=$('region').value,rect=box.map((v,i)=>v/(i%2?s().height:s().width));if(key==='exclude')layout.exclude.push(rect);else layout[key]=rect;await action('layout',{layout});}
 if(mode==='box'){const r=s().roles[role()];await action('prompts',{points:r.points,labels:r.labels,box});}
 if(mode==='angle'){let angle=Math.atan2(y1-y0,x1-x0)*180/Math.PI;angle=(angle+270)%180-90;$('angle').value=angle.toFixed(2);$('alignenabled').checked=true;status('각도를 확인한 뒤 현재 이미지에 적용하세요.');}
 if(mode==='scale'){const length=Math.hypot(x1-x0,y1-y0);$('nm').value=(+$('scalenm').value/length).toFixed(8);status('스케일 값을 확인한 뒤 이미지별 스케일 확정을 누르세요.');}
 if(mode==='override'){const cfg=settings();await action('override',{override:{loop:+$('loop').value,endpoints:ends,inside:cfg.inside,outside:cfg.outside,polarity:cfg.polarity}});}
 draw();});
canvas.onwheel=e=>{e.preventDefault();if(!s())return;const p=original([e.offsetX,e.offsetY]);zoom=Math.min(20,Math.max(.02,zoom*Math.exp(-e.deltaY*.001)));const q=rotated(p);pan=[e.offsetX-q[0]*zoom,e.offsetY-q[1]*zoom];draw();};
async function plotProfile(p){const a=s(),li=+$('loop').value,e=a.boundary?.loops[li];if(!e)throw Error('경계를 먼저 보정하세요.');let idx=0,best=Infinity;e.initial.forEach((q,i)=>{let d=Math.hypot(q[0]-p[0],q[1]-p[1]);if(d<best){best=d;idx=i;}});const r=await fetch(`/api/profile?id=${current}&loop=${li}&index=${idx}`),v=await r.json();if(!r.ok)throw Error(v.error);const c=$('profile');c.width=c.clientWidth;const g=c.getContext('2d'),w=c.width,h=c.height;g.clearRect(0,0,w,h);const max=Math.max(...v.response,1),xmin=v.offset[0],xmax=v.offset.at(-1),xx=x=>40+(x-xmin)/(xmax-xmin)*(w-55),yy=y=>h-25-y/max*(h-45);g.strokeStyle='#68e4cf';g.beginPath();v.response.forEach((y,i)=>i?g.lineTo(xx(v.offset[i]),yy(y)):g.moveTo(xx(v.offset[i]),yy(y)));g.stroke();g.strokeStyle='#ffdc40';g.beginPath();g.moveTo(xx(v.chosen),10);g.lineTo(xx(v.chosen),h-20);g.stroke();g.fillStyle='#dce5ee';g.font='12px sans-serif';g.fillText(`경계 ${li+1} · 지점 ${idx} · 선택 ${v.chosen.toFixed(1)} px (바깥쪽 +)`,12,14);g.fillText(xmin+' px',30,h-7);g.fillText(xmax+' px',w-50,h-7);}
async function b64(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result.split(',')[1]);r.onerror=reject;r.readAsDataURL(file);});}
$('upload').onchange=safe(async e=>{const files=await Promise.all([...e.target.files].map(async f=>({name:f.name,data:await b64(f)})));const ids=await action('upload',{files});current=ids[0]||current;await reload();fit();e.target.value='';});
$('restore').onchange=safe(async e=>{await action('restore',{data:await b64(e.target.files[0])});preview=null;fit();e.target.value='';});
$('importmask').onchange=safe(async e=>{await action('import_mask',{data:await b64(e.target.files[0])});e.target.value='';});
bind('synthetic',async()=>{await action('synthetic');preview=null;fit();});bind('delete',async()=>{const ids=selected.size?[...selected]:(current?[current]:[]);if(!ids.length)return;await action('delete',{ids});preview=null;fit();});
bind('loadmodel',()=>action('load_model',{model:$('model').value,checkpoint:$('checkpoint').value,device:$('device').value}));bind('segment',()=>action('segment'));bind('clearpoints',()=>action('prompts',{points:[],labels:[],box:null}));bind('copyanchor',()=>action('copy_anchor'));
bind('samsave',async()=>{preview=null;await action('sam_filter',{settings:readFilter('sam')});});
for(const prefix of ['sam','edge'])bind(prefix+'preview',async()=>{const cfg=prefix==='edge'&&$('edgesame').checked?s().sam_filter:readFilter(prefix);const result=await action('preview',{settings:cfg},false);preview=await imageURL('data:image/png;base64,'+result.preview);previewLabel=prefix==='sam'?'SAM 필터':'경계 필터';draw();});
bind('refine',async()=>{const cfg=settings(),filter=readFilter('edge'),same=$('edgesame').checked;await action('edge_filter',{settings:filter,same});await action('refine_all',{settings:cfg});});
bind('clearregions',()=>action('layout',{layout:{analysis:null,scale:null,sample:null,magnification:null,exclude:[]}}));bind('layoutall',()=>action('layout',{layout:s().layout,all:true}));
bind('ocr',async()=>{const m=await action('ocr',{executable:$('tesseract').value});if(m.suggested_nm_per_px){$('nm').value=m.suggested_nm_per_px;status('OCR 스케일 제안입니다. 원본과 대조한 뒤 확정하세요.');}});
bind('ocrall',async()=>{for(const a of state.images){await action('ocr',{id:a.id,executable:$('tesseract').value});}status('각 이미지 OCR 완료. 스케일은 이미지별로 확인·확정하세요.');});
bind('savemeta',()=>action('metadata',{sample:$('sampletext').value,magnification:$('magtext').value}));bind('calibrate',()=>action('calibrate',{nm_per_px:$('nm').value}));
bind('suggestangle',async()=>{const v=await action('suggest_angle',{},false);$('angle').value=v.angle.toFixed(2);status(`각도 제안 ${v.angle.toFixed(2)}° · 방향 일관성 ${v.coherence.toFixed(3)}. ${v.warning}`);});
bind('applyangle',async()=>{await action('alignment',{enabled:$('alignenabled').checked,angle:+$('angle').value});fit();});
bind('reference',()=>action('reference'));bind('search',()=>action('search'));bind('manualtransfer',()=>action('manual_transfer'));bind('batch',()=>action('batch',{ids:state.images.map(a=>a.id)}));bind('cancel',async()=>{await post('/api/cancel',{});status('현재 이미지 처리 후 중지합니다.');});bind('clearlocal',()=>action('clear_local'));bind('approve',()=>action('approve'));
bind('export',async()=>{const r=await post('/api/export',{}),blob=await r.blob(),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='TEM_Boundary_v2_session.zip';a.click();setTimeout(()=>URL.revokeObjectURL(url),5000);});
bind('fit',fit);bind('original',()=>{preview=null;draw();});$('role').onchange=safe(async()=>{pending=[];renderControls();await loadMask();});$('alignedview').onchange=fit;for(const id of ['showmask','showedges','shownormals'])$(id).onchange=draw;
safe(async()=>{await reload();fit();})();
