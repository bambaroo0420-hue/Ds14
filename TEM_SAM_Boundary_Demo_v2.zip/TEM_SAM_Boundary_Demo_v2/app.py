#!/usr/bin/env python3
"""Loopback-only, offline browser UI. No CDN, telemetry, remote inference or auto-download."""
import argparse,base64,json,secrets,threading,time,traceback,webbrowser
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse,parse_qs
import numpy as np
from temdemo.engine import Engine,png_bytes
from temdemo.imaging import filter_image, sanitized, valid_region
ROOT=Path(__file__).resolve().parent

def make_server(port=8765,engine=None):
    engine=engine or Engine();token=secrets.token_urlsafe(24);pool=ThreadPoolExecutor(max_workers=1);jobs={};lock=threading.Lock()
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,fmt,*args):pass
        def allowed(self):
            host=self.headers.get('Host','').split(':')[0]
            if host not in ('127.0.0.1','localhost'):return False
            origin=self.headers.get('Origin')
            if origin and origin not in (f'http://127.0.0.1:{self.server.server_port}',f'http://localhost:{self.server.server_port}'):return False
            return True
        def reply(self,status,body,mime='application/json; charset=utf-8',name=None):
            if not isinstance(body,bytes):body=json.dumps(body,ensure_ascii=False,allow_nan=False).encode()
            self.send_response(status);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(body)))
            self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
            if name:self.send_header('Content-Disposition',f'attachment; filename="{name}"')
            self.end_headers()
            try:self.wfile.write(body)
            except (BrokenPipeError,ConnectionResetError):pass
        def do_GET(self):
            if not self.allowed():return self.reply(403,{'error':'localhost only'})
            parsed=urlparse(self.path);path=parsed.path;qs=parse_qs(parsed.query)
            try:
                if path=='/':return self.reply(200,(ROOT/'web/index.html').read_bytes().replace(b'__TOKEN__',token.encode()),'text/html; charset=utf-8')
                if path in ('/app.js','/style.css'):
                    return self.reply(200,(ROOT/'web'/path[1:]).read_bytes(),'text/javascript; charset=utf-8' if path.endswith('js') else 'text/css; charset=utf-8')
                if path=='/api/state':return self.reply(200,engine.state())
                if path=='/api/job':return self.reply(200,jobs.get(qs.get('id',[''])[0],{'status':'missing'}))
                if path.startswith('/image/'):
                    s=engine.images[path.split('/')[2]];return self.reply(200,png_bytes(s['rgb']),'image/png')
                if path.startswith('/mask/'):
                    _,_,i,role=path.split('/');s=engine.images[i];m=s['boundary']['mask'] if role=='corrected' and s['boundary'] else (s['roles'][role]['mask'] if role in s['roles'] else None)
                    if 'sam_candidate' in qs:m=s['roles'][role]['candidates'][int(qs['sam_candidate'][0])]['mask']
                    if 'candidate' in qs:
                        ix=int(qs['candidate'][0]);row=s['match']['candidates'][ix];m=s['_match_masks'][row['index']]['mask']
                    if m is None:return self.reply(404,{'error':'No mask'})
                    rgba=np.zeros((*m.shape,4),np.uint8);rgba[m]=[80,210,150,95] if role=='anchor' else [40,150,255,95]
                    return self.reply(200,png_bytes(rgba),'image/png')
                if path=='/api/profile':
                    s=engine.images[qs['id'][0]];e=s['boundary']['loops'][int(qs.get('loop',['0'])[0])]
                    if 'response' not in e:return self.reply(400,{'error':'경계 보정을 먼저 실행하세요.'})
                    idx=max(0,min(len(e['response'])-1,int(qs.get('index',['0'])[0])))
                    return self.reply(200,{'offset':e['offset_grid'],'response':e['response'][idx],'chosen':e['offset_px'][idx],'index':idx})
                return self.reply(404,{'error':'not found'})
            except Exception as e:return self.reply(400,{'error':str(e)})
        def do_POST(self):
            if not self.allowed() or self.headers.get('X-TEM-Token')!=token:return self.reply(403,{'error':'Invalid local session token. Reload this page.'})
            try:
                n=int(self.headers.get('Content-Length','0'))
                if n>280_000_000:return self.reply(413,{'error':'Request too large'})
                d=json.loads(self.rfile.read(n) or b'{}')
                if self.path=='/api/cancel':engine.cancel=True;return self.reply(200,{'note':'현재 이미지 완료 후 중지합니다.'})
                with lock:
                    if any(j['status']=='running' for j in jobs.values()):return self.reply(409,{'error':'작업이 진행 중입니다. 완료 후 다시 시도하세요.'})
                    if self.path=='/api/export':return self.reply(200,engine.export(),'application/zip','TEM_session_results.zip')
                    if self.path!='/api/action':return self.reply(404,{'error':'not found'})
                    jobid=secrets.token_hex(6);jobs[jobid]={'status':'running','message':'처리 중'}
                    def run():
                        try:
                            op=d.pop('op')
                            if op=='preview':
                                s=engine.images[d['id']];cfg=d['settings'];f=filter_image(sanitized(s['rgb'],valid_region(s['rgb'].shape,s['layout'])),cfg);result={'preview':base64.b64encode(png_bytes(f)).decode()}
                            else:result=engine.action(op,d,lambda msg:jobs[jobid].update(message=msg))
                            jobs[jobid]={'status':'done','result':result}
                        except Exception as e:
                            traceback.print_exc();jobs[jobid]={'status':'error','error':str(e)}
                    pool.submit(run)
                return self.reply(200,{'job':jobid})
            except Exception as e:return self.reply(400,{'error':str(e)})
    server=ThreadingHTTPServer(('127.0.0.1',port),Handler);server.daemon_threads=True;server.engine=engine;server.token=token;server.pool=pool
    return server

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8765);p.add_argument('--no-browser',action='store_true');args=p.parse_args()
    server=make_server(args.port);url=f'http://127.0.0.1:{server.server_port}'
    print('TEM SAM Boundary Demo v2.0\n'+url+'\nKeep this terminal open. Ctrl+C to stop.',flush=True)
    if not args.no_browser:threading.Timer(.7,lambda:webbrowser.open(url)).start()
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close();server.pool.shutdown(wait=False,cancel_futures=True)
