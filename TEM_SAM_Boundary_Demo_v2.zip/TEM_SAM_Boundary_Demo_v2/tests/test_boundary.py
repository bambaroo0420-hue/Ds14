import base64,io,json,sys,unittest,zipfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from scipy import ndimage as ndi
from PIL import Image
from temdemo.engine import Engine,png_bytes
from temdemo.boundary import refine_all,topology,crossing
from temdemo.imaging import valid_region,prepare,rotation_map,invert_affine,filter_image,annotations
from temdemo.core import transform_points,warp_mask

class TestBoundary(unittest.TestCase):
    def scene(self):
        y,x=np.mgrid[:160,:240];truth=((x-120)/75)**2+((y-80)/35)**2<1
        rgb=np.repeat((35+truth.astype(np.uint8)*150)[...,None],3,axis=2);mask=ndi.binary_dilation(truth,iterations=4)
        return rgb,mask,truth
    def test_refinement_improves_displaced_ellipse(self):
        rgb,mask,truth=self.scene();b=refine_all(rgb,mask,np.ones(mask.shape,bool),dict(inside=12,outside=8),dict(enabled=True,method='gaussian',sigma=1.))
        raw=(mask&truth).sum()/(mask|truth).sum();new=(b['mask']&truth).sum()/(b['mask']|truth).sum();print('ellipse IoU',raw,new)
        self.assertGreater(new,raw+.05);self.assertEqual(topology(mask),topology(b['mask']))
        self.assertTrue(all(not crossing(e['refined']) for e in b['loops']))
        e=b['loops'][0];p=np.array(e['initial']);n=np.array(e['normal']);self.assertGreater(np.mean(np.sum((p-[120,80])*n,axis=1)>0),.98)
    def test_flat_and_excluded_regions_are_not_invented(self):
        rgb,m,t=self.scene();valid=np.ones(m.shape,bool);valid[70:90,:]=False;m&=valid
        b=refine_all(np.full_like(rgb,80),m,valid,dict(inside=8,outside=8))
        for e in b['loops']:self.assertTrue(np.allclose(e['initial'],e['refined']));self.assertTrue(all(e['uncertain']))
        self.assertFalse(b['mask'][~valid].any())
    def test_hole_topology(self):
        rgb,m,t=self.scene();y,x=np.mgrid[:160,:240];hole=(x-120)**2+(y-80)**2<100;m[hole]=False;rgb[hole]=30
        b=refine_all(rgb,m,np.ones(m.shape,bool),dict(inside=7,outside=7),dict(enabled=True,method='gaussian',sigma=1.));self.assertEqual(len(b['loops']),2);self.assertEqual(topology(m),topology(b['mask']))
    def test_affine_round_trip_and_exclusion(self):
        rgb,m,t=self.scene();e=Engine();i=e.add('a',rgb);s=e.images[i];s['layout']['scale']=[0,.85,1,1];s['alignment']=dict(enabled=True,angle=13)
        work,v,T,ov=prepare(s);p=[[40,50],[120,70]];back=transform_points(transform_points(p,T),invert_affine(T));self.assertTrue(np.allclose(p,back));self.assertFalse(ov[-1].any())
    def test_reference_no_interfaces_delete_restore(self):
        e=Engine();ids=e.action('synthetic',{});i=ids[0];self.assertIsNone(e.images[i]['boundary']);e.action('reference',{'id':i});e.action('refine_all',{'id':i});blob=e.export();f=Engine();f.restore(blob);self.assertEqual(len(f.images),7);self.assertEqual(f.reference['id'],i);self.assertIsNotNone(f.images[i]['boundary']);f.action('delete',{'ids':[i,ids[1]]});self.assertEqual(len(f.images),5);self.assertIsNone(f.reference)
    def test_preprocessing_invalidates_masks_preserves_points(self):
        e=Engine();i=e.action('synthetic',{})[0];pts=e.images[i]['roles']['target']['points'].copy();e.action('sam_filter',{'id':i,'settings':dict(enabled=True,method='gaussian',sigma=2.)});self.assertIsNone(e.images[i]['roles']['target']['mask']);self.assertEqual(e.images[i]['roles']['target']['points'],pts)
    def test_disabled_filter_identical(self):
        rgb,m,t=self.scene();self.assertTrue(np.array_equal(filter_image(rgb,dict(enabled=False)),rgb))
    def test_ocr_missing_is_optional(self):
        rgb,m,t=self.scene();e=Engine();i=e.add('x',rgb);s=e.images[i];s['layout']['scale']=[0,.8,1,1];a=annotations(s,'definitely_missing_tesseract');self.assertTrue(a['warnings']);self.assertIsNone(s['nm_per_px'])
    def test_local_override_and_pin_validation(self):
        rgb,m,t=self.scene();b=refine_all(rgb,m,np.ones(m.shape,bool),dict(inside=10,outside=10));p=b['loops'][0]['initial'];over=[dict(loop=0,endpoints=[p[5],p[15]],inside=3,outside=4,polarity='both')];b=refine_all(rgb,m,np.ones(m.shape,bool),dict(inside=10,outside=10),overrides=over);self.assertTrue(b['loops'])
    def test_target_always_resegmented_and_broad_candidate_rejected(self):
        rgb,m,t=self.scene();e=Engine();i=e.add('ref',rgb);j=e.add('next',rgb.copy());e.images[i]['roles']['target'].update(mask=t,points=[[120.,80.]],labels=[1]);e.action('reference',{'id':i})
        s=e.images[j];s['_match_masks']=[dict(mask=m,score=.99)];s['match']=dict(candidates=[dict(index=0,score=.99,matrix=[[1,0,0],[0,1,0]],scale_known=False,angle_reliable=True)])
        calls=[]
        def fake(work,points,labels,box,local):
            calls.append(True);return [dict(mask=np.ones(t.shape,bool),score=.99),dict(mask=t.copy(),score=.8)]
        e.predict=fake;e.apply_match(s,0);self.assertEqual(len(calls),1);self.assertTrue(np.array_equal(e.images[j]['roles']['target']['mask'],t))
        s=e.images[j]
        e.predict=lambda *args:[dict(mask=np.ones(t.shape,bool),score=.99)]
        e.apply_match(s,0);self.assertIsNone(e.images[j]['roles']['target']['mask']);self.assertIsNone(e.images[j]['boundary'])
    def test_predict_transform_clips_annotations_and_refreshes_cache_key(self):
        rgb,m,t=self.scene();e=Engine();i=e.add('input',rgb);s=e.images[i];s['layout']['scale']=[0,.85,1,1]
        class Fake:
            def __init__(self):self.keys=[]
            def predict(self,rgb,key,points,labels,box):self.keys.append(key);return [dict(mask=np.ones(rgb.shape[:2],bool),score=.8)]
        f=Fake();e.backend=f;a=e.predict(s,[[120,80]],[1]);self.assertFalse(a[0]['mask'][140:].any());s['sam_filter']['enabled']=True;e.predict(s,[[120,80]],[1]);self.assertNotEqual(f.keys[0],f.keys[1])

if __name__=='__main__':unittest.main(verbosity=2)
