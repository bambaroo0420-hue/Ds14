import sys,importlib,platform
print('Python:',sys.version,'\nPlatform:',platform.platform())
for name in ('numpy','scipy','PIL','matplotlib','torch','torchvision','segment_anything'):
    try:
        m=importlib.import_module(name);print(name,getattr(m,'__version__','import OK'))
        if name=='torch':print('  CUDA available:',m.cuda.is_available(),'CUDA runtime:',m.version.cuda)
    except Exception as e:print(name,'NOT READY:',str(e))
