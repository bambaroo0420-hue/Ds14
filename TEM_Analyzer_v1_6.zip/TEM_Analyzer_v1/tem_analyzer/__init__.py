"""Local TEM segmentation workbench."""
