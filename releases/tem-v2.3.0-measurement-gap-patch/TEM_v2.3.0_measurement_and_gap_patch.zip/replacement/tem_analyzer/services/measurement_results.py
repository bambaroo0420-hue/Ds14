"""Immutable per-run snapshots and separate numeric exports (not GT)."""
import copy
import csv
import io
import json
import uuid
import zipfile
from datetime import datetime, timezone
import numpy as np
from ..storage import atomic_json


def statistics(rows):
    values=np.array([r['length_nm'] for r in rows if r.get('status')=='ok'
                     and r.get('length_nm') is not None and np.isfinite(r['length_nm'])],float)
    n=len(values)
    return dict(count=n,excluded_count=len(rows)-n,total_count=len(rows),
        mean=float(values.mean()) if n else None,median=float(np.median(values)) if n else None,
        std=float(values.std(ddof=0)) if n else None,
        sample_std=float(values.std(ddof=1)) if n>1 else None,
        min=float(values.min()) if n else None,max=float(values.max()) if n else None,
        range=float(np.ptp(values)) if n else None,std_ddof=0,unit='nm')


def archive_measurement(project,iid,value):
    project.require_image(iid)
    value['run_id']=uuid.uuid4().hex
    value['saved_at_utc']=datetime.now(timezone.utc).isoformat()
    value['image_name']=project.state['images'][iid]['name']
    value['layer_name']=next((l['name'] for l in project.state['layers'] if l['id']==value.get('layer_id')),None)
    value['summary'].update(statistics(value['rows']))
    folder=project.root/'measurement_results'/iid;folder.mkdir(parents=True,exist_ok=True)
    atomic_json(folder/(value['run_id']+'.json'),value)


def export_results(project,ids,all_history=True):
    from .measurement import stored_measurements,measurement_hash
    def safe(value):
        return "'"+value if isinstance(value,str) and value.startswith(('=','+','-','@','\t','\r','\n')) else value
    def csv_text(header,rows):
        stream=io.StringIO(newline='');writer=csv.writer(stream);writer.writerow(header)
        writer.writerows([[safe(v) for v in row] for row in rows]);return '\ufeff'+stream.getvalue()
    summaries=[];details=[];output=io.BytesIO()
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
        count=0
        for iid in dict.fromkeys(ids):
            project.require_image(iid);values={}
            if all_history:
                for path in sorted((project.root/'measurement_results'/iid).glob('*.json')):
                    m=json.loads(path.read_text(encoding='utf8'));values[m['run_id']]=m
            for axis,m in stored_measurements(project,iid).items():
                values.setdefault(m.get('run_id','legacy_'+axis),copy.deepcopy(m))
            current=measurement_hash(project,iid)
            for run_id,m in sorted(values.items(),key=lambda item:item[1].get('saved_at_utc','')):
                count+=1;s=statistics(m['rows']);stale=m.get('input_hash')!=current
                meta=[iid,m.get('image_name',project.state['images'][iid]['name']),run_id,
                      m.get('saved_at_utc',''),m.get('layer_id'),m.get('layer_name'),m.get('scope_id'),
                      m['axis'],m.get('review_status','unknown'),stale]
                summaries.append(meta+[s[k] for k in ('count','excluded_count','total_count','mean','median','std','sample_std','min','max','range')]+[m.get('scale',{}).get('nm_per_px'),json.dumps(m.get('config',{}),ensure_ascii=False)])
                for index,row in enumerate(m['rows'],1):
                    valid=row.get('status')=='ok' and row.get('length_nm') is not None
                    deviation=row['length_nm']-s['mean'] if valid and s['mean'] is not None else None
                    details.append(meta+[index,row.get('component_id'),row.get('position_px'),row.get('segment'),row.get('status'),row.get('length_px'),row.get('length_nm'),row.get('raw_length_nm'),deviation,
                        json.dumps(row.get('original_endpoints')),json.dumps(row.get('aligned_endpoints'))])
                z.writestr(f'{iid}/{run_id}.json',json.dumps(dict(m,summary=s,stale_at_export=stale),ensure_ascii=False,indent=2,allow_nan=False))
        if not count:raise ValueError('저장된 계측 결과가 없습니다. 먼저 계측하세요.')
        common=['image_id','image_name','run_id','saved_at_utc','layer_id','layer_name','scope_id','axis','review_status','stale_at_export']
        z.writestr('summary.csv',csv_text(common+['valid_count','excluded_count','total_count','mean_nm','median_nm','std_population_nm','std_sample_nm','min_nm','max_nm','range_nm','nm_per_px','config_json'],summaries))
        z.writestr('measurements.csv',csv_text(common+['row_number','component_id','position_px','segment','status','length_px','length_nm','raw_length_nm','deviation_from_mean_nm','original_endpoints_json','aligned_endpoints_json'],details))
        z.writestr('README.txt','Statistics use only status=ok finite measurements. Units: nm. Population std: ddof=0; sample std: ddof=1 (blank for n<2). No pooling across runs, layers or images. Historical results may be stale; see stale_at_export and review_status. Snapshots retain their original scale and transform. New run history is retained from this patch onward; previously overwritten runs cannot be recovered. Undo does not erase archived runs.\n')
    return output.getvalue()
