"""Reviewable two-layer gap/overlap reconciliation, in original pixels.

Only opposing, single-interval layer scans are inferred. Exterior unknowns,
third layers and internal holes are not silently converted into material.
"""
from collections import Counter
import numpy as np
from scipy import ndimage as ndi
from .gap_bridge import _bounds
from ..geometry import gray


def reconcile(rgb, mask_a, mask_b, blocked, settings=None):
    cfg = dict(settings or {})
    axis = cfg.get('axis', 'auto')
    width = cfg.get('max_gap', 0)
    weak = float(cfg.get('min_gradient', .015))
    smooth = float(cfg.get('smooth', .12))
    fallback = cfg.get('distance_fallback', True)
    if axis not in ('auto', 'vertical', 'horizontal'):
        raise ValueError('잘못된 탐색 방향')
    if type(width) is not int or not 0 <= width <= 100000:
        raise ValueError('최대 폭은 0(제한 없음) 또는 양의 정수입니다.')
    if not np.isfinite([weak, smooth]).all() or not 0 < weak <= 1 or not 0 <= smooth <= 10:
        raise ValueError('Gradient/DP 설정 범위 오류')
    if type(fallback) is not bool:
        raise ValueError('거리 기반 제안 설정은 참/거짓입니다.')
    a, b, guard = (np.asarray(x, bool) for x in (mask_a, mask_b, blocked))
    if a.shape != b.shape or a.shape != guard.shape or rgb.shape[:2] != a.shape:
        raise ValueError('영상/마스크 크기 불일치')
    if not a.any() or not b.any():
        raise ValueError('두 레이어에 활성 마스크가 필요합니다.')
    policy=cfg.get('policy','auto')
    if policy not in ('auto','overlap_a','overlap_b'):
        raise ValueError('잘못된 배분 방식')
    if policy!='auto':
        changed=a&b&~guard;na=a.copy();nb=b.copy()
        if policy=='overlap_a':nb[changed]=False
        else:na[changed]=False
        return dict(mask_a=na,mask_b=nb,changed=changed,traces=[],axis=axis,
            filled_pixels=0,resolved_overlap_pixels=int(changed.sum()),
            changed_pixels=int(changed.sum()),remaining_overlap_pixels=int((na&nb).sum()),
            uncertain_scans=0,holes_preserved=True,skipped={},settings=cfg,
            note='명시적 겹침 우선순위 적용: '+('A' if policy=='overlap_a' else 'B')+
                 '에 겹친 픽셀을 남김. 빈틈/보호 영역은 변경하지 않음. 객체 소멸·분리는 검수 필요.')
    choices = []
    for ax in ('vertical', 'horizontal') if axis == 'auto' else (axis,):
        aa, bb = (a, b) if ax == 'vertical' else (a.T, b.T)
        af, al, av = _bounds(aa); bf, bl, bv = _bounds(bb)
        for reverse in (False, True):
            sf, sl, tf, tl = (bf, bl, af, al) if reverse else (af, al, bf, bl)
            # Each layer must retain its own outer edge: nested/identical masks
            # do not establish which material is on which side.
            good = av & bv & (sf < tf) & (sl < tl) & (sl + 1 != tf)
            lo = np.minimum(sl, tf - 1)
            hi = np.maximum(sl, tf - 1)
            if width:
                good &= hi - lo <= width
            choices.append((int(good.sum()), ax, reverse, lo, hi, good))
    _, axis, reverse, lo, hi, good = max(choices, key=lambda x: x[0])
    aa, bb = ((b.copy(), a.copy()) if reverse else (a.copy(), b.copy()))
    g = guard
    if axis == 'horizontal':
        aa, bb, g = aa.T, bb.T, guard.T
    f = ndi.gaussian_filter(gray(rgb), 1., mode='nearest')
    if axis == 'horizontal':
        f = f.T
    response = abs(np.diff(f, axis=0))
    reasons = Counter(); uncertain = 0; traces = []; scans = {}
    safe = ~ndi.binary_dilation(g, iterations=2)
    for x in range(aa.shape[1]):
        if not good[x]:
            reasons['unsupported_or_too_wide'] += 1
            continue
        l, h = int(lo[x]), int(hi[x])
        if not safe[l:h+2, x].all():
            reasons['protected_excluded_or_other_layer'] += 1
            continue
        r = response[l:h+1, x]
        weak_scan = float(r.max()) < weak
        if weak_scan and not fallback:
            reasons['weak_gradient'] += 1
            continue
        # A bounded grid keeps wide gaps tractable. Include the true strongest
        # edge as well as the exact midpoint; no 200px width ceiling.
        ys = np.unique(np.r_[np.linspace(l, h, min(129, h-l+1)).round().astype(int),
                               l + int(r.argmax()), (l+h)//2])
        signal = response[ys, x]
        cost = .10 * abs(ys-(l+h)/2) / max(1, h-l)
        if not weak_scan:
            cost = cost - signal / max(float(r.max()), weak)
        else:
            uncertain += 1
        scans[x] = (ys, cost, weak_scan)
    supported = np.array(sorted(scans), int)
    groups = np.split(supported, np.flatnonzero(np.diff(supported)>1)+1) if len(supported) else []
    for group in groups:
        prev = scans[int(group[0])][1].copy(); parents = []
        for old_x, x in zip(group[:-1], group[1:]):
            old_y = scans[int(old_x)][0]; ys, cost, _ = scans[int(x)]
            transition = prev[:, None] + smooth * abs(old_y[:, None]-ys[None, :])
            parent = transition.argmin(axis=0)
            prev = cost + transition[parent, np.arange(len(ys))]
            parents.append(parent)
        index = int(prev.argmin()); chosen = []
        for n in range(len(group)-1, -1, -1):
            chosen.append(int(scans[int(group[n])][0][index]))
            if n:
                index = int(parents[n-1][index])
        chosen.reverse()
        for x, y in zip(group, chosen):
            # Change ONLY the unknown/overlap band, retaining both outer edges.
            l, h = int(lo[x])+1, int(hi[x])+1
            aa[l:h+1, x] = np.arange(l, h+1) <= y
            bb[l:h+1, x] = np.arange(l, h+1) > y
        xy = lambda x, y: [int(x), float(y)] if axis == 'vertical' else [float(y), int(x)]
        mid = len(group)//2; x = int(group[mid]); y = chosen[mid]
        traces.append(dict(path=[xy(x, y+.5) for x,y in zip(group,chosen)],
            edge_a=[xy(x, lo[x]+.5) for x in group],
            edge_b=[xy(x, hi[x]+.5) for x in group],
            profile=dict(scan=x, coordinate=list(range(int(lo[x]),int(hi[x])+1)),
                         gradient=response[lo[x]:hi[x]+1,x].tolist(), chosen=y, axis=axis)))
    if axis == 'horizontal':
        aa, bb = aa.T, bb.T
    na, nb = (bb, aa) if reverse else (aa, bb)
    changed = (na != a) | (nb != b)
    assert not changed[guard].any()
    assert not ((na & nb) & ~(a & b)).any()
    filled = int((~(a|b) & (na|nb)).sum())
    removed = int(((a&b) & ~(na&nb)).sum())
    return dict(mask_a=na, mask_b=nb, changed=changed, traces=traces, axis=axis,
        filled_pixels=filled, resolved_overlap_pixels=removed, changed_pixels=int(changed.sum()),
        remaining_overlap_pixels=int((na&nb).sum()), uncertain_scans=uncertain,
        holes_preserved=True, skipped=dict(reasons), settings=cfg,
        note='선택 두 층 사이의 축 방향 단일 구간만 배분. 외곽/내부 구멍/보호 영역은 보존. '
             f'약한 신호의 거리 기반 제안 {uncertain}개 스캔은 반드시 검수. 강한 Gradient도 재료 정답 보장이 아님.')
