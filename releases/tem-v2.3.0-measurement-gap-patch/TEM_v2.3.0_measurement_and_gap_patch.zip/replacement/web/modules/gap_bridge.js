/* Two-layer gap preview and always-visible brush layer locks. No model required. */
export function mountGapBridge(T){
 const $=id=>document.getElementById(id);let token=null,previewImage=null,revision=null,imageReady=false;
 const locks=document.createElement('details');locks.id='brushLockPanel';locks.open=true;
 locks.innerHTML='<summary>브러시 · 레이어별 잠금 (프로젝트 전체)</summary><div id="brushLocks"></div><small id="brushTarget" role="status"></small>';
 $('canvasHost').before(locks);
 if(![...$('tool').options].some(o=>o.value==='roi'))$('tool').add(new Option('경계/회전 ROI 드래그','roi'));
 const panel=document.createElement('details');panel.open=true;panel.id='gapBridgePanel';
 panel.innerHTML=`<summary>두 레이어 겹침 제거 · 빈틈 자동 배분</summary>
 <p>선택한 두 층 사이의 빈틈과 겹침을 공통 경계로 나눠 배분합니다. 전체 미분류 영역을 무조건 채우지는 않습니다. 외곽·내부 구멍·보호·다른 층은 보존합니다. 두 대상 레이어의 잠금을 먼저 해제하세요.</p>
 <label>레이어 A<select id="gapLayerA"></select></label><label>레이어 B<select id="gapLayerB"></select></label>
 <label class="inline-check"><input id="gapAllPairs" type="checkbox">현재 이미지의 모든 인접 레이어 쌍 자동 처리 (레이어 목록 순서)</label>
 <label>배분 방식<select id="gapPolicy"><option value="auto">Gradient/DP · 빈틈과 겹침 함께</option><option value="overlap_a">겹침만 A에 남기기 (B에서 제거)</option><option value="overlap_b">겹침만 B에 남기기 (A에서 제거)</option></select></label>
 <p>모든 쌍 처리에서 A/B는 목록의 앞/뒤 레이어입니다. A/B 우선 배분은 중첩·복잡한 겹침에도 적용되며 빈틈은 변경하지 않습니다.</p>
 <label>탐색 방향<select id="gapAxis"><option value="auto">자동 (위/아래 또는 좌/우)</option><option value="vertical">위/아래 층 · 세로 탐색</option><option value="horizontal">좌/우 층 · 가로 탐색</option></select></label>
 <label>최대 보정 폭 (원본 px, 0=제한 없음)<input id="gapMaxWidth" type="number" min="0" max="100000" step="1" value="0"></label>
 <label>최소 Gradient (밝기 0~1 기준)<input id="gapMinGradient" type="number" min="0.001" max="1" step="0.005" value="0.015"></label>
 <label>DP 연속성<input id="gapSmooth" type="number" min="0" max="10" step="0.05" value="0.12"></label>
 <label class="inline-check"><input id="gapUseROI" type="checkbox">그린 ROI 내부만</label>
 <label class="inline-check"><input id="gapFallback" type="checkbox" checked>약한 Gradient도 거리 기반으로 배분 제안 (검수 필수)</label>
 <p>복수 경계에서도 한 경계를 제안합니다. 제3층/공극을 선택 두 층으로 잘못 채우지 않았는지 확인하세요.</p>
 <button id="gapPreview" class="primary">겹침·빈틈 자동 제안 · 크게 보기</button><p id="gapSummary" role="status"></p>`;
 $('boundary').prepend(panel);
 const dialog=document.createElement('dialog');dialog.id='gapDialog';dialog.innerHTML=`<div class="dialog-heading"><h2>겹침·빈틈 검수 · 아직 적용 안 됨</h2><button id="gapClose">닫기</button></div>
 <p>흰색/주황: 보정 대역 경계 · 청록: 공통 경계 · 분홍: 변경 픽셀(빈틈 채움/겹침 해소). 선택한 대상 쌍만 처리합니다.</p>
 <div class="gap-review"><img id="gapPreviewImage" alt="원본 영상 위의 두 레이어와 빈틈 보정 제안"><div><p id="gapReviewStats"></p><canvas id="gapProfile" width="420" height="200" aria-label="대표 스캔의 실제 Gradient와 DP 선택 위치"></canvas><p id="gapProfileInfo"></p><pre id="gapWarnings"></pre></div></div>
 <label><input id="gapConfirm" type="checkbox">이미지를 검수했고, 변경 영역은 제3층/공극이 아닌 선택 두 층의 분할 오류입니다.</label>
 <p>이 확인은 재료 판별 모델이 대신하지 않습니다. 결과는 미검수 마스크로 저장되며 Undo 가능합니다.</p><button id="gapApply" disabled>검수한 겹침·빈틈 제안 적용</button>`;document.body.append(dialog);
 const reasonNames={unsupported_or_too_wide:'범위 밖/빈틈 폭 초과/스캔에 복수 구간',protected_excluded_or_other_layer:'보호·제외·다른 레이어',weak_gradient:'약한 Gradient',multiple_edges_possible_third_layer:'복수 경계: 제3층 가능성',short_run:'연속 스캔 부족',discontinuous_path:'연속 경로 실패',weak_selected_path:'선택 경로 신호 부족',topology_change:'객체/구멍 연결 구조 변화'};
 function owner(c){const seen=new Set();while(c&&c.layer_id==null&&c.parent&&!seen.has(c.id)){seen.add(c.id);c=T.state.candidates?.[T.current]?.find(v=>v.id===c.parent)}return T.state.layers?.find(l=>l.id===c?.layer_id)}
 function updateApply(){$('gapApply').disabled=T.busy||!token||!imageReady||!$('gapConfirm').checked||$('gapApply').dataset.hasChanges!=='true';}
 function invalidate(){token=null;imageReady=false;$('gapApply').disabled=true;$('gapConfirm').checked=false;}
 $('gapPreviewImage').onload=()=>{imageReady=!!token&&$('gapPreviewImage').naturalWidth>0;updateApply();};
 $('gapPreviewImage').onerror=()=>{imageReady=false;updateApply();$('gapReviewStats').textContent='제안 이미지를 불러오지 못했습니다. 다시 제안한 후 검수하세요. 적용은 차단됩니다.';};
 function render(){
  const layers=T.state.layers||[];
  $('brushLocks').innerHTML=layers.map(l=>`<button data-brush-lock="${l.id}" aria-pressed="${!!l.locked}" ${T.busy?'disabled':''}>${l.locked?'🔒':'🔓'} ${T.escape(l.name)} · ${l.locked?'잠김':'편집 가능'}</button>`).join('');
  for(const btn of $('brushLocks').querySelectorAll('button'))btn.onclick=()=>T.task(async()=>{const l=T.state.layers.find(x=>x.id===+btn.dataset.brushLock);await T.api('v2/lock',{layer_id:l.id,locked:!l.locked});await T.refresh()});
  const c=T.state.candidates?.[T.current]?.find(v=>v.id===T.selectedCandidate),l=owner(c);
  $('brushTarget').textContent=c?`브러시 대상 #${c.id} · ${l?l.name:'미배정'} · ${l?.locked?'잠겨 있어 적용 불가':'선택 mask만 수정 / 잠긴 타 레이어와 보호 픽셀 제외'}`:'브러시로 수정할 후보를 선택하세요.';
  $('applyBrush').disabled=T.busy||!c||!!l?.locked;
  for(const [id,fallback] of [['gapLayerA',0],['gapLayerB',1]]){const select=$(id),old=select.value;select.innerHTML=layers.map(l=>`<option value="${l.id}">${T.escape(l.name)}${l.locked?' 🔒':''}</option>`).join('');select.value=layers.some(l=>String(l.id)===old)?old:String(layers[fallback]?.id||'');}
  if(previewImage!==T.current||revision!==T.state.revision)invalidate();
  updateApply();
 }
 function plot(report){
  const c=$('gapProfile'),ctx=c.getContext('2d');ctx.clearRect(0,0,c.width,c.height);ctx.fillStyle='#17212b';ctx.fillRect(0,0,c.width,c.height);
  const p=report.traces?.[0]?.profile;if(!p){$('gapProfileInfo').textContent='유효 경로가 없어 프로파일이 없습니다.';return;}
  const xmin=p.coordinate[0],xmax=p.coordinate.at(-1),ymax=Math.max(...p.gradient,0.001),px=x=>45+(x-xmin)/Math.max(1,xmax-xmin)*355,py=y=>155-y/ymax*125;
  ctx.strokeStyle='#8995a6';ctx.beginPath();ctx.moveTo(45,20);ctx.lineTo(45,155);ctx.lineTo(400,155);ctx.stroke();ctx.strokeStyle='#83baff';ctx.beginPath();p.gradient.forEach((y,i)=>i?ctx.lineTo(px(p.coordinate[i]),py(y)):ctx.moveTo(px(p.coordinate[i]),py(y)));ctx.stroke();
  ctx.strokeStyle='#00ffff';ctx.beginPath();ctx.moveTo(px(p.chosen),20);ctx.lineTo(px(p.chosen),155);ctx.stroke();ctx.fillStyle='#fff';ctx.font='12px sans-serif';ctx.fillText('Gradient',4,13);ctx.fillText(ymax.toFixed(3),4,34);ctx.fillText('0',25,157);ctx.fillText(String(xmin),45,176);ctx.fillText(String(xmax),375,176);ctx.fillText('원본 '+(p.axis==='vertical'?'y':'x')+' (px)',155,194);
  $('gapProfileInfo').textContent=`대표 스캔 ${p.scan}px · DP 위치 ${p.chosen+.5}px. 선택 두 경계 사이의 실제 밝기 변화입니다.`;
 }
 $('gapPreview').onclick=()=>T.task(async()=>{
  invalidate();if(!T.current)throw Error('이미지를 선택하세요.');if($('gapUseROI').checked&&!T.boundaryROI)throw Error('입력 방식에서 경계/회전 ROI를 그리세요.');
  const settings={method:'gradient_bridge',reconcile:true,policy:$('gapPolicy').value||'auto',all_pairs:$('gapAllPairs').checked,layer_a:+$('gapLayerA').value,layer_b:+$('gapLayerB').value,axis:$('gapAxis').value,max_gap:+$('gapMaxWidth').value,min_gradient:+$('gapMinGradient').value,smooth:+$('gapSmooth').value,distance_fallback:$('gapFallback').checked};
  const r=await T.api('workflow/boundary/preview',{image_id:T.current,settings,roi:$('gapUseROI').checked?T.boundaryROI:null});
  await T.refresh();token=r.token;previewImage=T.current;revision=T.state.revision;
  const report={traces:r.reports.flatMap(p=>p.traces||[]),skipped:{},note:r.reports.map(p=>`레이어 ${p.layer_a??'A'}/${p.layer_b??'B'}: ${p.note||''}`).join('\n')};
  for(const key of ['filled_pixels','resolved_overlap_pixels','remaining_overlap_pixels','uncertain_scans'])report[key]=r.reports.reduce((n,p)=>n+(p[key]||0),0);
  for(const p of r.reports)for(const [key,n] of Object.entries(p.skipped||{}))report.skipped[key]=(report.skipped[key]||0)+n;
  $('gapSummary').textContent=`변경 ${r.changed_pixels}px · 빈틈 채움 ${report.filled_pixels??0}px · 겹침 해소 ${report.resolved_overlap_pixels??0}px · 남은 겹침 ${report.remaining_overlap_pixels??0}px · 거리 기반 ${report.uncertain_scans??0}개 스캔 · 아직 적용 안 됨`;$('gapReviewStats').textContent=$('gapSummary').textContent;
  $('gapWarnings').textContent=Object.entries(report.skipped).map(([k,v])=>`${reasonNames[k]||k}: ${v}개 스캔`).join('\n')+'\n'+report.note;
  $('gapPreviewImage').src=`/api/workflow/boundary/${token}.png`;$('gapConfirm').checked=false;$('gapApply').dataset.hasChanges=String(r.changed_pixels>0);plot(report);dialog.showModal();
 });
 $('gapConfirm').onchange=updateApply;
 $('gapApply').onclick=()=>T.task(async()=>{if(!token||!$('gapConfirm').checked)throw Error('검수 확인이 필요합니다.');const r=await T.api('workflow/boundary/apply',{token,confirmed_two_layers:true});invalidate();dialog.close();await T.refresh();$('gapSummary').textContent=`${r.changed_pixels}px 적용 완료 · 새 마스크 ${r.created.map(c=>'#'+c.id).join(', ')} · GT 검수는 별도입니다.`;T.say(`${r.changed_pixels}px 빈틈 보정 적용. 새 마스크를 검수하세요.`)});
 $('gapClose').onclick=()=>{invalidate();dialog.close()};dialog.addEventListener('cancel',invalidate);
 for(const event of ['tem:refreshed','tem:idle','tem:candidate'])window.addEventListener(event,render);
 if(T.state.layers)render();
 return {render};
}
