import csv
import io
import json
import unittest
import zipfile
import numpy as np
import test_workflow
from tem_analyzer.services.measurement_results import statistics


class StatisticsTests(unittest.TestCase):
    def test_valid_only_and_ddof(self):
        s=statistics([{'status':'ok','length_nm':10},{'status':'ok','length_nm':20},
                      {'status':'invalid_region','length_nm':None,'raw_length_nm':900}])
        self.assertEqual(s['mean'],15);self.assertEqual(s['std'],5)
        self.assertAlmostEqual(s['sample_std'],np.sqrt(50));self.assertEqual(s['excluded_count'],1)
        self.assertIsNone(statistics([])['std'])
        s=statistics([{'status':'ok','length_nm':2}]);self.assertEqual(s['std'],0);self.assertIsNone(s['sample_std'])


class ResultsAPI(unittest.TestCase):
    setUp=test_workflow.WorkflowTest.setUp
    tearDown=test_workflow.WorkflowTest.tearDown

    def prepare(self):
        p=self.api.project;mask=np.zeros((60,80),bool);mask[20:40,10:70]=1
        p.put_candidate(self.id,mask,'fixture')['layer_id']=1
        self.client.post('/api/workflow/rotation/preview',json={'image_id':self.id,'config':{'layer_id':1,'mode':'edge','edge':'bottom'}})
        self.client.post('/api/workflow/rotation/confirm',json={'image_id':self.id})
        self.client.post('/api/scale/manual',json=dict(image_id=self.id,a=[5,55],b=[55,55],length=50,unit='nm'))

    def measure(self,axis='thickness'):
        r=self.client.post('/api/workflow/measurement',json={'image_id':self.id,'config':{'layer_id':1,'axis':axis,'start':25,'stop':35,'step':5}})
        self.assertEqual(r.status_code,200,r.text);return r.json()

    def test_repeat_saved_and_csv_statistics_and_reload(self):
        self.prepare();a=self.measure();b=self.measure();self.assertNotEqual(a['run_id'],b['run_id'])
        revision=self.api.project.state['revision']
        r=self.client.post('/api/workflow/measurement-results',json={'image_ids':[self.id]})
        self.assertEqual(self.api.project.state['revision'],revision)
        self.assertEqual(r.status_code,200,r.text[:100])
        with zipfile.ZipFile(io.BytesIO(r.content)) as z:
            rows=list(csv.DictReader(io.StringIO(z.read('summary.csv').decode('utf-8-sig'))))
            self.assertEqual(len(rows),2);self.assertAlmostEqual(float(rows[0]['mean_nm']),20)
            detail=list(csv.DictReader(io.StringIO(z.read('measurements.csv').decode('utf-8-sig'))))
            self.assertEqual(len(detail),6);self.assertAlmostEqual(float(detail[0]['deviation_from_mean_nm']),0)
            self.assertEqual(rows[0]['stale_at_export'],'False')
        from tem_analyzer.storage import Project
        from tem_analyzer.services.measurement_results import export_results
        restored=Project(self.temp.name)
        with zipfile.ZipFile(io.BytesIO(export_results(restored,[self.id]))) as z:
            self.assertEqual(len([n for n in z.namelist() if n.endswith('.json')]),2)

    def test_stale_history_exportable_with_warning_and_original_scale(self):
        self.prepare();a=self.measure()
        self.client.post('/api/scale/manual',json=dict(image_id=self.id,a=[5,55],b=[55,55],length=100,unit='nm'))
        r=self.client.post('/api/workflow/measurement-results',json={'image_ids':[self.id]})
        self.assertEqual(r.status_code,200)
        with zipfile.ZipFile(io.BytesIO(r.content)) as z:
            m=json.loads(z.read(f'{self.id}/{a["run_id"]}.json'))
            self.assertTrue(m['stale_at_export']);self.assertEqual(m['scale']['nm_per_px'],1)

    def test_no_text_default_and_optional_text(self):
        self.prepare();self.measure()
        url=f'/api/workbench/{self.id}/measurement.png?row=0'
        plain=self.client.get(url);explicit=self.client.get(url+'&labels=false');labelled=self.client.get(url+'&labels=true')
        self.assertEqual(plain.status_code,200);self.assertEqual(plain.content,explicit.content)
        self.assertNotEqual(plain.content,labelled.content)

    def test_empty_export_and_latest_only(self):
        self.assertEqual(self.client.post('/api/workflow/measurement-results',json={'image_ids':[self.id]}).status_code,400)
        self.prepare();self.measure();self.measure()
        r=self.client.post('/api/workflow/measurement-results',json={'image_ids':[self.id],'all_history':False})
        with zipfile.ZipFile(io.BytesIO(r.content)) as z:
            self.assertEqual(len([n for n in z.namelist() if n.endswith('.json')]),1)

if __name__=='__main__':unittest.main()
