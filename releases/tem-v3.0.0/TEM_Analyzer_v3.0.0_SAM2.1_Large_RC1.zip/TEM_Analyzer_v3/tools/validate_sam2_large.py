"""Actual Large checkpoint smoke; no downloads and no GT accuracy claims."""
from pathlib import Path
import argparse,sys,time,json
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tem_analyzer.sam_service import ModelService

def main():
    p=argparse.ArgumentParser();p.add_argument('--checkpoint',required=True);p.add_argument('--image',required=True);a=p.parse_args()
    import torch
    torch.set_num_threads(1)
    out=ROOT/'test-output/sam2-large';out.mkdir(parents=True,exist_ok=True)
    image=np.asarray(Image.open(a.image).convert('RGB'));h,w=image.shape[:2]
    points=[[w*.5,h*.5,1]];box=[w*.2,h*.2,w*.8,h*.8]
    service=ModelService();t=time.time();info=service.load(a.checkpoint,device='cpu')
    report={'model':info,'load_seconds':time.time()-t,'image':str(a.image),'shape':[h,w],'cases':[],'scope':'Actual Large runtime only; no expert GT / segmentation accuracy claim'}
    def run(name,fn):
        t=time.time();r=fn();m=r['mask'];assert m.shape==(h,w) and m.dtype==bool
        overlay=image.copy();overlay[m]=(image[m]*.55+np.array([0,220,100])*.45).astype(np.uint8)
        Image.fromarray(overlay).save(out/(name+'.png'))
        report['cases'].append(dict(name=name,seconds=time.time()-t,pixels=int(m.sum()),score=r.get('score'),prior_source=r.get('prior_source'),embedding_reused=r.get('embedding_reused')))
        (out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        print(report['cases'][-1],flush=True);return r
    first=run('point_box',lambda:service.prompt(image,points,box))
    run('cached_logits',lambda:service.prompt(image,points,prior=first))
    run('binary_prior',lambda:service.prompt(image,points,prior={'mask':first['mask']}))
    run('roi',lambda:service.in_roi(image,[int(w*.1),int(h*.1),int(w*.9),int(h*.9)],points,box))
    t=time.time();items=service.automatic(image,grid=2,pred_iou=0,stability=0,prepared_points=[[w*.4,h*.4],[w*.6,h*.6]])
    assert all(i['mask'].shape==(h,w) for i in items)
    report['automatic']={'seconds':time.time()-t,'candidates':len(items)}
    # Automatic generator must not corrupt the separately cached interactive predictor.
    run('after_automatic',lambda:service.prompt(image,points,box))
    (out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('PASS',flush=True)
if __name__=='__main__':main()
