"""Build a source-only archive; exclude weights, projects, caches and local outputs."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent/'release';OUT.mkdir(exist_ok=True)
dest=OUT/'TEM_Analyzer_v3.0.0_SAM2.1_Large_RC1.zip'
root_files=['run.py','check_environment.py','README_KO.md','setup.ipynb','requirements.txt','requirements-ocr.txt','start_windows.bat','install_windows.bat','diagnose_windows.bat','THIRD_PARTY_NOTICES.md','smoke_test.py']
tools=['server_setup.py','validate_server_notebook.py','check_gap_bridge.py','validate_sam2_large.py','package_v3.py']
files=[ROOT/name for name in root_files]+[ROOT/'tools'/name for name in tools]
for folder in ('tem_analyzer','web','vendor','tests','docs'):
    files.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pt','.pth'))
manifest={str(p.relative_to(ROOT)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(files))}
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
    for name in manifest:z.write(ROOT/name,'TEM_Analyzer_v3/'+name)
    z.writestr('TEM_Analyzer_v3/SOURCE_SHA256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(dest) as z:assert z.testzip() is None
digest=hashlib.sha256(dest.read_bytes()).hexdigest()
dest.with_suffix('.zip.sha256').write_text(digest+'  '+dest.name+'\n',encoding='ascii')
print(json.dumps({'zip':str(dest),'files':len(manifest),'bytes':dest.stat().st_size,'sha256':digest},indent=2))
