import unittest
from unittest.mock import patch
import numpy as np
from scipy import ndimage as ndi
from tem_analyzer.boundary import refine_all,topology
from tem_analyzer.boundary_iterative import initial_band

class IterativeTests(unittest.TestCase):
    def fixture(self):
        y,x=np.mgrid[:100,:120];gt=((x-60)/35)**2+((y-50)/25)**2<1
        m=ndi.binary_erosion(gt,iterations=6)
        image=np.repeat((ndi.gaussian_filter(gt.astype(float),1)*180+30)[...,None],3,2).astype('uint8')
        return image,m,np.ones_like(m)

    def test_steps_band_and_topology(self):
        im,m,v=self.fixture();r=refine_all(im,m,v,dict(inside=9,outside=9,iterations=8,step_px=1))
        self.assertEqual(topology(m),topology(r['mask']))
        self.assertFalse(np.any((r['mask']!=m)&~initial_band(m,9,9)))
        self.assertTrue(all(h['max_normal_step_px']<=1 for h in r['iteration_report']['history']))
        self.assertGreater(r['iteration_report']['changed_pixels'],0)

    def test_invalid_pixels_unchanged(self):
        im,m,v=self.fixture();v[:,55:65]=False
        r=refine_all(im,m,v,dict(inside=8,outside=8,iterations=4))
        np.testing.assert_array_equal(r['mask'][~v],m[~v])

    def test_flat_image_exact_noop(self):
        im,m,v=self.fixture();im[:]=120
        r=refine_all(im,m,v,dict(iterations=4))
        np.testing.assert_array_equal(r['mask'],m)

    def test_presmoothing_stays_in_original_band(self):
        im,m,v=self.fixture()
        r=refine_all(im,m,v,dict(inside=2,outside=2,iterations=3,initial_smoothing_sigma=1))
        self.assertFalse(np.any((r['mask']!=m)&~initial_band(m,2,2)))
        self.assertEqual(topology(m),topology(r['mask']))
        self.assertIn('initial_smoothing',r['iteration_report'])

    def test_presmoothing_cannot_remove_tiny_component(self):
        im,m,v=self.fixture();m[8,8]=True;im[:]=120
        r=refine_all(im,m,v,dict(iterations=3,initial_smoothing_sigma=1))
        self.assertTrue(r['iteration_report']['initial_smoothing']['rejected'])
        np.testing.assert_array_equal(r['mask'],m)

    def test_invalid_config_and_pins(self):
        im,m,v=self.fixture()
        for cfg in (dict(iterations=0),dict(iterations=41),dict(iterations=2,step_px=3)):
            with self.assertRaises(ValueError):refine_all(im,m,v,cfg)
        with self.assertRaises(ValueError):refine_all(im,m,v,dict(iterations=2),pins=[{}])

    def test_stronger_edge_outside_band_is_not_a_target(self):
        y,x=np.mgrid[:100,:120];m=((x-60)/25)**2+((y-50)/20)**2<1
        far=ndi.binary_dilation(m,iterations=14)
        im=np.repeat((ndi.gaussian_filter(far.astype(float),.5)*220)[...,None],3,2).astype('uint8')
        r=refine_all(im,m,np.ones_like(m),dict(inside=3,outside=3,iterations=12,corner_mode='guarded'))
        np.testing.assert_array_equal(m,r['mask'])

    def test_band_is_identical_for_every_pass(self):
        from tem_analyzer.boundary_iterative import refine_iterative
        im,m,v=self.fixture();original=refine_all;domains=[]
        def spy(*a,**kw):
            domains.append(kw['search_domain'].copy())
            return original(*a,**kw)
        with patch('tem_analyzer.boundary.refine_all',side_effect=spy):
            refine_iterative(im,m,v,dict(inside=9,outside=9,iterations=5,corner_mode='guarded'))
        self.assertGreater(len(domains),1)
        for d in domains:np.testing.assert_array_equal(d,initial_band(m,9,9)&v)

    def test_rejected_proposal_does_not_report_accepted_motion(self):
        from tem_analyzer.boundary_iterative import refine_iterative
        im,m,v=self.fixture();bad=m.copy();bad[2,2]=True
        loop=dict(initial=[[10,10]],refined=[[11,10]],offset_px=[1.],uncertain=[False],quality={'flags':[]})
        with patch('tem_analyzer.boundary.refine_all',return_value=dict(mask=bad,loops=[loop])):
            r=refine_iterative(im,m,v,dict(iterations=3))
        np.testing.assert_array_equal(r['mask'],m)
        self.assertEqual(r['iteration_report']['stop_reason'],'safety_rejected')
        self.assertEqual(r['loops'][0]['offset_px'],[0.])
