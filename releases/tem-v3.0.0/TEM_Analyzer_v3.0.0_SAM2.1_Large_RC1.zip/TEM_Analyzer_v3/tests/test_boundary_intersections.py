import unittest
from tem_analyzer.boundary import crossing

class IntersectionTests(unittest.TestCase):
    def test_simple_and_closed_polygons_allowed(self):
        self.assertFalse(crossing([[0,0],[2,0],[2,2],[0,2]]))
        self.assertFalse(crossing([[0,0],[1,0],[2,0],[2,2],[0,2],[0,0]]))

    def test_x_crossing(self):
        self.assertTrue(crossing([[0,0],[2,2],[0,2],[2,0]]))

    def test_vertex_touching_nonadjacent_edge(self):
        self.assertTrue(crossing([[0,0],[4,0],[4,4],[2,0],[0,4]]))

    def test_collinear_overlap(self):
        self.assertTrue(crossing([[0,0],[4,0],[4,3],[1,0],[3,0],[0,3]]))

    def test_degenerate_edge_rejected(self):
        self.assertTrue(crossing([[0,0],[2,0],[2,0],[0,2]]))

if __name__=='__main__':unittest.main()
