import unittest
import numpy as np
from tem_analyzer.sam_service import ModelService, ENGINE

class SAM2Contract(unittest.TestCase):
    def test_sam1_rejected_before_import_or_io(self):
        with self.assertRaisesRegex(ValueError,'전용'):
            ModelService().load('missing.pth',variant='vit_h')

    def test_sam1_decoder_rejected(self):
        for name in ('decoder_path','refiner_path','adaptation_path'):
            with self.assertRaisesRegex(ValueError,'호환'):
                ModelService().load('missing.pt',**{name:'weights.pt'})

    def test_context_separates_sam1_logits(self):
        s=ModelService();s.info={'checkpoint_sha256':'test'}
        self.assertEqual(s.context(np.zeros((12,25,3),np.uint8))['engine'],ENGINE)

    def test_failed_load_preserves_existing_predictor(self):
        s=ModelService();old=object();s.predictor=old
        with self.assertRaises(ValueError):s.load('missing.pt')
        self.assertIs(s.predictor,old)

    def test_default_api_variant(self):
        from tem_analyzer.api import ModelIn
        self.assertEqual(ModelIn(checkpoint='model.pt').variant,ENGINE)
