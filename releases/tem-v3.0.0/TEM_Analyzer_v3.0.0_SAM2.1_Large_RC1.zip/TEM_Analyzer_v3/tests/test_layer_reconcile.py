import unittest
import numpy as np
from tem_analyzer.algorithms.layer_reconcile import reconcile
from tem_analyzer.services.layers import propose_boundaries, unions
import test_gap_bridge
from test_gap_bridge import fixture


class ReconcileTests(unittest.TestCase):
    def test_gap_over_200(self):
        im=np.zeros((500,80,3),np.uint8);im[250:]=200
        a=np.zeros((500,80),bool);b=a.copy();a[10:100]=True;b[400:490]=True
        r=reconcile(im,a,b,np.zeros_like(a))
        self.assertEqual(r['filled_pixels'],300*80)
        self.assertTrue((r['mask_a']|r['mask_b'])[10:490].all())
        self.assertFalse((r['mask_a']&r['mask_b']).any())
        self.assertLessEqual(max(abs(y-249.5) for t in r['traces'] for x,y in t['path']),1)

    def test_overlap_not_deleted_from_both(self):
        im,a,b,g=fixture(0);a[50:65,10:110]=True;b[35:50,10:110]=True
        r=reconcile(im,a,b,g)
        self.assertEqual(r['resolved_overlap_pixels'],3000)
        self.assertFalse((r['mask_a']&r['mask_b']).any())
        np.testing.assert_array_equal(r['mask_a']|r['mask_b'],a|b)

    def test_flat_signal_fallback_and_strict_mode(self):
        im,a,b,g=fixture(40);im[:]=80
        r=reconcile(im,a,b,g)
        self.assertEqual(r['filled_pixels'],4000)
        self.assertEqual(r['uncertain_scans'],100)
        self.assertEqual(reconcile(im,a,b,g,{'distance_fallback':False})['filled_pixels'],0)

    def test_horizontal_reverse_and_mixed_overlap_gap(self):
        im,a,b,g=fixture(20);a[40:60,10:50]=True;b[40:60,10:50]=True
        r=reconcile(im.transpose(1,0,2),b.T,a.T,g.T)
        self.assertEqual(r['axis'],'horizontal')
        self.assertEqual(r['filled_pixels'],1200)
        self.assertEqual(r['resolved_overlap_pixels'],800)
        self.assertFalse((r['mask_a']&r['mask_b']).any())

    def test_guard_and_hole_and_exterior_preserved(self):
        im,a,b,g=fixture(20);a[20:25,20:25]=False;g[:,50:55]=True
        r=reconcile(im,a,b,g)
        self.assertFalse(r['changed'][g].any())
        self.assertFalse(r['mask_a'][20:25,20:25].any())
        self.assertFalse(r['mask_a'][:10].any())
        self.assertGreater(r['filled_pixels'],0)

    def test_no_identity_for_identical_or_nested_masks(self):
        im,a,b,g=fixture(0)
        self.assertEqual(reconcile(im,a,a,g)['changed_pixels'],0)
        b=a.copy();b[10:20]=False
        self.assertEqual(reconcile(im,a,b,g)['changed_pixels'],0)

    def test_explicit_overlap_priority_and_guard(self):
        im,a,b,g=fixture(0);b=a.copy();g[20:30,20:30]=True
        r=reconcile(im,a,b,g,{'policy':'overlap_a'})
        np.testing.assert_array_equal(r['mask_a'],a)
        self.assertEqual(r['remaining_overlap_pixels'],100)
        self.assertFalse(r['changed'][g].any())
        r=reconcile(im,a,b,g,{'policy':'overlap_b'})
        np.testing.assert_array_equal(r['mask_b'],b)
        self.assertEqual(r['remaining_overlap_pixels'],100)


class ReconcileAPI(test_gap_bridge.BridgeAPITests):
    def preview(self):
        return self.client.post('/api/workflow/boundary/preview',json=dict(image_id=self.iid,
            settings=dict(method='gradient_bridge',reconcile=True,layer_a=1,layer_b=2,max_gap=0)))

    def test_overlap_apply_and_undo(self):
        p,ca,cb,a,b=self.prepare()
        # Use a fresh parent candidate; masks on disk are immutable.
        a[30:65,10:110]=True;b[35:70,10:110]=True
        ca['active']=False;cb['active']=False
        p.put_candidate(self.iid,a,'fixture')['layer_id']=1
        p.put_candidate(self.iid,b,'fixture')['layer_id']=2;p.save()
        r=self.preview();self.assertEqual(r.status_code,200,r.text);r=r.json()
        self.assertEqual(r['reports'][0]['resolved_overlap_pixels'],3000)
        result=self.client.post('/api/workflow/boundary/apply',json={'token':r['token'],'confirmed_two_layers':True})
        self.assertEqual(result.status_code,200,result.text)
        m=unions(p,self.iid);self.assertFalse((m[1]&m[2]).any())
        np.testing.assert_array_equal(m[1]|m[2],a|b)
        self.assertEqual(self.client.post('/api/v2/undo',json={}).status_code,200)
        np.testing.assert_array_equal(unions(p,self.iid)[1],a)

    def test_outside_roi_overlap_no_longer_blocks(self):
        p,ca,cb,a,b=self.prepare();extra=a.copy();extra[40:80,:20]=True
        ca['active']=False;p.put_candidate(self.iid,extra,'fixture')['layer_id']=1;p.save()
        r=propose_boundaries(p,self.iid,dict(method='gradient_bridge',reconcile=True,
            layer_a=1,layer_b=2,max_gap=0),[.3,.2,.7,.8])
        self.assertGreater(r['changed_pixels'],0)
        self.assertFalse(r['changed'][:,:36].any())
        np.testing.assert_array_equal(r['masks'][1][:,:36],extra[:,:36])

    def test_all_adjacent_pairs_no_mutation_until_apply(self):
        p,ca,cb,a,b=self.prepare()
        third=np.zeros_like(a);third[94:99,10:110]=True
        p.state['layers'].append(dict(id=3,name='C',color='#ee4488'))
        p.put_candidate(self.iid,third,'fixture')['layer_id']=3;p.save()
        r=propose_boundaries(p,self.iid,dict(method='gradient_bridge',reconcile=True,
            all_pairs=True,max_gap=0))
        self.assertEqual(len(r['reports']),2)
        self.assertGreater(r['reports'][0]['filled_pixels'],0)
        self.assertGreater(r['reports'][1]['filled_pixels'],0)
        self.assertFalse((r['masks'][1]&r['masks'][2]).any())
        self.assertFalse((r['masks'][2]&r['masks'][3]).any())
        np.testing.assert_array_equal(unions(p,self.iid)[1],a)

    def test_all_pairs_skip_locked_not_error(self):
        p,*_=self.prepare();p.state['layers'][0]['locked']=True
        r=propose_boundaries(p,self.iid,dict(method='gradient_bridge',all_pairs=True,max_gap=0))
        self.assertEqual(r['changed_pixels'],0)
        self.assertEqual(r['reports'][0]['status'],'locked')


if __name__=='__main__':unittest.main()
