import unittest
from unittest.mock import patch

import numpy as np
from scipy import ndimage as ndi

from tem_analyzer.boundary import refine_all,raster
from tem_analyzer.geometry import mask_contours


class BoundaryPreservationTests(unittest.TestCase):
    def setUp(self):
        y,x=np.mgrid[:96,:128]
        self.mask=((x-64)/35)**2+((y-48)/23)**2<1
        self.valid=np.ones_like(self.mask)
        truth=ndi.binary_dilation(self.mask,iterations=4)
        self.image=np.repeat(np.where(truth,40,210)[...,None],3,axis=2).astype('uint8')

    def test_flat_image_no_motion_preserves_exact_pixels(self):
        result=refine_all(np.full_like(self.image,100),self.mask,self.valid)
        np.testing.assert_array_equal(result['mask'],self.mask)
        self.assertTrue(all(not any(loop['offset_px']) for loop in result['loops']))

    def test_crossing_cancellation_preserves_exact_pixels(self):
        with patch('tem_analyzer.boundary.crossing',return_value=True):
            result=refine_all(self.image,self.mask,self.valid,{'inside':8,'outside':8})
        np.testing.assert_array_equal(result['mask'],self.mask)
        self.assertTrue(any('자기 교차' in flag for loop in result['loops'] for flag in loop['quality']['flags']))

    def test_valid_region_does_not_erase_frozen_original_pixels(self):
        valid=self.valid.copy();valid[:50]=False
        result=refine_all(np.full_like(self.image,100),self.mask,valid)
        np.testing.assert_array_equal(result['mask'],self.mask)

    def test_isolated_pixel_preserved_without_aborting_other_boundary(self):
        mask=self.mask.copy();mask[12,12]=True
        result=refine_all(self.image,mask,self.valid,{'inside':8,'outside':8})
        self.assertTrue(result['mask'][12,12])
        self.assertTrue(any('작은 경계' in flag for loop in result['loops'] for flag in loop['quality']['flags']))
        self.assertGreater(result['mask'].sum(),mask.sum())

    def test_single_pixel_hole_preserved(self):
        mask=self.mask.copy();mask[48,64]=False
        result=refine_all(self.image,mask,self.valid,{'inside':8,'outside':8})
        self.assertFalse(result['mask'][48,64])
        self.assertGreater(result['mask'].sum(),mask.sum())

    def test_native_contour_roundtrip_preserves_random_pixels(self):
        rng=np.random.default_rng(20261002)
        for probability in (.1,.5,.9):
            mask=rng.random((40,50))<probability
            np.testing.assert_array_equal(raster(mask_contours(mask),mask.shape),mask)

    def test_cancelled_component_exact_while_other_component_moves(self):
        y,x=np.mgrid[:96,:160]
        mask=((x-40)**2+(y-48)**2<18**2)|((x-120)**2+(y-48)**2<18**2)
        truth=ndi.binary_dilation(mask,iterations=4)
        image=np.repeat(np.where(truth,40,210)[...,None],3,axis=2).astype('uint8')
        with patch('tem_analyzer.boundary.crossing',side_effect=lambda points: np.asarray(points)[:,0].mean()<80):
            result=refine_all(image,mask,np.ones_like(mask),{'inside':8,'outside':8})
        np.testing.assert_array_equal(result['mask'][:,:80],mask[:,:80])
        self.assertGreater(result['mask'][:,80:].sum(),mask[:,80:].sum())


if __name__=='__main__':unittest.main()
