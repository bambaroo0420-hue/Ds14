import unittest
import numpy as np
from scipy import ndimage as ndi
from tem_analyzer.boundary import refine_all,topology,crossing


class GuardedCornerTests(unittest.TestCase):
    def setUp(self):
        y,x=np.mgrid[:120,:160]
        self.truth=(x>30)&(x<130)&(y>30)&(y<95)
        gray=ndi.gaussian_filter(np.where(self.truth,40.,210.),1.5)
        self.image=np.repeat(gray.astype('uint8')[...,None],3,axis=2)
        self.mask=ndi.binary_erosion(self.truth,iterations=10)
        self.valid=np.ones_like(self.mask)

    def test_default_mode_retained(self):
        implicit=refine_all(self.image,self.mask,self.valid)
        explicit=refine_all(self.image,self.mask,self.valid,{'corner_mode':'freeze'})
        np.testing.assert_array_equal(implicit['mask'],explicit['mask'])

    def test_guarded_motion_is_bounded_and_preserves_topology(self):
        result=refine_all(self.image,self.mask,self.valid,{'corner_mode':'guarded','inside':20,'outside':20})
        self.assertEqual(topology(result['mask']),topology(self.mask))
        self.assertGreater(result['mask'].sum(),self.mask.sum())
        for loop in result['loops']:
            self.assertLessEqual(np.max(np.abs(loop['offset_px'])),20)
            self.assertFalse(crossing(loop['refined']))

    def test_excluded_band_cannot_be_crossed(self):
        valid=self.valid.copy();valid[30:35,:]=False
        result=refine_all(self.image,self.mask,valid,{'corner_mode':'guarded','inside':20,'outside':20})
        self.assertFalse(result['mask'][:30].any())
        np.testing.assert_array_equal(result['mask'][~valid],self.mask[~valid])

    def test_unknown_mode_rejected(self):
        with self.assertRaises(ValueError):refine_all(self.image,self.mask,self.valid,{'corner_mode':'unsafe'})


if __name__=='__main__':unittest.main()
