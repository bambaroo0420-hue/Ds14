import copy
import io
import unittest
import numpy as np
from PIL import Image
import test_workflow
from tem_analyzer.services.mask_matching import canonical,compare


class ShapeTests(unittest.TestCase):
    def test_scale_translation_and_aspect(self):
        a=np.zeros((100,160),bool);a[10:30,20:100]=1
        b=np.zeros((150,240),bool);b[60:100,30:190]=1
        c=np.zeros_like(a);c[20:70,40:90]=1
        x,_=canonical(a);y,_=canonical(b);z,_=canonical(c)
        self.assertAlmostEqual(compare(x,y)['score'],1)
        self.assertLess(compare(x,z)['score'],.5)
    def test_empty(self):
        with self.assertRaises(ValueError):canonical(np.zeros((10,10),bool))


class MatchAPI(unittest.TestCase):
    setUp=test_workflow.WorkflowTest.setUp
    tearDown=test_workflow.WorkflowTest.tearDown

    def setup_masks(self):
        p=self.api.project;b=io.BytesIO();Image.new('RGB',(80,60)).save(b,format='PNG')
        self.target=p.add_image(b.getvalue(),'target.png')
        m=np.zeros((60,80),bool);m[10:22,10:58]=1
        self.ref=p.put_candidate(self.id,m,'test');self.ref.update(layer_id=1,reviewed=True)
        self.candidates=[]
        for n in range(4):
            t=np.zeros_like(m);t[30:42+n*3,20:68]=1
            self.candidates.append(p.put_candidate(self.target,t,'test'))
        p.save()

    def search(self):
        r=self.client.post('/api/workflow/layers/match',json=dict(reference_image=self.id,image_id=self.target,threshold=.9))
        self.assertEqual(r.status_code,200,r.text);return r.json()

    def payload(self,r,index=0):
        return dict(reference_image=self.id,image_id=self.target,signature=r['signature'],threshold=r['threshold'],reference_candidate_id=self.ref['id'],candidate_id=r['proposals'][0]['candidates'][index]['candidate_id'])

    def test_readonly_top3_apply_single_and_stale(self):
        self.setup_masks();p=self.api.project;before=copy.deepcopy(p.state);r=self.search()
        self.assertEqual(before,p.state);self.assertEqual(len(r['proposals'][0]['candidates']),3)
        payload=self.payload(r);mask=p.mask(self.target,payload['candidate_id']).copy()
        q=self.client.post('/api/workflow/layers/match/accept',json=payload)
        self.assertEqual(q.status_code,200,q.text)
        assigned=[c for c in p.state['candidates'][self.target] if c.get('layer_id') is not None]
        self.assertEqual(len(assigned),1);self.assertFalse(assigned[0]['reviewed'])
        np.testing.assert_array_equal(mask,p.mask(self.target,payload['candidate_id']))
        self.assertEqual(self.client.post('/api/workflow/layers/match/accept',json=payload).status_code,400)
        from tem_analyzer.storage import Project
        self.assertEqual(Project(self.temp.name).candidate(self.target,payload['candidate_id'])['layer_id'],1)
        # The same reference cannot be used twice, even after ranking again.
        again=self.search();self.assertEqual(self.client.post('/api/workflow/layers/match/accept',json=self.payload(again)).status_code,400)

    def test_low_score_lock_and_non_top_candidate(self):
        self.setup_masks();r=self.search()
        low=self.payload(r,2);self.assertEqual(self.client.post('/api/workflow/layers/match/accept',json=low).status_code,400)
        low['allow_low_score']=True
        self.assertEqual(self.client.post('/api/workflow/layers/match/accept',json=low).status_code,200)

    def test_locked_and_changed_reference(self):
        self.setup_masks();r=self.search();self.api.project.state['layers'][0]['locked']=True
        self.assertEqual(self.client.post('/api/workflow/layers/match/accept',json=self.payload(r)).status_code,400)
        r=self.search();self.assertTrue(r['proposals'][0]['locked'])
        self.assertEqual(self.client.post('/api/workflow/layers/match/accept',json=self.payload(r)).status_code,400)

    def test_no_candidates_and_reference_required(self):
        self.setup_masks()
        for c in self.candidates:c['layer_id']=1
        self.assertEqual(self.search()['proposals'][0]['candidates'],[])
        self.ref['reviewed']=False
        self.assertEqual(self.client.post('/api/workflow/layers/match',json=dict(reference_image=self.id,image_id=self.target)).status_code,400)

    def test_reject_non_top_and_undo(self):
        self.setup_masks();r=self.search();payload=self.payload(r)
        payload['candidate_id']=self.candidates[-1]['id']
        self.assertEqual(self.client.post('/api/workflow/layers/match/accept',json=payload).status_code,400)
        payload=self.payload(r)
        self.assertEqual(self.client.post('/api/workflow/layers/match/accept',json=payload).status_code,200)
        self.assertEqual(self.client.post('/api/v2/undo').status_code,200)
        self.assertIsNone(self.api.project.candidate(self.target,payload['candidate_id'])['layer_id'])

    def test_batch_service_does_not_assign(self):
        self.setup_masks()
        from tem_analyzer.services.layers import transfer_layers
        before=copy.deepcopy(self.api.project.state)
        result=transfer_layers(self.api.project,self.id,self.target)
        self.assertEqual(before,self.api.project.state)
        self.assertEqual(len(result['proposals'][0]['candidates']),3)
