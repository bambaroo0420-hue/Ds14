"""Mask-only recommendations. Never assign during ranking; preserve native masks."""
import base64
import hashlib
import io
import numpy as np
from PIL import Image
from scipy import ndimage as ndi


def stamp(project, reference, target):
    from .layers import fingerprint
    return hashlib.sha256((fingerprint(project, reference)+fingerprint(project, target)).encode()).hexdigest()


def canonical(mask):
    y,x=np.nonzero(mask)
    if not len(x):
        raise ValueError('빈 마스크는 대응할 수 없습니다.')
    crop=mask[y.min():y.max()+1,x.min():x.max()+1]
    h,w=crop.shape; scale=64/max(h,w)
    small=np.asarray(Image.fromarray(crop).resize((max(1,round(w*scale)),max(1,round(h*scale))),Image.Resampling.NEAREST),bool)
    out=np.zeros((112,112),bool); sh,sw=small.shape
    out[(112-sh)//2:(112-sh)//2+sh,(112-sw)//2:(112-sw)//2+sw]=small
    return out,dict(area=int(mask.sum()),width=w,height=h,longest=max(h,w))


def png(rgb):
    stream=io.BytesIO();Image.fromarray(rgb).save(stream,format='PNG')
    return 'data:image/png;base64,'+base64.b64encode(stream.getvalue()).decode('ascii')


def compare(ref, candidate):
    # Canonical long-axis scaling is uniform, not independent width/height warping.
    best=None
    for angle in range(-30,31,5):
        m=ndi.rotate(candidate,angle,reshape=False,order=0,prefilter=False)>0
        score=float((ref&m).sum()/max(1,(ref|m).sum()))
        if best is None or score>best[0]:best=(score,angle,m)
    score,angle,m=best
    a=ref&~ndi.binary_erosion(ref);b=m&~ndi.binary_erosion(m)
    distance=float((ndi.distance_transform_edt(~a)[b].mean()+ndi.distance_transform_edt(~b)[a].mean())/2/64)
    rgb=np.full((*ref.shape,3),25,np.uint8)
    rgb[ref]=[40,200,240];rgb[m]=[255,160,40];rgb[ref&m]=[235,235,235]
    return dict(score=score,angle=angle,contour_distance=distance,overlay=png(rgb))


def suggest(project,reference,target,threshold=.5):
    from .layers import active
    if reference==target:raise ValueError('기준 이미지와 대상 이미지는 달라야 합니다.')
    if not np.isfinite(threshold) or not 0<=threshold<=1:raise ValueError('최소 IoU는 0~1입니다.')
    project.require_image(reference);project.require_image(target)
    refs=[c for c in active(project,reference) if c.get('reviewed') and c.get('layer_id') is not None]
    if not refs:raise ValueError('기준 이미지에서 마스크를 레이어에 배정하고 검수 확정하세요.')
    targets=[c for c in active(project,target) if c.get('layer_id') is None]
    # Explicit bound rather than silent candidate truncation or unbounded server work.
    if len(refs)*len(targets)>10000:raise ValueError('비교 쌍이 10,000개를 넘습니다. 불필요한 후보를 정리하거나 기준 마스크 수를 줄이세요.')
    prepared=[]
    for c in targets:
        mask=project.mask(target,c['id'])
        if mask.any():prepared.append((c,*canonical(mask)))
    layers={l['id']:l for l in project.state['layers']};rows=[]
    for rc in refs:
        r,rs=canonical(project.mask(reference,rc['id'])); ranked=[]
        for c,m,ms in prepared:
            item=compare(r,m)
            item.update(candidate_id=c['id'],area_ratio=ms['area']/rs['area'],scale_to_reference=rs['longest']/ms['longest'],below_threshold=item['score']<threshold)
            ranked.append(item)
        ranked.sort(key=lambda v:(-v['score'],v['contour_distance'],v['candidate_id']))
        layer=layers[rc['layer_id']]
        used=next((c['id'] for c in active(project,target) if c.get('layer_id') is not None and c.get('template_match',{}).get('reference_image')==reference and c.get('template_match',{}).get('reference_candidate_id')==rc['id']),None)
        rows.append(dict(reference_candidate_id=rc['id'],layer_id=rc['layer_id'],layer_name=layer['name'],locked=project.locked(rc['layer_id']),assigned_candidate_id=used,reference_preview=png(np.repeat((r*255).astype('uint8')[...,None],3,axis=2)),candidates=ranked[:3]))
    return dict(reference_image=reference,image_id=target,signature=stamp(project,reference,target),threshold=threshold,proposals=rows,method='mask template IoU; uniform longest-side normalization; rotation -30..30 step 5 degrees; top 3; manual assignment only')


def accept(project,body):
    from .layers import active
    ref=body['reference_image'];target=body['image_id']
    if ref==target:raise ValueError('기준 이미지와 대상 이미지는 달라야 합니다.')
    if body.get('signature')!=stamp(project,ref,target):raise ValueError('마스크 또는 설정이 변경되었습니다. 후보를 다시 검색하세요.')
    refs={c['id']:c for c in active(project,ref)};targets={c['id']:c for c in active(project,target)}
    rc=refs.get(body.get('reference_candidate_id'));c=targets.get(body.get('candidate_id'))
    if not rc or not rc.get('reviewed') or rc.get('layer_id') is None:raise ValueError('검수된 기준 마스크가 필요합니다.')
    if not c or c.get('layer_id') is not None:raise ValueError('사용 중이거나 사용할 수 없는 후보입니다.')
    if project.locked(rc['layer_id']):raise ValueError('대상 레이어가 잠겨 있습니다.')
    if any(x.get('template_match',{}).get('reference_image')==ref and x.get('template_match',{}).get('reference_candidate_id')==rc['id'] and x.get('layer_id') is not None for x in targets.values()):
        raise ValueError('이 기준 마스크에 이미 배정한 후보가 있습니다. 기존 배정을 해제하세요.')
    result=suggest(project,ref,target,float(body.get('threshold',.5)))
    row=next(v for v in result['proposals'] if v['reference_candidate_id']==rc['id'])
    chosen=next((v for v in row['candidates'] if v['candidate_id']==c['id']),None)
    if chosen is None:raise ValueError('현재 상위 3개 후보에서 선택하세요.')
    if chosen['below_threshold'] and body.get('allow_low_score') is not True:raise ValueError('낮은 IoU 후보는 별도 확인이 필요합니다.')
    c.update(layer_id=rc['layer_id'],reviewed=False,template_match=dict(reference_image=ref,reference_candidate_id=rc['id'],score=chosen['score'],method=result['method']))
    return dict(candidate_id=c['id'],layer_id=c['layer_id'],reviewed=False)
