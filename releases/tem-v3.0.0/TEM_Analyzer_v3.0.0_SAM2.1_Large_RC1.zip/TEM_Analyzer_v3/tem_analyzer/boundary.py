"""Closed contour normal-gradient refinement in original pixel coordinates."""
import numpy as np
from scipy import ndimage as ndi
from matplotlib.path import Path
from .geometry import mask_contours, resample, gray
from .preprocessing import filtered as filter_image
def sanitized(rgb,valid):
    a=rgb.copy()
    if not valid.any():raise ValueError("유효 영역이 없습니다.")
    ix=ndi.distance_transform_edt(~valid,return_distances=False,return_indices=True);a[~valid]=a[ix[0][~valid],ix[1][~valid]]
    return a

DEFAULTS=dict(inside=25,outside=25,polarity='both',smooth=.18,distance=.15,jump=4,weak=.12)

def crossing(p):
    # Non-adjacent contacts and collinear overlap are invalid too, not only Xs.
    a=np.asarray(p,float)
    if len(a)>1 and np.allclose(a[0],a[-1],rtol=0,atol=1e-9):a=a[:-1]
    if len(a)<3 or not np.isfinite(a).all():return True
    b=np.roll(a,-1,axis=0);v=b-a
    if np.any(np.linalg.norm(v,axis=1)<1e-9):return True
    lo=np.minimum(a,b);hi=np.maximum(a,b);eps=1e-9
    cross=lambda x,y:x[...,0]*y[...,1]-x[...,1]*y[...,0]
    for i in range(len(a)-2):
        ids=np.arange(i+2,len(a));ids=ids[ids!=len(a)-1] if i==0 else ids
        ids=ids[np.all((lo[ids]<=hi[i]+eps)&(hi[ids]>=lo[i]-eps),axis=1)]
        if not len(ids):continue
        q=a[ids]-a[i];den=cross(v[i],v[ids]);ok=abs(den)>1e-9
        t=np.zeros(len(ids));u=t.copy();t[ok]=cross(q[ok],v[ids][ok])/den[ok];u[ok]=cross(q[ok],v[i])/den[ok]
        if np.any(ok&(t>=-eps)&(t<=1+eps)&(u>=-eps)&(u<=1+eps)):return True
        if np.any(~ok&(abs(cross(q,v[i]))<=eps)):return True
    return False

def topology(mask):
    return (ndi.label(mask)[1],ndi.label(ndi.binary_fill_holes(mask)&~mask)[1])

def raster(loops,shape):
    """Sample polygons at integer pixel centres (contours lie at half pixels)."""
    out=np.zeros(shape,bool)
    for line in loops:
        p=np.asarray(line,float)
        if len(p)<3:continue
        lo=np.maximum(np.floor(p.min(0)).astype(int),0)
        hi=np.minimum(np.ceil(p.max(0)).astype(int)+1,[shape[1],shape[0]])
        polygon=Path(np.vstack([p,p[0]]))
        for y0 in range(lo[1],hi[1],64):
            y1=min(y0+64,hi[1]);yy,xx=np.mgrid[y0:y1,lo[0]:hi[0]]
            hit=polygon.contains_points(np.c_[xx.ravel(),yy.ravel()]).reshape(yy.shape)
            out[y0:y1,lo[0]:hi[0]]^=hit
    return out

def displaced_contour(contour,displacement):
    """Interpolate sampled movement back onto the original detailed contour."""
    length=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(contour,axis=0),axis=1))]
    steps=np.linspace(0,length[-1],len(displacement)+1)
    delta=np.vstack([displacement,displacement[0]])
    return contour+np.c_[np.interp(length,steps,delta[:,0]),np.interp(length,steps,delta[:,1])]

def cyclic_path(cost,jump,smooth):
    N,K=cost.shape
    # Restricted start-state search; each candidate path includes the closing seam penalty.
    seam=int(np.argmax(np.partition(np.where(np.isfinite(cost),cost,1e5),min(1,K-1),axis=1)[:,min(1,K-1)]-np.min(cost,axis=1)))
    c=np.roll(cost,-seam,axis=0);starts=np.argsort(c[0])[:min(5,K)];best=None
    dest=np.arange(K)
    for start in starts:
        if not np.isfinite(c[0,start]):continue
        prev=np.full(K,np.inf);prev[start]=c[0,start];parent=np.zeros((N,K),np.int16)
        for i in range(1,N):
            choices=np.full((2*jump+1,K),np.inf)
            for j,delta in enumerate(range(-jump,jump+1)):
                src=dest+delta;ok=(src>=0)&(src<K);choices[j,ok]=prev[src[ok]]+smooth*abs(delta)
            ix=np.argmin(choices,axis=0);prev=c[i]+choices[ix,dest];parent[i]=dest+ix-jump
        prev+=smooth*abs(dest-start);prev[abs(dest-start)>jump]=np.inf
        if not np.isfinite(prev).any():continue
        end=int(np.argmin(prev));score=float(prev[end])
        if best is None or score<best[0]:
            path=np.empty(N,int);path[-1]=end
            for i in range(N-1,0,-1):path[i-1]=parent[i,path[i]]
            best=(score,np.roll(path,seam))
    return None if best is None else best[1]

def refine_all(rgb,mask,valid,settings=None,filter_cfg=None,overrides=None,pins=None,*,search_domain=None,max_step=None):
    if (settings or {}).get('iterations',1)!=1:
        from .boundary_iterative import refine_iterative
        return refine_iterative(rgb,mask,valid,settings,filter_cfg,overrides,pins)
    cfg=DEFAULTS|dict(settings or {})
    for key in ('inside','outside'):
        if not np.isfinite(cfg[key]) or not 0<=cfg[key]<=200:raise ValueError('탐색 폭은 안쪽/바깥쪽 각각 0~200 px입니다.')
    if cfg['inside']+cfg['outside']<2:raise ValueError('탐색 폭 합계는 2 px 이상이어야 합니다.')
    if not 1<=int(cfg['jump'])<=20 or not 0<=cfg['smooth']<=10 or not 0<=cfg['distance']<=10 or not 0<=cfg['weak']<=1:raise ValueError('연속성 설정 범위 오류')
    if cfg['polarity'] not in ('both','positive','negative'):raise ValueError('극성 오류')
    corner_mode=cfg.get('corner_mode','freeze')
    if corner_mode not in ('freeze','guarded'):raise ValueError('모서리 처리 방식 오류')
    from .preprocessing import filter_support
    guard=3+filter_support(filter_cfg)
    safe=ndi.binary_erosion(valid,iterations=guard,border_value=0)
    f=gray(filter_image(sanitized(rgb,valid),filter_cfg));gy,gx=np.gradient(f)
    signed=ndi.distance_transform_edt(mask)-ndi.distance_transform_edt(~mask)
    contours=mask_contours(mask);loops=[];output_contours=[];small_guard=np.zeros(mask.shape,bool)
    for loop_index,contour in enumerate(contours):
        # Isolated pixels/tiny holes are valid mask data, but cannot support a
        # stable normal. Preserve them and keep loop indices usable by the UI.
        if np.linalg.norm(np.diff(contour,axis=0),axis=1).sum()<4:
            p=np.asarray(contour[:-1],float);N=len(p)
            small_guard|=ndi.binary_dilation(raster([p],mask.shape),iterations=1)
            loops.append(dict(initial=p.tolist(),peak=p.tolist(),refined=p.tolist(),normal=np.zeros_like(p).tolist(),offset_px=[0.]*N,offset_grid=[0.],response=[[0.] for _ in range(N)],uncertain=[True]*N,quality=dict(flags=['4 px 미만의 작은 경계: 원본 보존, 보정 제외'],uncertain_fraction=1.,median_shift_px=0.)))
            output_contours.append(contour)
            continue
        p=resample(contour,2.)[:-1];N=len(p)
        sm=ndi.gaussian_filter1d(p,1.3,axis=0,mode='wrap');t=np.roll(sm,-1,axis=0)-np.roll(sm,1,axis=0);t/=np.maximum(np.linalg.norm(t,axis=1)[:,None],1e-9);n=np.c_[-t[:,1],t[:,0]]
        sample=lambda field,xy,order=1:ndi.map_coordinates(field,[xy[...,1],xy[...,0]],order=order,mode='constant',cval=0)
        orient=sample(signed,p+n*2)-sample(signed,p-n*2);n[orient>0]*=-1
        inside=np.full(N,cfg['inside'],float);outside=np.full(N,cfg['outside'],float);polar=np.full(N,cfg['polarity'],object)
        for override in overrides or []:
            if int(override['loop'])!=loop_index:continue
            ids=[int(np.argmin(np.linalg.norm(p-np.array(ep),axis=1))) for ep in override['endpoints']];a,b=sorted(ids);sel=np.zeros(N,bool);sel[a:b+1]=True
            if b-a>N/2:sel=~sel;sel[ids]=True
            for key,arr in [('inside',inside),('outside',outside)]:
                value=float(override.get(key,cfg[key]));
                if not 0<=value<=200:raise ValueError('부분 탐색 폭은 0~200 px입니다.')
                arr[sel]=value
            pol=override.get('polarity',cfg['polarity'])
            if pol not in ('both','positive','negative'):raise ValueError('부분 극성 오류')
            polar[sel]=pol
        d=np.arange(-int(np.ceil(inside.max())),int(np.ceil(outside.max()))+1,dtype=float);zero=int(np.argmin(abs(d)))
        xy=p[:,None,:]+n[:,None,:]*d[None,:,None];allowed=sample(safe.astype(float),xy,0)>.5
        allowed&=(d[None,:]>=-inside[:,None])&(d[None,:]<=outside[:,None])
        if search_domain is not None:allowed&=sample(search_domain.astype(float),xy,0)>.5
        if corner_mode=='guarded' or search_domain is not None:
            # Do not jump across invalid/excluded samples to a remote valid edge.
            allowed[:,zero:]=np.logical_and.accumulate(allowed[:,zero:],axis=1)
            allowed[:,:zero+1]=np.logical_and.accumulate(allowed[:,:zero+1][:,::-1],axis=1)[:,::-1]
        grad=sample(gx,xy)*n[:,0,None]+sample(gy,xy)*n[:,1,None]
        response=np.abs(grad);response[polar=='positive']=np.maximum(grad[polar=='positive'],0);response[polar=='negative']=np.maximum(-grad[polar=='negative'],0)
        scale=float(np.percentile(response[allowed],95)) if allowed.any() else 0
        strength=np.clip(response/max(scale,1e-7),0,3);best=np.max(np.where(allowed,strength,0),axis=1)
        corner=np.sum(np.roll(t,3,axis=0)*np.roll(t,-3,axis=0),axis=1)<.45
        frozen=(sample(safe.astype(float),p,0)<.5)|(corner if corner_mode=='freeze' else False)|(best<cfg['weak'])|(scale<1e-7)
        cost=-strength+cfg['distance']*abs(d)[None,:]/max(abs(d).max(),1);cost[~allowed]=np.inf
        cost[frozen]=np.inf;cost[frozen,zero]=0
        for pin in pins or []:
            if int(pin['loop'])!=loop_index:continue
            q=np.asarray(pin['point'],float);i=int(np.argmin(np.linalg.norm(p-q,axis=1)));delta=float((q-p[i])@n[i]);k=int(np.argmin(abs(d-delta)))
            if frozen[i] or not allowed[i,k] or abs(delta-d[k])>1:raise ValueError('고정점이 유효 탐색 범위를 벗어납니다.')
            cost[i,abs(np.arange(len(d))-k)>1]=np.inf
        peak_path=np.argmin(cost,axis=1);peak=p+n*d[peak_path,None]
        path=cyclic_path(cost,int(cfg['jump']),float(cfg['smooth']));flags=[]
        if path is None:path=np.full(N,zero);frozen[:]=True;flags.append('연속 폐곡선 경로 실패: 원래 경계 유지')
        chosen=strength[np.arange(N),path];hit=(path==0)|(path==len(d)-1)
        uncertain=frozen|(chosen<cfg['weak'])|hit
        # Re-solve with uncertain points fixed; do not introduce discontinuities after path selection.
        newfreeze=uncertain&~frozen
        if newfreeze.any():
            cost[newfreeze]=np.inf;cost[newfreeze,zero]=0
            second=cyclic_path(cost,int(cfg['jump']),float(cfg['smooth']))
            if second is None:
                path=np.full(N,zero);uncertain[:]=True;flags.append('불확실 지점 고정 후 경로 실패: 원래 경계 유지')
            else:path=second
        offset=d[path].copy();refined=p+n*offset[:,None]
        if max_step is not None:
            offset=np.clip(offset,-max_step,max_step);refined=p+n*offset[:,None]
        # Experimental opt-in: retain both coarse and detailed intersection guards.
        # Shorten the proposed displacement rather than accepting a crossed loop.
        if corner_mode=='guarded' and not pins and np.any(offset):
            proposed=offset.copy()
            for factor in (1.,.5,.25,.125,0.):
                trial=p+n*(proposed*factor)[:,None]
                detail=displaced_contour(contour,trial-p)
                if factor==0 or (not crossing(trial) and not crossing(detail[:-1])):
                    offset=proposed*factor;refined=trial
                    if factor<1:
                        uncertain[:]=True;flags.append(f'교차 방지 부분 이동 {factor:g}배: 목표 경계 도달 미확정')
                    break
        if crossing(refined):refined=p.copy();offset[:]=0;uncertain[:]=True;flags.append('자기 교차 발생: 이 경계 보정 취소')
        detailed=displaced_contour(contour,refined-p)
        if np.any(offset) and crossing(detailed[:-1]):
            detailed=contour.copy();refined=p.copy();offset[:]=0;uncertain[:]=True;flags.append('상세 경계 자기 교차: 이 경계 보정 취소')
        output_contours.append(detailed)
        if hit.mean()>.05:flags.append('탐색 폭 끝 도달 >5%: 폭/극성 확인')
        if uncertain.mean()>.2:flags.append('불확실/미보정 지점 >20%')
        loops.append(dict(initial=p.tolist(),peak=peak.tolist(),refined=refined.tolist(),normal=n.tolist(),offset_px=offset.tolist(),offset_grid=d.tolist(),response=strength.tolist(),uncertain=uncertain.tolist(),quality=dict(flags=flags,uncertain_fraction=float(uncertain.mean()),median_shift_px=float(np.median(abs(offset))))))
    original_raster=raster(contours,mask.shape)
    corrected=raster(output_contours,mask.shape)
    corrected[~valid]=mask[~valid]
    corrected[small_guard]=mask[small_guard]
    if search_domain is not None:corrected[~search_domain]=mask[~search_domain]
    # A cancelled/no-motion operation is an exact no-op, not a contour round trip.
    # Half-pixel polygon fill conventions otherwise change the original mask.
    if all(not np.any(e['offset_px']) for e in loops):
        corrected=mask.copy()
    # The original contour round trip must preserve topology, as must the result.
    if topology(corrected)!=topology(mask) or topology(original_raster)!=topology(mask):
        for e in loops:e['refined']=e['initial'];e['offset_px']=[0.]*len(e['initial']);e['uncertain']=[True]*len(e['initial']);e['quality']['uncertain_fraction']=1.;e['quality']['median_shift_px']=0.;e['quality']['flags'].append('연결 구조 변화: 전체 보정 취소')
        corrected=mask.copy()
    return dict(loops=loops,mask=corrected,settings=cfg,filter=dict(filter_cfg or {}))
