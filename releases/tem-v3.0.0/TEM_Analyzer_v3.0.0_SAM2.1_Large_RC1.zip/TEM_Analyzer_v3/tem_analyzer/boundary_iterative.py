"""Opt-in iterative normals with an immutable initial-mask pixel search band.

The band is a signed EDT pixel domain, not pointwise normal tubes. Each pass
re-extracts normals. Cross-loop trajectories are not continuously certified.
"""
import numpy as np
from scipy import ndimage as ndi


def initial_band(mask,inside,outside):
    # Pixel centres adjacent to the half-pixel boundary are 0.5px away.
    a=ndi.distance_transform_edt(mask)-.5
    b=ndi.distance_transform_edt(~mask)-.5
    return np.where(mask,a<=inside,b<=outside)


def refine_iterative(rgb,mask,valid,settings,filter_cfg=None,overrides=None,pins=None):
    from .boundary import refine_all,DEFAULTS,topology
    cfg=DEFAULTS|dict(settings or {})
    count=cfg.get('iterations',1);step=cfg.get('step_px',1.)
    if type(count) is not int or not 2<=count<=40:raise ValueError('반복 횟수는 2~40 정수입니다.')
    if not np.isfinite(step) or not .25<=step<=2:raise ValueError('단계 이동은 0.25~2 px입니다.')
    if overrides or pins:raise ValueError('반복 보정은 부분 설정/고정점을 아직 지원하지 않습니다. 지우거나 단회 보정을 선택하세요.')
    for k in ('inside','outside'):
        if not np.isfinite(cfg[k]) or not 0<=cfg[k]<=200:raise ValueError('최초 탐색 폭은 0~200 px입니다.')
    band=initial_band(mask,cfg['inside'],cfg['outside'])&valid
    sigma=cfg.get('initial_smoothing_sigma',0.)
    if not np.isfinite(sigma) or not 0<=sigma<=2:raise ValueError('초기 평활화 sigma는 0~2 px입니다.')
    current=mask.copy();smoothing=dict(sigma=float(sigma),changed_pixels=0,rejected=False)
    if sigma:
        proposed=ndi.gaussian_filter(mask.astype(float),sigma)>=.5
        allowed=band&initial_band(mask,1.5,1.5)
        proposed[~allowed]=mask[~allowed]
        if topology(proposed)==topology(mask):current=proposed
        else:smoothing['rejected']=True
        smoothing['changed_pixels']=int(np.count_nonzero(current!=mask))
    history=[];seen={current.tobytes()};reason='max_iterations'
    one=dict(cfg,iterations=1);result=None
    for iteration in range(count):
        result=refine_all(rgb,current,valid,one,filter_cfg,search_domain=band,max_step=float(step))
        proposed=result['mask'];changed=int(np.count_nonzero(proposed!=current))
        if np.any((proposed!=mask)&~band) or topology(proposed)!=topology(mask):
            reason='safety_rejected';break
        history.append(dict(iteration=iteration+1,changed_pixels=changed,
                            max_normal_step_px=max((max(abs(np.asarray(l['offset_px'])),default=0.) for l in result['loops']),default=0.),
                            flags=[f for l in result['loops'] for f in l['quality']['flags']]))
        if not changed:reason='pixel_converged_or_guarded';break
        key=proposed.tobytes()
        if key in seen:reason='cycle_rejected';break
        seen.add(key);current=proposed.copy()
    result['mask']=current;result['settings']=cfg
    if reason in ('safety_rejected','cycle_rejected'):
        for loop in result['loops']:
            loop['refined']=loop['initial'];loop['offset_px']=[0.]*len(loop['initial'])
            loop['uncertain']=[True]*len(loop['initial'])
            loop['quality'].update(uncertain_fraction=1.,median_shift_px=0.)
            loop['quality']['flags'].append('반복 제안 거부: 마지막 승인 마스크 유지')
    result['iteration_report']=dict(initial_smoothing=smoothing,history=history,stop_reason=reason,accepted_iterations=sum(h['changed_pixels']>0 for h in history)-(1 if reason=='cycle_rejected' else 0),
        band_definition='immutable initial-mask signed EDT pixel domain; distance EDT-0.5; normal samples and changed pixels restricted',
        changed_pixels=int(np.count_nonzero(current!=mask)),outside_band_changes=int(np.count_nonzero((current!=mask)&~band)),
        note='Loops describe final attempted local pass, not accumulated displacement. Pixel rasterization quantizes small moves; stationary can mean guard rejection, not correct edge. No continuous cross-loop trajectory guarantee.')
    return result
