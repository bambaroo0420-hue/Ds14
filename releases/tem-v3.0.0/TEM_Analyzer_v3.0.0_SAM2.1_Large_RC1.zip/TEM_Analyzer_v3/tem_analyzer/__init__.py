"""Local TEM segmentation workbench."""

