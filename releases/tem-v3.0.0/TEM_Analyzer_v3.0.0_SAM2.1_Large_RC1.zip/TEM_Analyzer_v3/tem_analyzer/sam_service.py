"""SAM 2.1 Hiera Large adapter; retains the v2 prompt/ROI/result contract."""
from pathlib import Path
import hashlib,sys,json
import numpy as np

ENGINE = 'sam2.1_hiera_large'
CONFIG = 'configs/sam2.1/sam2.1_hiera_l.yaml'
VENDOR = Path(__file__).resolve().parents[1] / 'vendor'
if str(VENDOR) not in sys.path:
    sys.path.insert(0, str(VENDOR))

def file_hash(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def image_hash(image):return hashlib.sha256(str(image.shape).encode()+image.tobytes()).hexdigest()

class ModelService:
    def __init__(self):self.model=None;self.predictor=None;self.refiner=None;self.info=None;self.image_key=None;self.refiner_kind=None;self.cfg={}
    def load(self,checkpoint,variant=ENGINE,device='auto',decoder_path=None,refiner_path=None,adaptation_path=None):
        if variant != ENGINE:
            raise ValueError('v3는 SAM 2.1 Hiera Large 전용입니다. sam2.1_hiera_large를 선택하세요.')
        if decoder_path or refiner_path or adaptation_path:
            raise ValueError('SAM1 decoder/refiner/ABL 가중치는 SAM 2.1과 호환되지 않습니다.')
        checkpoint=Path(checkpoint).expanduser().resolve()
        if not checkpoint.is_file():raise ValueError('SAM 2.1 Large 체크포인트 경로를 확인하세요.')
        try:
            import torch
            from sam2.build_sam import build_sam2
            from sam2.sam2_image_predictor import SAM2ImagePredictor
        except ImportError as exc:
            raise ImportError('SAM 2.1 설치가 필요합니다. README_KO.md의 설치 절차를 확인하세요: '+str(exc)) from exc
        device=('cuda' if torch.cuda.is_available() else 'cpu') if device=='auto' else device
        if device not in ('cuda','cpu'):raise ValueError('장치는 auto/cpu/cuda입니다.')
        if device=='cuda' and not torch.cuda.is_available():raise ValueError('CUDA를 사용할 수 없습니다.')
        # Construct locally; a failed load must not invalidate the previous model.
        # mmap avoids an additional ~900 MB checkpoint copy on CPU. Strict loading
        # still rejects SAM1, Tiny/Small/Base+, and structurally incompatible weights.
        model=build_sam2(CONFIG,None,device='cpu',apply_postprocessing=False)
        state=torch.load(str(checkpoint),map_location='cpu',weights_only=True,mmap=True)
        if not isinstance(state,dict) or 'model' not in state:
            raise ValueError('SAM 2.1 Large 공식 checkpoint의 model state가 필요합니다.')
        model.load_state_dict(state['model'],strict=True,assign=True)
        model=model.to(device).eval()
        predictor=SAM2ImagePredictor(model, max_hole_area=0, max_sprinkle_area=0)
        info=dict(engine=ENGINE,variant=ENGINE,config=CONFIG,device=device,
                  checkpoint=str(checkpoint),checkpoint_sha256=file_hash(checkpoint),
                  decoder_path=None,adaptation_path=None,adaptation_sha256=None,
                  refiner=None,single_mask=False,adapted=False,score_calibrated=None)
        self.model=model;self.predictor=predictor;self.info=info;self.image_key=None
        self.refiner=None;self.refiner_kind=None;self.cfg={}
        return info
    def context(self,image):
        return dict(engine=ENGINE,image_sha256=image_hash(image),model_sha256=self.info.get('checkpoint_sha256'),adaptation_sha256=self.info.get('adaptation_sha256'),shape=list(image.shape))
    def _set_image(self,image):
        digest=image_hash(image);cached=digest==self.image_key
        if not cached:self.predictor.set_image(np.ascontiguousarray(image).copy());self.image_key=digest
        return cached
    def prompt(self,image,points=None,box=None,prior=None,mask_choice=-1):
        if self.model is None:raise ValueError('먼저 SAM 모델을 로드하세요.')
        import torch
        import torch.nn.functional as F
        h,w=image.shape[:2];points=points or [];prior=prior or {};seed=None;origin='none'
        if type(mask_choice) is not int or mask_choice not in (-1,0,1,2):raise ValueError('SAM 후보 선택은 자동(-1) 또는 0/1/2입니다.')
        if any(len(p)!=3 or not np.isfinite(p).all() or p[2] not in (0,1) or not(0<=p[0]<w and 0<=p[1]<h) for p in points):raise ValueError('점 좌표/라벨 오류')
        if box is not None and (len(box)!=4 or not np.isfinite(box).all() or not(0<=box[0]<box[2]<=w and 0<=box[1]<box[3]<=h)):raise ValueError('box 좌표 오류')
        cached=self._set_image(image);ctx=self.context(image)
        if prior.get('context')==ctx and isinstance(prior.get('logits'),np.ndarray) and prior['logits'].shape==(1,256,256):seed=prior['logits'];origin='sam_logits'
        elif prior.get('mask') is not None:
            m=np.asarray(prior['mask'],np.float32)
            if m.shape!=(h,w):raise ValueError('이전 mask 크기 불일치')
            # SAM2 square-resizes the whole image; SAM1 longest-side padding is incorrect here.
            x=torch.from_numpy(m)[None,None]*8-4
            seed=F.interpolate(x,size=(256,256),mode='bilinear',align_corners=False)[0].numpy();origin='binary_mask_seed'
        if not points and box is None and seed is None:raise ValueError('점 또는 box가 필요합니다.')
        xy=np.asarray([p[:2] for p in points],np.float32) if points else None;labels=np.asarray([p[2] for p in points],np.int32) if points else None
        with torch.inference_mode():
            full,scores,low=self.predictor.predict(point_coords=xy,point_labels=labels,box=np.asarray(box,np.float32) if box else None,mask_input=seed,multimask_output=not bool(self.info.get('single_mask') or seed is not None),return_logits=True)
            if mask_choice>=len(scores):raise ValueError('이 SAM 경로는 해당 후보 번호를 지원하지 않습니다. 학습/이전 mask 입력 경로는 단일 후보입니다.')
            i=int(np.argmax(scores)) if mask_choice<0 else mask_choice;native=low[i:i+1].copy();z=full[i]
            if self.refiner is not None:
                scale=min(1.,self.cfg['refine_side']/max(h,w));size=(max(8,round(h*scale)),max(8,round(w*scale)))
                rgb=torch.as_tensor(image.copy(),device=self.info['device']).permute(2,0,1)[None].float()/255
                logits=torch.as_tensor(z.copy(),device=self.info['device'])[None,None]
                rgb=F.interpolate(rgb,size=size,mode='bilinear',align_corners=False);logits=F.interpolate(logits,size=size,mode='bilinear',align_corners=False)
                z=F.interpolate(self.refiner(rgb,logits),size=(h,w),mode='bilinear',align_corners=False)[0,0].cpu().numpy()
        prob=1/(1+np.exp(-np.clip(z,-50,50)));threshold=self.cfg.get('mask_threshold',.5)
        violations=[index for index,(x,y,label) in enumerate(points) if bool(prob[min(h-1,int(np.floor(y+.5))),min(w-1,int(np.floor(x+.5)))]>=threshold)!=bool(label)]
        return dict(mask=prob>=threshold,score=float(scores[i]),logits=native,context=ctx,prior_source=origin,embedding_reused=cached,probability=prob,
                    mask_choice=i,multimask_scores=[float(s) for s in scores],prompt_violations=violations)
    def in_roi(self,image,roi,points=None,box=None,prior=None,mask_choice=-1,align_positive=False,box_margin=0):
        if len(roi)!=4 or not np.isfinite(roi).all():raise ValueError('ROI 오류')
        if any(float(v)!=int(v) for v in roi):raise ValueError('추론 ROI는 정수 픽셀 경계로 지정하세요.')
        x0,y0,x1,y1=map(int,roi);h,w=image.shape[:2]
        if not(0<=x0<x1<=w and 0<=y0<y1<=h):raise ValueError('ROI 오류')
        if any(len(p)!=3 or not(x0<=p[0]<x1 and y0<=p[1]<y1) for p in (points or [])):raise ValueError('모든 점은 ROI 안에 있어야 합니다.')
        if box is not None and (len(box)!=4 or not np.isfinite(box).all() or not(x0<=box[0]<box[2]<=x1 and y0<=box[1]<box[3]<=y1)):raise ValueError('box는 ROI 안에 있어야 합니다.')
        local=[[p[0]-x0,p[1]-y0,p[2]] for p in (points or [])];lb=[box[0]-x0,box[1]-y0,box[2]-x0,box[3]-y0] if box else None
        if type(align_positive) is not bool or not np.isfinite(box_margin) or not 0<=box_margin<=200:raise ValueError('사전정렬 설정 오류')
        if box_margin and not align_positive:raise ValueError('자동 좁은 box는 사전정렬 옵션과 함께 사용하세요.')
        if align_positive:
            if prior:raise ValueError('이전 마스크 seed의 사전정렬은 지원하지 않습니다. 독립 ROI를 사용하세요.')
            from .algorithms.roi_alignment import prepare,restore
            rgb,pp,bb,support,meta=prepare(image[y0:y1,x0:x1],local,lb,box_margin)
            item=self.prompt(rgb,pp,bb,mask_choice=mask_choice)
            prob=restore(item['probability'],support,meta,(y1-y0,x1-x0));threshold=self.cfg.get('mask_threshold',.5)
            full=np.zeros((h,w),bool);full[y0:y1,x0:x1]=prob>=threshold;item['mask']=full
            meta['original_roi']=[x0,y0,x1,y1];item['roi_alignment']=meta;item['inference_domains']=[[x0,y0,x1,y1]]
            item['prompt_violations']=[k for k,(x,y,label) in enumerate(points or []) if bool(full[min(h-1,int(np.floor(y+.5))),min(w-1,int(np.floor(x+.5)))])!=bool(label)]
            item.pop('logits',None);item.pop('context',None);item.pop('probability',None);return item
        pr=None
        if prior and prior.get('mask') is not None:pr={'mask':prior['mask'][y0:y1,x0:x1]}
        kwargs={'mask_choice':mask_choice} if mask_choice!=-1 else {}
        item=self.prompt(image[y0:y1,x0:x1],local,lb,pr,**kwargs) if pr else self.prompt(image[y0:y1,x0:x1],local,lb,**kwargs)
        full=np.zeros((h,w),bool);full[y0:y1,x0:x1]=item['mask'];item['mask']=full;item['inference_domains']=[[x0,y0,x1,y1]]
        item.pop('logits',None);item.pop('context',None);item.pop('probability',None);return item
    def automatic(self,image,grid=16,pred_iou=.90,stability=.92,nms=.8,exclude=None,prepared_points=None):
        if self.model is None:raise ValueError('먼저 SAM 모델을 로드하세요.')
        from .prompts import grid_points,validate_points
        if exclude is None:exclude=np.zeros(image.shape[:2],bool)
        points=validate_points(prepared_points,image.shape[1],image.shape[0]) if prepared_points is not None else grid_points(image.shape[:2],grid,exclude)
        points=[p for p in points if not exclude[int(p[1]),int(p[0])]]
        if not points:return []
        if self.info.get('single_mask'):
            # Same single-mask output path used for training; IoU head is uncalibrated.
            kept=[];delta=self.cfg.get('stability_delta',.05);threshold=self.cfg.get('mask_threshold',.5)
            for p in points:
                x=self.prompt(image,[p+[1]]);prob=x.pop('probability');mask=x['mask'];s=float((prob>=min(1,threshold+delta)).sum()/max(1,(prob>=max(0,threshold-delta)).sum()))
                if not mask.any() or s<stability or (not self.info.get('adapted') and x['score']<pred_iou):continue
                x.update(stability=s,bbox=[],point=[p]);kept.append(x)
            kept.sort(key=lambda x:x['stability'] if self.info.get('adapted') else x['score'],reverse=True)
            selected=[]
            for x in kept:
                mask=x['mask']
                if any((mask&k['mask']).sum()/max(1,(mask|k['mask']).sum())>nms for k in selected):continue
                selected.append(x)
            return selected
        import torch
        from sam2.automatic_mask_generator import SAM2AutomaticMaskGenerator
        pts=np.asarray(points,np.float32)/[image.shape[1],image.shape[0]]
        # AMG owns a separate predictor. Release the interactive embedding cache
        # before encoding again, particularly important for Large on CPU.
        self.predictor.reset_predictor();self.image_key=None
        gen=SAM2AutomaticMaskGenerator(self.model,points_per_side=None,point_grids=[pts],points_per_batch=1 if self.info['device']=='cpu' else 8,crop_n_layers=0,pred_iou_thresh=pred_iou,stability_score_thresh=stability,box_nms_thresh=nms,min_mask_region_area=0)
        with torch.inference_mode():items=gen.generate(image)
        return [dict(mask=x['segmentation'],score=float(x['predicted_iou']),stability=float(x['stability_score']),bbox=x['bbox'],point=x.get('point_coords')) for x in items]
