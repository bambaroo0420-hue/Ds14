@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Virtual environment missing. Run install_windows.bat once.
  pause
  exit /b 1
)
echo TEM Analyzer v3.0.0 SAM 2.1 Large - no automatic downloads.
echo Default address: http://127.0.0.1:8766
".venv\Scripts\python.exe" -X utf8 run.py --port 8766 %*
pause

