/* Independent ROI prompt editor. All stored coordinates are original image pixels. */
class ROIEditor {
 constructor({api,onSaved}) {
  this.api=api;this.onSaved=onSaved;this.busy=false;this.preview=null;this.previewOverlay=null;
  this.el=id=>document.getElementById(id);this.dialog=this.el('roiDialog');
  this.canvas=this.el('roiCanvas');this.ctx=this.canvas.getContext('2d');this.host=this.el('roiHost');
  this.el('roiClose').onclick=()=>{if(!this.busy){this.discard();this.dialog.close()}};
  this.dialog.addEventListener('cancel',e=>{if(this.busy)e.preventDefault();else this.discard()});
  this.el('roiClear').onclick=()=>{if(this.busy)return;this.points=[];this.box=null;this.draw()};
  this.el('roiReset').onclick=()=>this.fit();
  this.el('roiShowPoints').onchange=()=>this.draw();this.el('roiShowMask').onchange=()=>this.draw();
  this.el('roiMaskChoice').onchange=()=>this.draw();
  this.el('roiAlignPositive').onchange=()=>this.draw();this.el('roiBoxMargin').oninput=()=>this.draw();
  this.el('roiRun').onclick=()=>this.run();this.el('roiAccept').onclick=()=>this.accept();this.el('roiDiscard').onclick=()=>{if(!this.busy){this.discard();this.draw()}};this.el('roiShowPreview').onchange=()=>this.draw();
  this.canvas.addEventListener('pointerdown',e=>this.down(e));
  this.canvas.addEventListener('pointermove',e=>this.move(e));
  this.canvas.addEventListener('pointerup',e=>this.up(e));
  this.canvas.addEventListener('pointercancel',()=>{this.drag=null;this.draw()});
  this.canvas.addEventListener('contextmenu',e=>{e.preventDefault();if(this.busy)return;const p=this.coord(e);let best=-1,d=12/this.scale;this.points.forEach((q,i)=>{const v=Math.hypot(q[0]-p[0],q[1]-p[1]);if(v<d){d=v;best=i}});if(best>=0)this.points.splice(best,1);this.draw()});
  this.canvas.addEventListener('wheel',e=>{e.preventDefault();if(this.busy)return;const p=this.coord(e),r=this.canvas.getBoundingClientRect();this.scale=Math.max(.02,Math.min(50,this.scale*(e.deltaY<0?1.15:1/1.15)));this.pan=[e.clientX-r.left-p[0]*this.scale,e.clientY-r.top-p[1]*this.scale];this.draw()},{passive:false});
  new ResizeObserver(()=>{if(this.dialog.open)this.fit()}).observe(this.host);
 }
 async open(imageId,parent,image) {
  this.discard();this.imageId=imageId;this.parent=parent;this.image=image;this.points=[];this.box=null;this.drag=null;
  this.el('roiError').textContent='';
  this.el('roiMaskChoice').value='-1';
  this.el('roiAlignPositive').checked=false;this.el('roiAlignPositive').disabled=parent!=null;this.el('roiBoxMargin').value=6;this.el('roiBoxMargin').disabled=parent!=null;
  if(parent==null){
   this.overlay=document.createElement('canvas');this.overlay.width=image.width;this.overlay.height=image.height;
   this.roi=[0,0,image.width,image.height];this.bounds=[...this.roi];this.el('roiTool').value='roi';
   this.el('roiTitle').textContent='독립 ROI 확대 분할 (부모 마스크 없음)';
   this.el('roiExplanation').textContent='노란 추론 ROI를 먼저 드래그한 뒤 양성·음성점 또는 SAM box를 지정하세요. ROI 밖을 채우지 않습니다. 가장자리에 닿은 절단선은 실제 경계가 아니며 GT/계측에서 미지정 처리합니다. 미리보기 확인 후에만 새 후보를 저장합니다.';
   this.dialog.showModal();this.fit();return;
  }
  const mask=await new Promise((resolve,reject)=>{const im=new Image();im.onload=()=>resolve(im);im.onerror=()=>reject(Error('부모 마스크를 읽을 수 없습니다.'));im.src=`/api/masks/${imageId}/${parent}.png?${Date.now()}`});
  this.overlay=document.createElement('canvas');this.overlay.width=mask.width;this.overlay.height=mask.height;
  const x=this.overlay.getContext('2d');x.drawImage(mask,0,0);const d=x.getImageData(0,0,mask.width,mask.height);
  let x0=mask.width,y0=mask.height,x1=0,y1=0;
  for(let i=0;i<d.data.length;i+=4){const inside=d.data[i]>127;if(inside){const px=i/4%mask.width,py=Math.floor(i/4/mask.width);x0=Math.min(x0,px);y0=Math.min(y0,py);x1=Math.max(x1,px+1);y1=Math.max(y1,py+1)}d.data[i]=30;d.data[i+1]=220;d.data[i+2]=170;d.data[i+3]=inside?90:0}
  if(x1<=x0||y1<=y0)throw Error('비어 있는 후보는 재분할할 수 없습니다.');
  x.putImageData(d,0,0);this.roi=[x0,y0,x1,y1];this.bounds=[Math.max(0,x0-16),Math.max(0,y0-16),Math.min(image.width,x1+16),Math.min(image.height,y1+16)];
  this.el('roiTitle').textContent=`후보 #${parent} 내부 재분할`;this.el('roiTool').value='positive';
  this.el('roiExplanation').textContent='선택 부모 내부 재분할입니다. ROI와 양성·음성점 또는 box를 지정하세요. 결과는 부모 마스크 내부로 제한하며, 주황색 미리보기 확인 후 새 후보로 저장합니다.';this.dialog.showModal();this.fit();
 }
 fit(){if(!this.image)return;this.canvas.width=Math.max(1,this.host.clientWidth);this.canvas.height=Math.max(1,this.host.clientHeight);const [x0,y0,x1,y1]=this.bounds;this.scale=Math.min(this.canvas.width/(x1-x0),this.canvas.height/(y1-y0))*.92;this.pan=[(this.canvas.width-(x0+x1)*this.scale)/2,(this.canvas.height-(y0+y1)*this.scale)/2];this.draw()}
 coord(e){const r=this.canvas.getBoundingClientRect();return [(e.clientX-r.left-this.pan[0])/this.scale,(e.clientY-r.top-this.pan[1])/this.scale]}
 clamp(p){return [Math.max(0,Math.min(this.image.width,p[0])),Math.max(0,Math.min(this.image.height,p[1]))]}
 inside(p){return p[0]>=this.roi[0]&&p[0]<this.roi[2]&&p[1]>=this.roi[1]&&p[1]<this.roi[3]}
 down(e){if(this.busy||e.button!==0)return;const p=this.coord(e),mode=this.el('roiTool').value;this.canvas.setPointerCapture(e.pointerId);if(mode==='view')this.drag={mode,start:[e.clientX,e.clientY],pan:[...this.pan]};else if(mode==='box'||mode==='roi')this.drag={mode,start:this.clamp(p),now:this.clamp(p)};else if(this.inside(p)){this.points.push([...p,mode==='negative'?0:1]);this.el('roiError').textContent=''}else this.el('roiError').textContent='노란색 ROI 안에 점을 찍으세요.';this.draw()}
 move(e){if(!this.drag||this.busy)return;if(this.drag.mode==='view')this.pan=[this.drag.pan[0]+e.clientX-this.drag.start[0],this.drag.pan[1]+e.clientY-this.drag.start[1]];else this.drag.now=this.clamp(this.coord(e));this.draw()}
 up(e){if(!this.drag||this.busy)return;const d=this.drag;this.drag=null;if(d.mode!=='view'){const p=this.clamp(this.coord(e)),r=[Math.floor(Math.min(d.start[0],p[0])),Math.floor(Math.min(d.start[1],p[1])),Math.ceil(Math.max(d.start[0],p[0])),Math.ceil(Math.max(d.start[1],p[1]))];if(r[2]-r[0]>=2&&r[3]-r[1]>=2){if(d.mode==='roi'){this.roi=r;this.points=this.points.filter(p=>this.inside(p));this.box=null;this.el('roiError').textContent='ROI 밖의 점과 기존 box를 제거했습니다.'}else if(r[0]>=this.roi[0]&&r[1]>=this.roi[1]&&r[2]<=this.roi[2]&&r[3]<=this.roi[3]){this.box=r;this.el('roiError').textContent=''}else this.el('roiError').textContent='SAM box는 노란색 ROI 안에 지정하세요.'}}this.draw()}
 draw(){if(!this.image)return;if(this.preview&&this.preview.signature!==this.signature())this.discard();this.updateButtons();const x=this.ctx;x.clearRect(0,0,this.canvas.width,this.canvas.height);x.save();x.translate(...this.pan);x.scale(this.scale,this.scale);x.drawImage(this.image,0,0);if(this.el('roiShowMask').checked)x.drawImage(this.overlay,0,0);if(this.previewOverlay&&this.el('roiShowPreview').checked)x.drawImage(this.previewOverlay,0,0);
  const rect=(r,color)=>{if(!r)return;x.strokeStyle=color;x.lineWidth=2/this.scale;x.strokeRect(r[0],r[1],r[2]-r[0],r[3]-r[1])};rect(this.roi,'#ffdd36');
  if(this.el('roiShowPoints').checked){rect(this.box,'#ae87ff');for(const p of this.points){x.fillStyle=p[2]?'#20ff83':'#ff5471';x.beginPath();x.arc(p[0],p[1],5/this.scale,0,Math.PI*2);x.fill()}}
  if(this.drag&&this.drag.mode!=='view')rect([...this.drag.start,...this.drag.now],'white');x.restore();
  this.el('roiInfo').textContent=`ROI [${this.roi.join(', ')}] · 양성 ${this.points.filter(p=>p[2]).length} / 음성 ${this.points.filter(p=>!p[2]).length} · box ${this.box?1:0} · 휠 확대 / 보기·이동 드래그 / 우클릭 점 삭제`;
 }

 signature(){const aligned=this.parent==null&&this.el('roiAlignPositive').checked;return JSON.stringify({image_id:this.imageId,parent:this.parent,roi:this.roi,points:this.points,box:this.box,mask_choice:+this.el('roiMaskChoice').value,align_positive:aligned,box_margin:aligned?+this.el('roiBoxMargin').value:0})}
 updateButtons(){this.el('roiAccept').disabled=this.busy||!this.preview;this.el('roiDiscard').disabled=this.busy||!this.preview;this.el('roiRun').disabled=this.busy;this.el('roiClose').disabled=this.busy}
 discard(){const old=this.preview;this.preview=null;this.previewOverlay=null;if(old)this.api('roi-previews/'+old.token,null,'DELETE').catch(()=>{});this.updateButtons()}
 async run(){
  if(this.busy)return;
  if(!this.points.some(p=>p[2]===1)&&!this.box){this.el('roiError').textContent='양성점 또는 SAM box를 먼저 지정하세요.';return}
  this.discard();this.busy=true;this.updateButtons();this.el('roiError').textContent='SAM 재분할 미리보기 중…';let token=null;
  try{
   const signature=this.signature();const result=await this.api('sam/prompt',{...JSON.parse(signature),preview:true});token=result.preview_token;
   if(!token)throw Error('서버가 미리보기를 지원하지 않습니다. 서버를 새 버전으로 재시작하세요.');
   const im=await new Promise((resolve,reject)=>{const x=new Image();x.onload=()=>resolve(x);x.onerror=()=>reject(Error('미리보기 이미지를 불러올 수 없습니다.'));x.src='/api/roi-previews/'+token+'.png'});
   const overlay=document.createElement('canvas');overlay.width=im.width;overlay.height=im.height;const x=overlay.getContext('2d');x.drawImage(im,0,0);const d=x.getImageData(0,0,im.width,im.height);
   for(let i=0;i<d.data.length;i+=4){const inside=d.data[i]>127;d.data[i]=255;d.data[i+1]=156;d.data[i+2]=35;d.data[i+3]=inside?170:0}x.putImageData(d,0,0);
   this.preview={token,signature};this.previewOverlay=overlay;this.el('roiShowPreview').checked=true;
   const alternatives=(result.multimask_scores||[]).map((s,i)=>`${i+1}: ${s.toFixed(3)}`).join(' / ');
   this.el('roiError').textContent=`주황색 결과 ${result.area} px를 확인하세요. 아직 저장되지 않았습니다. ${alternatives?'후보 예측점수 '+alternatives+' (정확도 보장 아님). ':''}${(result.warnings||[]).join(' ')}`;
  }catch(e){if(token&&!this.preview)this.api('roi-previews/'+token,null,'DELETE').catch(()=>{});this.el('roiError').textContent=e.message}
  finally{this.busy=false;this.draw()}
 }
 async accept(){
  if(this.busy||!this.preview)return;
  if(this.preview.signature!==this.signature()){this.discard();this.el('roiError').textContent='입력이 바뀌었습니다. 다시 미리보기 하세요.';return}
  this.busy=true;this.updateButtons();
  try{const result=await this.api('roi-previews/'+this.preview.token+'/accept',{});this.preview=null;this.previewOverlay=null;await this.onSaved(result);this.dialog.close()}
  catch(e){this.el('roiError').textContent=e.message}
  finally{this.busy=false;this.updateButtons()}
 }
}
