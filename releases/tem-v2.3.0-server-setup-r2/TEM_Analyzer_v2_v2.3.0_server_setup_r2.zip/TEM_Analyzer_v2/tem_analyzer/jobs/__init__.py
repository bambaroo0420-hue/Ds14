"""Serial, cancellable project jobs."""
