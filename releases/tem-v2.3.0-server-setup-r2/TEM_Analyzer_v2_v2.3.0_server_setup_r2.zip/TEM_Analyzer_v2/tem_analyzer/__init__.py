"""Local TEM segmentation workbench."""

