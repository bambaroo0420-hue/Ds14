"""Batch flat-color semantic GT preparation. JPEG palettes are estimates, not truth.

No image-size reduction, fixed K, relative-area pruning, or cross-image semantic
class inference. Auto color IDs are local to each image (prompted binary targets).
"""
from pathlib import Path
import csv
import json
import shutil
import tempfile
import hashlib
import numpy as np
from PIL import Image
from scipy import ndimage as ndi
from .data import read_manifest, load_mask, sha256, dump_json

DEFAULT_RECTS = [(20, 1800, 1800, 2000), (20, 20, 200, 120)]
ALGORITHM_VERSION = 2


def clip_rectangles(shape, rectangles):
    h, w = shape[:2]
    effective, notes = [], []
    for rect in rectangles:
        if len(rect) != 4 or any(int(v) != v for v in rect):
            raise ValueError('ignore_rects: use integer (x0,y0,x1,y1)')
        x0, y0, x1, y1 = map(int, rect)
        if x0 >= x1 or y0 >= y1:
            raise ValueError(f'Invalid rectangle: {rect}')
        clipped = [max(0, x0), max(0, y0), min(w, x1), min(h, y1)]
        if clipped != list(rect):
            notes.append(f'Rectangle {list(rect)} clipped to image {w}x{h}')
        if clipped[0] < clipped[2] and clipped[1] < clipped[3]:
            effective.append(clipped)
    ignored = np.zeros((h, w), bool)
    for x0, y0, x1, y1 in effective:
        ignored[y0:y1, x0:x1] = True
    if ignored.all():
        raise ValueError('ignore_rects excludes the entire image')
    return ignored, effective, notes


def nearest_colors(rgb, palette, valid, *, max_distance, ambiguity_margin):
    from scipy.spatial import cKDTree
    tree = cKDTree(np.asarray(palette, np.float64))
    labels = np.full(rgb.shape[:2], 255, np.uint8)
    indices = np.flatnonzero(valid)
    flat = rgb.reshape(-1, 3)
    uncertain = 0
    for start in range(0, len(indices), 100000):
        where = indices[start:start + 100000]
        distance, hit = tree.query(flat[where], k=min(2, len(palette)), workers=1)
        if len(palette) == 1:
            best, selected = distance, hit
            ambiguous = np.zeros(len(where), bool)
        else:
            best, selected = distance[:, 0], hit[:, 0]
            ambiguous = distance[:, 1] - best < ambiguity_margin
        good = (best <= max_distance) & ~ambiguous
        labels.ravel()[where[good]] = selected[good] + 1
        uncertain += int((~good).sum())
    return labels, uncertain


def automatic_colors(rgb, ignored, *, lossy=False, merge_distance=24.,
                     flat_range=16, min_core_pixels=4, max_distance=96.,
                     ambiguity_margin=2.):
    """Exact low-color lossless masks; adaptive flat-interior modes for JPEG.

    Nearby colors within merge_distance may merge in lossy mode. Tiny regions
    without 4 flat interior pixels may be uncertain/missed; report this limitation.
    """
    if rgb.dtype != np.uint8 or rgb.ndim != 3 or rgb.shape[2] != 3:
        raise ValueError('Color GT must be uint8 RGB')
    if merge_distance <= 0 or flat_range < 0 or min_core_pixels < 1 or max_distance <= 0 or ambiguity_margin < 0:
        raise ValueError('Invalid automatic color settings')
    valid = ~ignored
    if not valid.any():
        raise ValueError('No valid GT pixels')
    flat = rgb[valid]
    packed = (flat[:, 0].astype(np.uint32) << 16) | (flat[:, 1].astype(np.uint32) << 8) | flat[:, 2]
    unique = np.unique(packed)
    raw_count = len(unique)
    notes = []
    if not lossy and raw_count <= 254:
        palette = np.stack([unique >> 16, (unique >> 8) & 255, unique & 255], axis=1).astype(np.uint8)
        labels = np.full(valid.shape, 255, np.uint8)
        labels[valid] = np.searchsorted(unique, packed).astype(np.uint8) + 1
        mode, uncertain = 'exact_lossless_rgb', 0
    else:
        # A 3x3 low-range neighborhood identifies painted interiors; no downsample.
        high = ndi.maximum_filter(rgb, size=(3, 3, 1)).astype(np.int16)
        low = ndi.minimum_filter(rgb, size=(3, 3, 1)).astype(np.int16)
        core = valid & ((high - low).max(axis=2) <= flat_range)
        # Excluded text cannot influence the interior-color discovery at its edge.
        core &= ~ndi.maximum_filter(ignored, size=3)
        pixels = rgb[core]
        if len(pixels) < min_core_pixels:
            raise ValueError('No flat painted GT interiors. Check overlay/photographic GT or use lossless labels.')
        quantized = pixels.astype(np.int32) // 4
        bins, inv, counts = np.unique(quantized, axis=0, return_inverse=True, return_counts=True)
        means = np.stack([np.bincount(inv, weights=pixels[:, c], minlength=len(bins)) / counts for c in range(3)], axis=1)
        order = np.argsort(-counts, kind='stable')
        centers, weights = [], []
        # Collect observed modes, never force colors into a chosen K.
        for j in order:
            if counts[j] < min_core_pixels:
                continue
            p = means[j]
            distances = np.linalg.norm(np.asarray(centers) - p, axis=1) if centers else np.array([])
            if len(distances) and distances.min() <= merge_distance:
                k = int(distances.argmin())
                # Keep the original dominant mode fixed to prevent chained merging.
                weights[k] += int(counts[j])
            else:
                centers.append(p)
                weights.append(int(counts[j]))
            if len(centers) > 254:
                raise ValueError('More than 254 color modes: GT may be an overlay or heavily compressed; use label PNG.')
        if not centers:
            raise ValueError('No stable GT colors found; use a flat-color or label PNG mask.')
        palette = np.round(centers).astype(np.uint8)
        palette = palette[np.lexsort((palette[:, 2], palette[:, 1], palette[:, 0]))]
        labels, uncertain = nearest_colors(rgb, palette, valid, max_distance=max_distance,
                                           ambiguity_margin=ambiguity_margin)
        mode = 'estimated_compressed_rgb'
        notes.append('JPEG palette is an estimate: missing thin/rare colors cannot be detected from confidence alone. Review against source GT; prefer original label PNG.')
        if uncertain:
            notes.append(f'{uncertain} ambiguous/outlier pixels set to ignore=255 (in addition to rectangles).')
    used = [i for i in range(len(palette)) if (labels == i + 1).any()]
    # Compact only empty IDs; never erase small connected regions.
    new = np.full_like(labels, 255)
    for i, old in enumerate(used, 1):
        new[labels == old + 1] = i
    palette = palette[used]
    if len(palette) == 0:
        raise ValueError('No confidently assigned GT colors remain')
    return new, palette, dict(mode=mode, raw_rgb_count=raw_count,
        color_count=len(palette), uncertain_pixels=uncertain,
        uncertain_fraction=float(uncertain / valid.sum()), requires_visual_review=(mode != 'exact_lossless_rgb'),
        warnings=notes)


def source_mask(path):
    """Recover originals from both legacy and new prepared-mask sidecars."""
    path = Path(path).resolve()
    visited = set()
    while path.with_suffix('.json').is_file():
        if str(path) in visited:
            raise ValueError('Cyclic GT source metadata')
        visited.add(str(path))
        meta = json.loads(path.with_suffix('.json').read_text())
        if 'source_gt' not in meta:
            break
        source = Path(meta['source_gt'])
        source = source.resolve() if source.is_absolute() else (path.parent / source).resolve()
        if source == path:
            break
        path = source
    if not path.is_file():
        raise FileNotFoundError(f'Original GT missing: {path}')
    return path


def _convert(path, cfg, rectangles, settings):
    with Image.open(path) as im:
        raw = np.asarray(im)
        is_color = raw.ndim == 3 or im.format == 'JPEG'
        rgb = np.asarray(im.convert('RGB'))
        lossy = im.format == 'JPEG'
    ignored, effective, notes = clip_rectangles(rgb.shape, rectangles)
    if is_color and not cfg.get('rgb_label_map'):
        labels, palette, report = automatic_colors(rgb, ignored, lossy=lossy, **settings)
        # No automatic inference that black, white, or largest area is background.
        background = cfg.get('auto_gt_background_rgb')
        if background is not None:
            bg = np.asarray(background, float)
            if bg.shape != (3,) or np.any((bg < 0) | (bg > 255)):
                raise ValueError('auto_gt_background_rgb must be [R,G,B] or null')
            distances = np.linalg.norm(palette.astype(float) - bg, axis=1)
            limit = settings.get('merge_distance', 24.) if lossy else 0.
            matches = np.flatnonzero(distances <= limit)
            if len(matches) > 1:
                raise ValueError('Background color matches multiple modes; use a less ambiguous mask')
            if len(matches):
                labels[labels == int(matches[0]) + 1] = 0
        display = {str(i + 1): list(map(int, c)) for i, c in enumerate(palette)}
    else:
        # Already indexed labels retain IDs and explicit legacy remapping, if any.
        temporary_cfg = dict(cfg, class_names={str(i): str(i) for i in range(1, 255)})
        labels = load_mask(path, temporary_cfg)
        if np.any((labels < 0) | (labels > 255)):
            raise ValueError('Index GT must have labels in 0..255')
        labels = labels.astype(np.uint8)
        labels[labels == cfg.get('ignore_label', 255)] = 255
        labels[labels == cfg.get('background_label', 0)] = 0
        from matplotlib import colormaps
        palette = np.asarray(colormaps['tab20'].colors) * 255
        display = {str(int(i)): palette[int(i) % 20].astype(int).tolist()
                   for i in np.unique(labels) if i not in (0, 255)}
        report = dict(mode='existing_label_ids', raw_rgb_count=None,
                      color_count=len(display), uncertain_pixels=0, uncertain_fraction=0., warnings=[])
    labels[ignored] = 255
    report.update(rectangles=effective, requested_rectangles=rectangles,
                  rectangle_ignored_pixels=int(ignored.sum()), ignored_fraction=float((labels == 255).mean()),
                  label_colors=display,
                  label_pixel_counts={str(int(k)): int(v) for k, v in zip(*np.unique(labels, return_counts=True))})
    report['warnings'] = notes + report['warnings']
    if not np.any((labels != 0) & (labels != 255)):
        raise ValueError('No foreground remains after GT preparation')
    return labels, rgb, report


def save_preview(source_rgb, labels, report, output, title):
    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch
    converted = np.zeros_like(source_rgb)
    for k, color in report['label_colors'].items():
        converted[labels == int(k)] = color
    converted[labels == 255] = [255, 0, 255]
    fig, axes = plt.subplots(1, 3, figsize=(16, 5))
    axes[0].imshow(source_rgb); axes[0].set_title('Original painted GT')
    axes[1].imshow(converted, interpolation='nearest'); axes[1].set_title('Auto labels: original colors')
    axes[2].imshow(labels == 255, cmap='gray', vmin=0, vmax=1); axes[2].set_title('White = excluded / uncertain')
    handles = [Patch(color=np.array(c)/255, label=f'ID {k}: {tuple(c)}')
               for k, c in report['label_colors'].items() if str(k) in report['label_pixel_counts']]
    for ax in axes:
        ax.axis('off')
    fig.suptitle(title)
    if len(handles) <= 32:
        fig.legend(handles=handles, loc='lower center', ncol=min(6, len(handles)))
    fig.tight_layout(rect=(0, min(.35, .05 * ((len(handles)+5)//6)), 1, .93))
    fig.savefig(output, dpi=110)
    plt.close(fig)


def prepare_project(root, *, ignore_rects=None, color_settings=None):
    """Convert ALL current manifest rows before audit; persist automatic config.

    Current manifest remains authoritative for splits, including after rerunning
    setup. Outputs are content-addressed and original files remain untouched.
    """
    root = Path(root).resolve()
    config_path = root / 'config.local.json'
    cfg = json.loads(config_path.read_text())
    manifest = Path(cfg['manifest'])
    if not manifest.is_absolute():
        manifest = root / manifest
    rows = read_manifest(manifest)
    rectangles = list(DEFAULT_RECTS if ignore_rects is None else ignore_rects)
    settings = dict(color_settings or {})
    originals, provenance = [], []
    for row in rows:
        p = source_mask(row['mask'])
        with Image.open(row['image']) as image, Image.open(p) as mask:
            if image.size != mask.size:
                raise ValueError(f'Image/GT dimensions differ: {row["image_id"]}')
        originals.append(p)
        provenance.append(dict(row, source_gt=str(p), source_sha256=sha256(p)))
        # Prepared paths are not part of the fingerprint: reruns stay stable.
        provenance[-1]['mask'] = str(p)
    identity = dict(version=ALGORITHM_VERSION, rows=provenance, rectangles=rectangles,
                    settings=settings, label_map=cfg.get('label_map'),
                    rgb_label_map=cfg.get('rgb_label_map'),
                    background=cfg.get('auto_gt_background_rgb'),
                    source_background=cfg.get('background_label', 0), source_ignore=cfg.get('ignore_label', 255))
    # Preserve original decoding settings across repeated prepared-mask runs.
    if cfg.get('auto_gt_source_decoding'):
        identity.update(cfg['auto_gt_source_decoding'])
    fingerprint = hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()[:16]
    destination = root / 'data' / 'auto_gt' / fingerprint
    summary_path = destination / 'summary.json'
    decoding = {k: identity[k] for k in ('label_map', 'rgb_label_map', 'source_background', 'source_ignore')}
    conversion_cfg = dict(cfg, label_map=decoding['label_map'], rgb_label_map=decoding['rgb_label_map'],
                          background_label=decoding['source_background'], ignore_label=decoding['source_ignore'])
    if summary_path.exists():
        summary = json.loads(summary_path.read_text())
        for r in summary['images']:
            p = destination / 'masks' / (r['image_id'] + '.png')
            if not p.is_file() or sha256(p) != r['output_sha256']:
                raise ValueError(f'Prepared mask changed or missing: {p}; restore it or remove this generated run folder.')
        print('GT conversion reused:', destination)
    else:
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = Path(tempfile.mkdtemp(prefix='.preparing_', dir=destination.parent))
        try:
            (temporary / 'masks').mkdir(); (temporary / 'previews').mkdir()
            reports, class_ids = [], set()
            for row, source in zip(rows, originals):
                labels, rgb, report = _convert(source, conversion_cfg, rectangles, settings)
                class_ids.update(int(i) for i in np.unique(labels) if i not in (0, 255))
                output = temporary / 'masks' / (row['image_id'] + '.png')
                Image.fromarray(labels).save(output)
                report.update(image_id=row['image_id'], split=row['split'], source_gt=str(source),
                    source_sha256=sha256(source), output_sha256=sha256(output),
                    preparation='automatic', reviewed=False)
                dump_json(output.with_suffix('.json'), report)
                save_preview(rgb, labels, report, temporary / 'previews' / (row['image_id'] + '.png'), row['image_id'])
                reports.append(report)
                print(f'{row["image_id"]}: {report["color_count"]} colors, '
                      f'uncertain={report["uncertain_fraction"]:.2%}, ignored={report["ignored_fraction"]:.2%}', flush=True)
            names = {str(i): f'region_color_{i:03d}' for i in sorted(class_ids)}
            summary = dict(fingerprint=fingerprint, class_names=names, images=reports,
                class_id_scope='per_image_color_or_existing_label; not material identity', provenance=identity)
            dump_json(temporary / 'summary.json', summary)
            prepared = [dict(r, mask=str(destination / 'masks' / (r['image_id'] + '.png'))) for r in rows]
            with (temporary / 'manifest.csv').open('w', encoding='utf-8', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=list(rows[0]))
                writer.writeheader(); writer.writerows(prepared)
            temporary.rename(destination)
        except Exception:
            shutil.rmtree(temporary, ignore_errors=True)
            raise
    backup = root / 'config.before_auto_gt.json'
    if not backup.exists():
        shutil.copy2(config_path, backup)
    cfg.update(manifest=str(destination / 'manifest.csv'), class_names=summary['class_names'],
        background_label=0, ignore_label=255, label_map=None, rgb_label_map=None,
        auto_gt_source_decoding=decoding, auto_gt_summary=str(summary_path),
        auto_gt_ignore_rects=rectangles, auto_gt_color_settings=settings,
        class_id_scope=summary['class_id_scope'])
    if cfg.get('auto_gt_fingerprint') != fingerprint:
        output_dir = Path(cfg['output_dir'])
        if not output_dir.is_absolute():
            output_dir = root / output_dir
        if output_dir.exists() and any(output_dir.iterdir()):
            cfg['output_dir'] = str(output_dir.parent / f'experiment_gt_{fingerprint}')
            print('GT changed; new training output:', cfg['output_dir'])
    cfg['auto_gt_fingerprint'] = fingerprint
    temp_config = config_path.with_suffix('.json.tmp')
    dump_json(temp_config, cfg); temp_config.replace(config_path)
    return cfg, summary


def show_project_previews(cfg, *, splits=('train', 'val')):
    """Display every selected preview, without per-image user input."""
    from IPython.display import display, Image as NotebookImage
    summary_path = Path(cfg['auto_gt_summary'])
    summary = json.loads(summary_path.read_text())
    print('Auto class names:', summary['class_names'])
    print('IDs describe colors within each image, not shared material names.')
    for report in summary['images']:
        if report['split'] not in splits:
            continue
        print(report['image_id'], 'colors=', report['color_count'])
        for note in report['warnings']:
            print('  NOTE:', note)
        print('  ID / RGB / pixels:', [(k, c, report['label_pixel_counts'].get(k, 0))
              for k, c in report['label_colors'].items()])
        display(NotebookImage(filename=str(summary_path.parent / 'previews' / (report['image_id'] + '.png'))))
