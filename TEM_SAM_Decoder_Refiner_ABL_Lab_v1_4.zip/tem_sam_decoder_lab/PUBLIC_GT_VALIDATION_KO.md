# v1.4 실제 공개 multiclass GT 실행 검증

검증일: 2026-09-30 (한국). 이전 v1.3의 합성 도형 검증만으로는 실제 JPG 마스크의 신뢰성을 확인하기에 부족했습니다. 실제 공개 GT에서 색의 과분할과 작은 클래스 누락이 재현됐습니다.

## 확보한 실제 데이터와 재현 방법

출처: https://github.com/alexgkendall/SegNet-Tutorial (CamVid). 해당 저장소에 포함된 실제 도로 이미지와 480×360 다중 클래스 라벨 PNG 20쌍을 다운로드했습니다. 이미지별 관측 라벨은 9~12개입니다. 원본 다운로드 URL·파일별 SHA256은 validation/development_sources.json 및 heldout_sources.json에 기록했습니다. 고정 저장소 tree는 bb68b64e72cb004b3ed927fee0f5624dd8097498 입니다.

원본 라벨 ID를 같은 저장소의 Scripts/camvid12.png 팔레트로 RGB화한 뒤 PNG 및 JPG 품질 95/85/70으로 저장했습니다. 따라서 JPG 압축 전의 정확한 색/영역을 알고 비교할 수 있습니다. 임의 합성 도형이 아닌 실제 물체 경계를 가진 마스크입니다. 재현성 있는 손실 압축 시험이며, 사람이 처음부터 작성한 회사 JPG의 압축 이력까지 대표하지는 않습니다.

10쌍은 문제 재현/알고리즘 조정에 사용하고, 다른 10쌍은 조정 후 고정된 설정으로 추가 확인했습니다. 아래 표는 **조정에 사용하지 않은 10쌍**의 이미지별 지표 평균입니다. 이는 GT 색 복원 지표이며 SAM의 학습 정확도나 TEM 성능이 아닙니다. CamVid 비디오의 인접 장면을 포함하므로 독립적인 소재/도메인 일반화 평가라고 해석하면 안 됩니다.

## 수정 전후 측정

| 입력 | v1.3 픽셀 일치율 | v1.4 픽셀 일치율 | v1.3 클래스 평균 IoU | v1.4 클래스 평균 IoU |
|---|---:|---:|---:|---:|
| PNG | 100.00% | 100.00% | 100.00% | 100.00% |
| JPG 품질 95 | 95.69% | 97.55% | 77.13% | 81.00% |
| JPG 품질 85 | 83.65% | 97.22% | 62.36% | 77.88% |
| JPG 품질 70 | 78.39% | 95.83% | 54.44% | 76.30% |

자동 생성 ID는 기준 ID와 다를 수 있어 평가에서만 Hungarian 일대일 IoU 매칭으로 대응시켰습니다. 원본 라벨/팔레트는 자동 추정 함수에 주지 않았습니다. 제외된 불확실 픽셀과 대응하지 못한 픽셀도 일치율의 분모에 포함했습니다. 작은 클래스가 누락되면 클래스 평균 IoU에 0으로 반영합니다. 색 복원 시험에서는 관측된 모든 ID(미표기 ID 포함)를 색 그룹으로 평가했습니다. 의미별 segmentation 성능 평가가 아닙니다.

원본 색 수는 추가 10쌍 평균 10.6개입니다. JPG85에서는 v1.3이 평균 20.3개로 과분할했고, v1.4는 평균 9.5개로 줄었습니다. **아직 일부 색이 누락됩니다.** 높은 전체 픽셀 일치율만 보고 작은 층도 복원됐다고 판단하면 안 됩니다. v1.4의 uncertain 비율이 낮아도 실제 오류가 낮다는 보장은 없습니다.

## 바꾼 코드와 남는 한계

- JPG의 평탄한 내부 픽셀 허용 범위를 8→16, RGB 대표색 병합 거리를 10→24로 조정해 압축으로 갈라진 대표색을 더 잘 묶습니다.
- 대표색과의 최대 할당 거리를 48→96으로 조정해 과도하게 무시되던 경계 픽셀을 줄입니다. 가장 가까운 두 대표색이 모호한 경우의 기준은 유지합니다.
- 무손실 저색상 PNG의 정확한 색 분리 경로는 그대로입니다. JPEG 추정에는 requires_visual_review를 명시했습니다.
- HF 다운로드를 실제 실행했을 때 이 환경의 SOCKS 프록시에 socksio가 없어 실패했습니다. httpx[socks], requests[socks]를 requirements에 추가한 후 재시도해 성공했습니다. 프록시·SSL 보안 설정을 해제하지 않았습니다.

RGB 거리가 24 이하인 서로 다른 실제 색을 하나로 묶을 가능성도 있습니다. 작은/얇은 층의 색이 안정적인 내부 픽셀을 갖지 않으면 대표색 자체가 빠질 수 있습니다. JPG는 자동 처리한 결과를 원본 GT와 비교해야 하며, 가능하면 최초 작성 도구의 원본 라벨 PNG를 확보하는 편이 정확합니다. JPG를 PNG로 다시 저장해도 손실은 복구되지 않습니다. 이번 수정으로 모든 JPG가 정확해졌다고 주장하지 않습니다.

## 실제 실행한 범위

1. 원본 CamVid 인덱스 PNG: 데이터셋의 0=실제 클래스, 11=미표기 규칙을 명시적 label_map으로 연결한 뒤 prepare_project→audit 통과. 무조건 0을 배경으로 가정하지 않았습니다.
2. 실제 이미지 3장 + JPG85 GT로 00 setup, 00a, 01 train, 02 evaluate/export, 03 test의 Python 셀을 순서대로 실행했습니다. train 2/val 1, 별도 test 이미지 1장입니다. 출력 이미지와 bitpacked mask NPZ 저장까지 확인했습니다.
3. 위 노트북 전체 흐름에서는 공식 SAM 구성요소를 축소한 무작위 CPU 모델을 사용했습니다. 4조건 각 1 epoch, ABL warmup=0, 2×2 grid, prompts_per_region=1로 짧게 실행했습니다. 결과 점수는 모델 정확도 판단에 사용하지 않습니다. 설치·HF 다운로드 셀은 해당 검증에서는 대체했고, HF 다운로드는 아래에서 별도로 실제 수행했습니다.
4. 실제 SAM ViT-H 2,564,550,879바이트를 HF facebook/ov-seg의 고정 revision에서 다운로드하고 SHA256 검증을 완료했습니다. SHA256: a7bf3b02f3ebf1267aba913ff637d9a2d5c33d3173bb679e46d9f338c26f262e.
5. **실제 사전학습 ViT-H**, 표준 1024 encoder 입력, CPU로 공개 이미지 1장/영역 1개의 프롬프트를 처리했습니다. decoder_noabl, decoder_abl, refiner_noabl, refiner_abl 각각 초기 상태에서 1 optimizer step을 실행했습니다. 유한 loss, 0보다 큰 gradient, 업데이트, checkpoint 저장/재로딩 및 360×480 출력 확인 모두 통과했습니다. 조건별 수치는 validation/vith_smoke_results.json에 있습니다.
6. 기존 자동 GT·분할·4조건 학습/평가/export 통합 테스트 총 14개 통과. Python/노트북 문법과 nbformat 스키마도 검사했습니다.

이 환경은 로컬 소켓 생성을 허용하지 않아 Jupyter 커널 시작이 TCP/IPC 모두 차단됐습니다. 대신 동일 노트북 코드를 in-process IPython으로 실행했습니다. 실제 Jupyter/VS Code 프런트엔드 조작은 검증하지 않았습니다. 검증용으로 변경한 셀 설정은 validation/notebook_execution.json에 기록했습니다. 실제 회사 데이터, CUDA GPU, ViT-H 다중 epoch 학습 및 TEM 정확도는 검증하지 않았습니다.

## 같은 검증을 다시 실행하려면

프로젝트 루트에서 requirements와 CPU 또는 CUDA에 맞는 torch/torchvision을 설치한 환경을 사용합니다. 노트북 셀 재현에는 추가로 nbformat과 IPython이 필요합니다.

```bash
python validation/download_public_gt.py --destination /path/to/public_gt
python validation/benchmark_public_gt.py --data /path/to/public_gt/heldout --tag my_result
python validation/run_public_notebook_cells.py --data /path/to/public_gt/development --output /path/to/new_verification_project
python validation/run_real_vith_smoke.py --data /path/to/public_gt/development --checkpoint /path/to/sam_vit_h_4b8939.pth --output /path/to/vith_check
python -m unittest discover -s tests -v
```

첫 명령만 공개 자료를 다운로드합니다. 회사 TEM 파일을 외부로 전송하는 동작은 없습니다. 신규 output 경로를 사용하세요. CamVid 자료는 학습용 TEM 데이터로 포함하지 않았습니다.

## 기존 사용자 적용

v1.4 ZIP의 temlab/, notebooks/, requirements.txt를 기존 프로젝트에 복사합니다. 기존 data/, weights/, runs/, config.local.json은 보존하고 커널을 재시작하세요. 패키지 설치 셀을 다시 실행해 추가 의존성을 반영한 뒤 00a_gt_prepare.ipynb를 실행하면 기존 분할을 유지하며 새 규칙으로 GT를 재생성합니다. 변경된 GT에는 새로운 학습 결과를 만들어 비교해야 합니다.

## 자료 출처와 그림

validation/camvid_comparison.jpg는 추가 검증 10장의 JPG85 픽셀 일치율 중간 순위 사례를 고정 규칙으로 골랐습니다. 예쁘게 나온 최상위 사례만 고르지 않았습니다. 평가/표시를 위해 ID 색을 원본에 맞췄으며, 오른쪽 아래 빨간색은 남아 있는 불일치/미할당입니다.

데이터·팔레트·그림 원자료: Alex Kendall / SegNet-Tutorial, CamVid. 원 저장소는 연구·개인 용도의 CC BY-NC 4.0 조건을 안내합니다. 파생 비교 그림에도 해당 원자료 출처와 조건이 적용됩니다. 원본 데이터 전체는 패키지에 재배포하지 않으며 URL과 해시를 제공합니다. 프로젝트 코드의 기존 라이선스와 별개입니다.
