import json,sys,shutil,copy,base64
from pathlib import Path
import numpy as np
from PIL import Image
import nbformat
from IPython.core.interactiveshell import InteractiveShell
from IPython.utils.capture import capture_output
import os
import argparse
parser=argparse.ArgumentParser()
parser.add_argument('--package',default=str(Path(__file__).resolve().parents[1]))
parser.add_argument('--data',required=True)
parser.add_argument('--output',required=True)
args=parser.parse_args()
SOURCE=Path(args.package).resolve()
DATA=Path(args.data).resolve()
ROOT=Path(args.output).resolve()
if ROOT.exists() and not os.environ.get('VERIFY_NOTEBOOKS'):
 raise FileExistsError('Use a new --output directory for a fresh notebook verification.')
ROOT.mkdir(parents=True,exist_ok=True)
for name in ['temlab','vendor','notebooks','tests']:
 shutil.copytree(SOURCE/name,ROOT/name,dirs_exist_ok=True)
for file in SOURCE.iterdir():
 if file.is_file():shutil.copy2(file,ROOT/file.name)
(ROOT/'data/images').mkdir(parents=True,exist_ok=True);(ROOT/'data/masks').mkdir(exist_ok=True);(ROOT/'data/test').mkdir(exist_ok=True)
paths=sorted((DATA/'CamVid/trainannot').glob('*.png'))[:3]
pal=np.asarray(Image.open(DATA/'Scripts/camvid12.png').convert('RGB'))[0,:12]
for p in paths:
 shutil.copy2(DATA/'CamVid/train'/p.name,ROOT/'data/images'/p.name)
 truth=np.asarray(Image.open(p));Image.fromarray(pal[truth]).save(ROOT/'data/masks'/p.with_suffix('.jpg').name,quality=85)
# Test-only image remains separate from these train/val images.
shutil.copy2(DATA/'CamVid/train'/sorted((DATA/'CamVid/trainannot').glob('*.png'))[4].name,ROOT/'data/test')
setup_boot='''import sys
sys.path.insert(0,str(ROOT/'tests'))
from test_pipeline import tiny_sam
from temlab.models import sam_model_registry
import torch
torch.set_num_threads(2)
sam_model_registry['vit_test']=tiny_sam
'''
config_boot='''cfg.update(model_type='vit_test',device='cpu',encoder_amp=False,
 sam_checkpoint=str(ROOT/'weights/tiny_random_sam.pt'),epochs=1,abl_warmup_epochs=0,
 prompts_per_region=1,background_samples_per_image=0,grid_points_per_side=2,
 loss_side=512,refine_side=64,refiner_width=8)
'''
selected=os.environ.get('VERIFY_NOTEBOOKS','')
logs=json.loads((ROOT/'execution_log.json').read_text()) if selected and (ROOT/'execution_log.json').exists() else []
for name in ['00_data_setup.ipynb','00a_gt_prepare.ipynb','01_train.ipynb','02_evaluate_export.ipynb','03_predict_test_images.ipynb']:
 if selected and name not in selected.split(','):continue
 logs=[r for r in logs if r['notebook']!=name]
 nb=nbformat.read(SOURCE/'notebooks'/name,as_version=4)
 changes=[]
 if name.startswith('00_data'):
  nb.cells[3].source=nb.cells[3].source.replace('INSTALL_PACKAGES = True','INSTALL_PACKAGES = False');changes.append('skip already-installed packages')
  nb.cells[7].source=setup_boot+"\n(ROOT/'weights').mkdir(exist_ok=True)\nSAM_CHECKPOINT=ROOT/'weights/tiny_random_sam.pt'\ntorch.save(tiny_sam().state_dict(),SAM_CHECKPOINT)\n";changes.append('replace HF ViT-H download with official tiny random SAM fixture')
  nb.cells[9].source+='\n'+config_boot+"dump_json(config_path,cfg)\n";changes.append('CPU tiny fixture config')
 elif name.startswith('01_'):
  nb.cells[2].source=setup_boot+nb.cells[2].source
  nb.cells[4].source=config_boot+"dump_json(ROOT/'config.local.json',cfg)\n";changes.append('1 epoch, ABL active, 1 prompt, CPU tiny SAM')
 elif name.startswith('02_'):
  nb.cells[3].source=setup_boot+nb.cells[3].source
  nb.cells[5].source=nb.cells[5].source.replace('= 16','= 2');changes.append('2x2 grid; CPU tiny SAM registered')
 elif name.startswith('03_'):
  nb.cells[2].source=setup_boot+nb.cells[2].source;changes.append('CPU tiny SAM registered')
 print('EXECUTE',name,flush=True)
 try:
  os.chdir(ROOT)
  InteractiveShell.clear_instance()
  shell=InteractiveShell.instance()
  for cell_no, cell in enumerate(nb.cells):
   if cell.cell_type != 'code':continue
   print(' cell',cell_no,flush=True)
   with capture_output() as captured:
    result=shell.run_cell(cell.source,store_history=True)
   cell.execution_count=cell_no+1
   cell.outputs=[]
   if captured.stdout:cell.outputs.append(nbformat.v4.new_output('stream',name='stdout',text=captured.stdout))
   if captured.stderr:cell.outputs.append(nbformat.v4.new_output('stream',name='stderr',text=captured.stderr))
   for output in captured.outputs:
    if output.data:
     data={k:base64.b64encode(v).decode() if isinstance(v,bytes) else v for k,v in output.data.items()}
     cell.outputs.append(nbformat.v4.new_output('display_data',data=data,metadata=output.metadata))
   if result.error_before_exec or result.error_in_exec:
    raise RuntimeError(f'Cell {cell_no}: {result.error_before_exec or result.error_in_exec}\n{captured.stdout}\n{captured.stderr}')
  status='passed'
 except Exception as e:
  status='FAILED: '+str(e)
 nbformat.write(nb,ROOT/(name.replace('.ipynb','.executed.ipynb')))
 logs.append(dict(notebook=name,status=status,execution='in-process IPython; local sockets unavailable',fixture_overrides=changes))
 (ROOT/'execution_log.json').write_text(json.dumps(logs,indent=2))
 print(status,flush=True)
 if status!='passed':sys.exit(1)
