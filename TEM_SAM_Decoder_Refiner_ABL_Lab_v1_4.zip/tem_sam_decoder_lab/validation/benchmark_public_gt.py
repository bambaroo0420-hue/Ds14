import sys,json,time,io
from pathlib import Path
import numpy as np
from PIL import Image
from scipy.optimize import linear_sum_assignment
import argparse
parser=argparse.ArgumentParser()
parser.add_argument('--package',default=str(Path(__file__).resolve().parents[1]))
parser.add_argument('--data',required=True)
parser.add_argument('--tag',default='verification')
args=parser.parse_args()
sys.path.insert(0,args.package)
from temlab.auto_gt import automatic_colors
root=Path(args.data).resolve()
pal=np.asarray(Image.open(root/'Scripts/camvid12.png').convert('RGB'))[0,:12]
records=[]
for p in sorted((root/'CamVid/trainannot').glob('*.png')):
 truth=np.asarray(Image.open(p));rgb=pal[truth]
 for q in ['png',95,85,70]:
  if q=='png':a=rgb
  else:
   buf=io.BytesIO();Image.fromarray(rgb).save(buf,format='JPEG',quality=q);buf.seek(0);a=np.asarray(Image.open(buf).convert('RGB'))
  start=time.perf_counter()
  pred,colors,rep=automatic_colors(a,np.zeros(truth.shape,bool),lossy=q!='png')
  ids=np.unique(truth);pids=np.array([x for x in np.unique(pred) if x!=255])
  matrix=np.zeros((len(ids),len(pids)))
  for i,g in enumerate(ids):
   for j,h in enumerate(pids):
    inter=((truth==g)&(pred==h)).sum();union=((truth==g)|(pred==h)).sum();matrix[i,j]=inter/max(1,union)
  rr,cc=linear_sum_assignment(-matrix)
  correct=sum(int(((truth==ids[i])&(pred==pids[j])).sum()) for i,j in zip(rr,cc))
  metrics=dict(image=p.stem,format=str(q),true_colors=len(ids),detected_colors=len(colors),
   uncertain_fraction=rep['uncertain_fraction'],all_pixel_agreement=correct/truth.size,
   matched_miou=float(matrix[rr,cc].sum()/len(ids)),seconds=time.perf_counter()-start)
  records.append(metrics)
  print(json.dumps(metrics),flush=True)
  out=root/args.tag/p.stem;out.mkdir(parents=True,exist_ok=True)
  Image.fromarray(pred).save(out/f'{q}_pred.png')
  Image.fromarray(a).save(out/f'{q}_input.png')
(root/(args.tag+'.json')).write_text(json.dumps(records,indent=2))
for q in ['png','95','85','70']:
 rows=[r for r in records if r['format']==q]
 print('SUMMARY',q,{k:float(np.mean([r[k] for r in rows])) for k in ['true_colors','detected_colors','uncertain_fraction','all_pixel_agreement','matched_miou']})
