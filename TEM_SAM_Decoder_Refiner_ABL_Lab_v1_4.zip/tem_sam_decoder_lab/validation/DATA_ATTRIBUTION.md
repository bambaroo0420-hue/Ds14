Source: https://github.com/alexgkendall/SegNet-Tutorial
CamVid data / palette, Alex Kendall and original dataset authors.
Repository license notice: https://creativecommons.org/licenses/by-nc/4.0/
camvid_comparison.jpg is a derived verification figure. Original datasets are not bundled.
