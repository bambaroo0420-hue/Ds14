from pathlib import Path
import sys,json,time,gc,copy,resource
import numpy as np
import torch
import argparse
parser=argparse.ArgumentParser()
parser.add_argument('--package',default=str(Path(__file__).resolve().parents[1]))
parser.add_argument('--data',required=True)
parser.add_argument('--checkpoint',required=True)
parser.add_argument('--output',required=True)
args=parser.parse_args()
DATA=Path(args.data).resolve()
ROOT=Path(args.output).resolve();ROOT.mkdir(parents=True,exist_ok=True)
PKG=Path(args.package).resolve()
sys.path.insert(0,str(PKG))
from temlab.models import Engine
from temlab.data import load_image,center_point
from temlab.train import target_tensors
from temlab.losses import segmentation_loss,ABL
from PIL import Image
from scipy import ndimage as ndi
# Real ViT-H and its normal 1024 encoder resolution. CPU only; no accuracy claim.
torch.set_num_threads(2)
cfg=json.loads((PKG/'config.example.json').read_text())
cfg.update(sam_checkpoint=str(Path(args.checkpoint).resolve()),device='cpu',encoder_amp=False,
 cache_dir=str(ROOT/'vith_cache'),class_names={'1':'test_region'})
p=sorted((DATA/'CamVid/trainannot').glob('*.png'))[0]
im=load_image(DATA/'CamVid/train'/p.name)
gt=np.asarray(Image.open(p));cc,n=ndi.label(gt==4);areas=np.bincount(cc.ravel());areas[0]=0;region=cc==areas.argmax()
valid=np.ones(region.shape,bool);prompt={'points':[center_point(region)],'labels':[1]}
results=[]
for method in ['decoder','refiner']:
 start=time.perf_counter();print('LOAD',method,flush=True);engine=Engine(cfg,method)
 print('ENCODE',method,flush=True);encoded=engine.encode(im)
 initial=copy.deepcopy(engine.trainable.state_dict())
 for abl_on in [False,True]:
  engine.trainable.load_state_dict(initial);engine.trainable.train()
  optimizer=torch.optim.AdamW([p for p in engine.trainable.parameters() if p.requires_grad],lr=1e-5)
  optimizer.zero_grad(set_to_none=True)
  logits,_=engine.predict_logits(im,encoded,prompt,train=True)
  z,t,v=target_tensors(logits,region,valid,cfg)
  loss,parts=segmentation_loss(z,t,v,ABL(label_smoothing=.2) if abl_on else None,.1 if abl_on else 0.)
  assert torch.isfinite(loss);loss.backward()
  norm=float(torch.nn.utils.clip_grad_norm_(engine.trainable.parameters(),1.))
  assert norm>0 and np.isfinite(norm);optimizer.step()
  ckpt=ROOT/f'vith_{method}_{abl_on}.pt';engine.save(ckpt)
  engine.load_weights(ckpt)
  with torch.no_grad():out,_=engine.predict_logits(im,encoded,prompt)
  assert out.shape[-2:]==region.shape and torch.isfinite(out).all()
  record=dict(method=method,abl=abl_on,loss=parts,gradient_norm=norm,output_shape=list(out.shape),
   checkpoint_reload=True,elapsed_since_load=time.perf_counter()-start,peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
  results.append(record);print('PASS',json.dumps(record),flush=True)
  (ROOT/'vith_smoke_results.json').write_text(json.dumps(results,indent=2))
  del optimizer,logits,z,t,v,loss,out
 del engine,encoded,initial;gc.collect()
