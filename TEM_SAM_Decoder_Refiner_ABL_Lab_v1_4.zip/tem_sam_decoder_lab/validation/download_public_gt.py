from pathlib import Path
import argparse,json,urllib.request,hashlib
p=argparse.ArgumentParser();p.add_argument('--destination',required=True);a=p.parse_args()
root=Path(a.destination).resolve();meta=Path(__file__).resolve().parent
for group,manifest in [('development','development_sources.json'),('heldout','heldout_sources.json')]:
 records=json.loads((meta/manifest).read_text())
 if group=='heldout':
  records += [r for r in json.loads((meta/'development_sources.json').read_text()) if r['path']=='Scripts/camvid12.png']
 for r in records:
  dest=root/group/r['path'];dest.parent.mkdir(parents=True,exist_ok=True)
  if not dest.exists() or hashlib.sha256(dest.read_bytes()).hexdigest()!=r['sha256']:
   b=urllib.request.urlopen(r['url'],timeout=60).read()
   assert hashlib.sha256(b).hexdigest()==r['sha256'], r['url']
   dest.write_bytes(b)
  print(group,r['path'])
